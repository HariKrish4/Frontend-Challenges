"use client";

import { useState } from "react";
import { TodoList } from "./todo-list";
import { CreateTodoModal } from "./create-todo-modal";
import { TodoItemDisplay } from "./types";
import { Button } from "@/components/ui/button";
import { toggleTodoComplete } from "@/lib/supabase/toggle-todo-action";
import { deleteTodo } from "@/lib/supabase/delete-todo-action";

interface ClientTodoListProps {
  initialTodos: TodoItemDisplay[];
}

export function ClientTodoList({ initialTodos }: ClientTodoListProps) {
  const [todos, setTodos] = useState<TodoItemDisplay[]>(initialTodos);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleToggleComplete = async (id: string) => {
    // Get the current todo to determine new status
    const currentTodo = todos.find((todo) => todo.id === id);
    if (!currentTodo) return;

    const newStatus = !currentTodo.completed;

    // Optimistic update
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, completed: newStatus } : todo
      )
    );

    // Call server action to update in Supabase
    const result = await toggleTodoComplete(id, newStatus);

    // If server action failed, revert the optimistic update
    if (!result) {
      setTodos((prevTodos) =>
        prevTodos.map((todo) =>
          todo.id === id ? { ...todo, completed: !newStatus } : todo
        )
      );
      console.error("Failed to toggle todo completion status");
    }
  };

  const handleDelete = async (id: string) => {
    // Get the todo to delete (for rollback)
    const todoToDelete = todos.find((todo) => todo.id === id);
    if (!todoToDelete) return;

    // Optimistic update - remove from UI immediately
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));

    // Call server action to delete from Supabase
    const success = await deleteTodo(id);

    // If deletion failed, restore the todo
    if (!success) {
      setTodos((prevTodos) => [...prevTodos, todoToDelete]);
      console.error("Failed to delete todo");
    }
  };

  const handleTodoCreated = (newTodo: TodoItemDisplay) => {
    // Optimistic update: add to the top of the list
    setTodos((prevTodos) => [newTodo, ...prevTodos]);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Todo List</h2>
        <Button
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          + Create Todo
        </Button>
      </div>

      {todos.length === 0 ? (
        <div className="p-4 border border-gray-300 bg-gray-50 rounded text-gray-700">
          No todos yet. Create one to get started!
        </div>
      ) : (
        <TodoList
          todos={todos}
          onToggleComplete={handleToggleComplete}
          onDelete={handleDelete}
        />
      )}

      <CreateTodoModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        onTodoCreated={handleTodoCreated}
      />
    </div>
  );
}

