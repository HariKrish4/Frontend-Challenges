//A component that displays a list of todo items with the ability to mark them as completed or delete them.
import TodoListItem from "./todo-list-item";
import { TodoItemDisplay } from "./types";

interface TodoListProps {
  todos: TodoItemDisplay[];
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
}

export function TodoList({ todos, onToggleComplete, onDelete }: TodoListProps) {
  return (
    <ul className="space-y-4">
      {todos.map((todo) => (
        <TodoListItem
          key={todo.id}
          todo={todo}
          onToggleComplete={() => onToggleComplete(todo.id)}
          onDelete={() => onDelete(todo.id)}
        />
      ))}
    </ul>
  );
}
export default TodoList;