import { ClientTodoList } from "./client-todo-list";
import { TodoItemDisplay } from "./types";
import { createClient } from "@/lib/supabase/server";
import { fetchUserTodos, mapTodoItemToDisplay } from "@/lib/supabase/todos";

export async function TodoListServer() {
  const supabase = await createClient();
  let todos: TodoItemDisplay[] = [];

  try {
    // Get the current user's session
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return (
        <div className="p-4 border border-red-300 bg-red-50 rounded text-red-700">
          Unable to authenticate. Please sign in to view your todos.
        </div>
      );
    }

    // Fetch todos for the current user
    const fetchedTodos = await fetchUserTodos(user.id);

    if (fetchedTodos === null) {
      return (
        <div className="p-4 border border-red-300 bg-red-50 rounded text-red-700">
          Failed to load todos. Please try again later.
        </div>
      );
    }

    // Map fetched todos to display format
    todos = fetchedTodos.map(mapTodoItemToDisplay);
  } catch (err) {
    console.error("Error in TodoListServer:", err);
    return (
      <div className="p-4 border border-red-300 bg-red-50 rounded text-red-700">
        An unexpected error occurred while loading todos.
      </div>
    );
  }

  return <ClientTodoList initialTodos={todos} />;
}
