export interface TodoItem {
  id: number;
  task: string | null;
  is_complete: boolean | null;
  inserted_at: string;
  user_id: string;
}

// Mapped type for display compatibility with components
export interface TodoItemDisplay {
  id: string;
  title: string;
  completed: boolean;
  createdAt: Date;
  updatedAt: Date;
}
