"use client";

import { useState } from "react";
import { createTodo } from "@/lib/supabase/create-todo-action";
import { TodoItemDisplay } from "./types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface CreateTodoModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTodoCreated: (todo: TodoItemDisplay) => void;
}

const MAX_CHAR = 250;

export function CreateTodoModal({
  open,
  onOpenChange,
  onTodoCreated,
}: CreateTodoModalProps) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const charCount = input.length;
  const isValid = input.trim().length > 0 && charCount <= MAX_CHAR;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!isValid) {
      setError("Please enter a valid todo (1-250 characters)");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const newTodo = await createTodo(input);

      if (newTodo) {
        onTodoCreated(newTodo);
        setInput("");
        onOpenChange(false);
      } else {
        setError("Failed to create todo. Please try again.");
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Error creating todo:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (newOpen) {
      setInput("");
      setError(null);
    }
    onOpenChange(newOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a New Todo</DialogTitle>
          <DialogDescription>
            Add a new todo item to your list. You can enter up to 250
            characters.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              autoFocus
              placeholder="What do you need to do?"
              value={input}
              onChange={(e) => {
                const newValue = e.target.value;
                if (newValue.length <= MAX_CHAR) {
                  setInput(newValue);
                  setError(null);
                }
              }}
              disabled={loading}
              maxLength={MAX_CHAR}
            />
            <div className="flex justify-between text-xs text-neutral-500">
              <span>
                {charCount}/{MAX_CHAR} characters
              </span>
              {charCount > 0 && charCount >= MAX_CHAR * 0.9 && (
                <span className="text-orange-500">
                  {MAX_CHAR - charCount} remaining
                </span>
              )}
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
              {error}
            </div>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => handleOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!isValid || loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? "Creating..." : "Create Todo"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
