// A page to display and manage a list of todo items.
import { Suspense } from "react";
import { TodoListServer } from "@/components/todo/todo-list-server";

function TodoListSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div
          key={i}
          className="h-16 bg-gray-200 rounded animate-pulse"
        />
      ))}
    </div>
  );
}

export default function TodoPage() {
  return (
    <div className="max-w-md mx-auto mt-10">
      <Suspense fallback={<TodoListSkeleton />}>
        <TodoListServer />
      </Suspense>
    </div>
  );
}
