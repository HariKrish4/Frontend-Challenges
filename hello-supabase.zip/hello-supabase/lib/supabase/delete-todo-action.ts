"use server";

import { createClient } from "./server";

/**
 * Delete a todo from the database
 * @param todoId - The ID of the todo to delete
 * @returns true if deletion was successful, false otherwise
 */
export async function deleteTodo(todoId: string): Promise<boolean> {
  try {
    const supabase = await createClient();

    // Get the current user for authorization
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error("Authentication error:", authError);
      return false;
    }

    // Delete the todo - only allow if user owns it
    const { error } = await supabase
      .from("todos")
      .delete()
      .eq("id", todoId)
      .eq("user_id", user.id);

    if (error) {
      console.error("Error deleting todo:", error);
      return false;
    }

    return true;
  } catch (error) {
    console.error("Unexpected error deleting todo:", error);
    return false;
  }
}
