import { createClient } from "./server";
import { TodoItem, TodoItemDisplay } from "@/components/todo/types";

/**
 * Fetch all todos for a specific user from the Supabase todo table.
 * @param userId - The user ID to fetch todos for
 * @returns Array of TodoItem objects or null if there's an error
 */
export async function fetchUserTodos(userId: string): Promise<TodoItem[] | null> {
  try {
    const supabase = await createClient();

    const { data, error } = await supabase
      .from("todos")
      .select("*")
      .eq("user_id", userId)
      .order("inserted_at", { ascending: false });

    if (error) {
      console.error("Error fetching todos:", error);
      return null;
    }

    return data as TodoItem[];
  } catch (error) {
    console.error("Unexpected error fetching todos:", error);
    return null;
  }
}

/**
 * Map Supabase TodoItem to TodoItemDisplay format for component usage
 */
export function mapTodoItemToDisplay(todo: TodoItem): TodoItemDisplay {
  return {
    id: String(todo.id),
    title: todo.task || "Untitled",
    completed: todo.is_complete ?? false,
    createdAt: new Date(todo.inserted_at),
    updatedAt: new Date(todo.inserted_at),
  };
}


