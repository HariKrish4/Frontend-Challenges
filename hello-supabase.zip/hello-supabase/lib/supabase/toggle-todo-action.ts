"use server";

import { createClient } from "./server";
import { TodoItemDisplay } from "@/components/todo/types";
import { mapTodoItemToDisplay } from "./todos";

/**
 * Toggle the completion status of a todo
 * @param todoId - The ID of the todo to toggle
 * @param isComplete - The new completion status
 * @returns The updated todo or null if there's an error
 */
export async function toggleTodoComplete(
  todoId: string,
  isComplete: boolean
): Promise<TodoItemDisplay | null> {
  try {
    const supabase = await createClient();

    // Get the current user for authorization
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error("Authentication error:", authError);
      return null;
    }

    // Update the todo - only allow if user owns it
    const { data, error } = await supabase
      .from("todos")
      .update({ is_complete: isComplete })
      .eq("id", todoId)
      .eq("user_id", user.id)
      .select()
      .single();

    if (error) {
      console.error("Error toggling todo:", error);
      return null;
    }

    if (!data) {
      console.error("Todo not found or unauthorized");
      return null;
    }

    return mapTodoItemToDisplay(data);
  } catch (error) {
    console.error("Unexpected error toggling todo:", error);
    return null;
  }
}
