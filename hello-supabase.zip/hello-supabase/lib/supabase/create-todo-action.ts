"use server";

import { createClient } from "./server";
import { TodoItem, TodoItemDisplay } from "@/components/todo/types";
import { mapTodoItemToDisplay } from "./todos";

/**
 * Create a new todo for the current user
 * @param task - The todo task text
 * @returns The newly created todo or null if there's an error
 */
export async function createTodo(
  task: string
): Promise<TodoItemDisplay | null> {
  try {
    if (!task || task.trim().length === 0) {
      console.error("Task cannot be empty");
      return null;
    }

    if (task.length > 250) {
      console.error("Task cannot exceed 250 characters");
      return null;
    }

    const supabase = await createClient();

    // Get the current user
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error("Authentication error:", authError);
      return null;
    }

    // Insert the new todo
    const { data, error } = await supabase
      .from("todos")
      .insert({
        task: task.trim(),
        user_id: user.id,
        is_complete: false,
      })
      .select()
      .single();

    if (error) {
      console.error("Error creating todo:", error);
      return null;
    }

    return mapTodoItemToDisplay(data as TodoItem);
  } catch (error) {
    console.error("Unexpected error creating todo:", error);
    return null;
  }
}
