# Copilot Instructions for Next.js + Supabase Starter Kit

## Project Overview
A full-stack Next.js application integrated with Supabase for authentication and backend services. Uses App Router, React 19, TypeScript, Tailwind CSS, and shadcn/ui components.

## Architecture & Key Patterns

### Supabase Client Initialization
- **Client-side** (`lib/supabase/client.ts`): Use `createBrowserClient()` for client components accessing Supabase
- **Server-side** (`lib/supabase/server.ts`): Use `createServerClient()` for Server Components with cookie management
- **Middleware proxy** (`lib/supabase/proxy.ts`): Handles session refresh via Next.js middleware—calls `supabase.auth.getClaims()` to validate/refresh user sessions on every request
- **Critical**: Don't cache server clients globally; create new instances per request (Fluid compute compatibility)

### Authentication Flow
1. Users authenticate via `components/login-form.tsx` or sign-up-form (client components using browser client)
2. Middleware proxy (`proxy.ts` via `middleware` entry point) automatically refreshes sessions and sets cookies
3. Protected routes in `app/protected/` check session via Server Component `AuthButton` using `getClaims()`
4. Auth state persists across browser and server via HTTP-only cookies managed by `@supabase/ssr`

### Session Management Pattern
- Server Components access user via: `await supabase.auth.getClaims()` → `data?.claims` (the user object)
- Client Components call auth methods directly on browser client, then use `useRouter().push()` for navigation
- **Don't mix**: Ensure client and server clients are used in appropriate context (check `"use client"` directive)

## Development Workflows

### Running the Application
```bash
npm run dev        # Start Next.js dev server on http://localhost:3000
npm run build      # Production build
npm run lint       # Run ESLint with Next.js/TypeScript rules
```

### Required Environment Variables
Create `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=<your-project-url>
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=<your-publishable-or-anon-key>
```
Use `lib/utils.ts::hasEnvVars` to check if configured (already used in app to show setup warnings).

## Code Organization & Conventions

### Component Structure
- **UI Components** (`components/ui/`): Atomic shadcn/ui components (Button, Card, Input, etc.)
- **Feature Components** (`components/`): Auth forms, theme switcher, buttons—mostly client components
- **Page Components** (`app/`): Use Server Components by default, add `"use client"` only when needed (state, events, hooks)
- **CSS Classes**: Use `cn()` utility from `lib/utils.ts` (combines clsx + tailwind-merge) for conditional styling

### Directory Layout
- `app/` — Next.js App Router pages and layouts
  - `auth/` — Public auth routes (login, sign-up, password reset)
  - `protected/` — Requires session; wraps children with auth UI
  - `instruments/` and `todo/` — Feature pages
- `components/` — Reusable React components
- `lib/supabase/` — Supabase client factories (client, server, proxy)
- `lib/utils.ts` — Shared utilities (cn, hasEnvVars)

### Styling & Theming
- Tailwind CSS with `next-themes` for dark mode
- shadcn/ui components configured in `components.json`
- Color scheme uses CSS variables (e.g., `bg-foreground`, `border-b-foreground/10`)
- Never hardcode colors; use Tailwind utilities

## Integration Points & Dependencies

### Key Dependencies
- `@supabase/ssr` — Handles Auth over cookies for Next.js SSR/SSG
- `@supabase/supabase-js` — Client library for Supabase queries
- `next-themes` — Dark mode toggle without hydration mismatch
- `@radix-ui/*` — Headless UI primitives (checkbox, dropdown, label)
- `shadcn/ui` — Pre-built accessible components built on Radix UI

### Middleware & Route Handlers
- Middleware runs via `proxy.ts` config, exported from root `proxy.ts` file
- Handles automatic session refresh and cookie management
- Route handlers in `app/auth/confirm/route.ts` handle OAuth/magic link callbacks
- No traditional pages router used; App Router only

## Common Patterns & Anti-Patterns

✅ **DO:**
- Create Server Components by default; use `"use client"` sparingly
- Import client components with dynamic imports if needed in Server Components
- Use `Suspense` boundaries for async operations (AuthButton in layouts)
- Always await server Supabase operations and handle auth.error gracefully
- Validate auth state at layout level (`protected/layout.tsx` pattern)

❌ **DON'T:**
- Store Supabase client as a module-level global variable
- Call `createServerClient()` outside async functions
- Mix browser and server clients in the same component
- Hardcode styling values; always use Tailwind utilities
- Forget to set cookies in server client setup (proxy.setAll uses try-catch for this reason)

## Quick Navigation
- **Auth flows**: `components/login-form.tsx`, `components/sign-up-form.tsx`
- **Protected routing**: `app/protected/layout.tsx` + `AuthButton` Server Component
- **Styling config**: `tailwind.config.ts`, `components.json`
- **Session refresh**: `lib/supabase/proxy.ts` + `proxy.ts` middleware entry
