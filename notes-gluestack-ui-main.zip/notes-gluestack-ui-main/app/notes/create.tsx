import { useCallback, useEffect, useState } from "react";
import { useRouter } from "expo-router";
import { View } from "@/components/ui/view";
import { VStack } from "@/components/ui/vstack";
import { Box } from "@/components/ui/box";
import { Text } from "@/components/ui/text";
import { Button, ButtonText } from "@/components/ui/button";
import { HStack } from "@/components/ui/hstack";
import { Input, InputField } from "@/components/ui/input";
import { Pressable } from "@/components/ui/pressable";
import { Badge, BadgeText } from "@/components/ui/badge";
import { SafeAreaView } from "@/components/ui/safe-area-view";
import { Alert } from "react-native";
import { createNote, listTags, type Tag } from "@/lib/notes-repository";

export default function CreateNoteScreen() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTagIds, setSelectedTagIds] = useState<number[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  const loadTags = useCallback(async () => {
    try {
      const availableTags = await listTags();
      setTags(availableTags);
    } catch {
      Alert.alert("Error", "Unable to load tags.");
    }
  }, []);

  useEffect(() => {
    void loadTags();
  }, [loadTags]);

  const handleCreate = async () => {
    if (!title.trim()) {
      Alert.alert("Validation", "Please enter a note title.");
      return;
    }

    try {
      setIsSaving(true);
      await createNote({
        title: title.trim(),
        content: content.trim(),
        tagIds: selectedTagIds,
      });

      router.back();
    } catch {
      Alert.alert("Error", "Unable to create note.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (!isSaving) {
      router.back();
    }
  };

  const handleToggleTag = (tagId: number) => {
    setSelectedTagIds((current) =>
      current.includes(tagId)
        ? current.filter((id) => id !== tagId)
        : [...current, tagId],
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
      <View className="flex-1 bg-white p-4">
        <VStack space="md" className="flex-1">
          <Box className="mb-4">
            <Text className="text-xs text-gray-500 mb-2">Title</Text>
            <Input className="border border-gray-300 rounded-lg">
              <InputField
                className="text-lg font-bold"
                value={title}
                onChangeText={setTitle}
                placeholder="Note title"
              />
            </Input>
          </Box>

          <VStack space="sm" className="flex-1">
            <Text className="text-xs text-gray-500">Content</Text>
            <Input className="border border-gray-300 rounded-lg p-3 flex-1">
              <InputField
                className="text-base font-normal"
                value={content}
                onChangeText={setContent}
                placeholder="Note content"
                multiline
                textAlignVertical="top"
              />
            </Input>
          </VStack>

          <VStack space="sm">
            <Text className="text-xs text-gray-500">Tags</Text>
            {tags.length === 0 ? (
              <Text className="text-sm text-gray-500">No tags available.</Text>
            ) : (
              <HStack className="flex-wrap" space="sm">
                {tags.map((tag) => {
                  const selected = selectedTagIds.includes(tag.id);

                  return (
                    <Pressable
                      key={tag.id}
                      onPress={() => handleToggleTag(tag.id)}
                    >
                      <Badge
                        variant={selected ? "solid" : "outline"}
                        action={selected ? "info" : "muted"}
                      >
                        <BadgeText>{tag.name}</BadgeText>
                      </Badge>
                    </Pressable>
                  );
                })}
              </HStack>
            )}
          </VStack>

          <HStack space="md">
            <Button
              className="flex-1 bg-green-500"
              onPress={() => void handleCreate()}
              size="lg"
              isDisabled={isSaving}
            >
              <ButtonText>{isSaving ? "Creating..." : "Create"}</ButtonText>
            </Button>
            <Button
              className="flex-1 bg-gray-400"
              onPress={handleCancel}
              size="lg"
              isDisabled={isSaving}
            >
              <ButtonText>Cancel</ButtonText>
            </Button>
          </HStack>
        </VStack>
      </View>
    </SafeAreaView>
  );
}
