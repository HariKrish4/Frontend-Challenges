import { Box } from "@/components/ui/box";
import { VStack } from "@/components/ui/vstack";
import { HStack } from "@/components/ui/hstack";
import { Text } from "@/components/ui/text";
import { Pressable } from "@/components/ui/pressable";
import { Input, InputField } from "@/components/ui/input";
import { SafeAreaView } from "@/components/ui/safe-area-view";
import { useRouter } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import { Alert, ScrollView } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Badge, BadgeText } from "@/components/ui/badge";
import {
  listNotes,
  listTags,
  type Note,
  type Tag,
} from "@/lib/notes-repository";

export default function HomeScreen() {
  const router = useRouter();
  const [notes, setNotes] = useState<Note[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTagIds, setSelectedTagIds] = useState<number[]>([]);

  const formatTimestamp = (iso: string) => {
    const parsed = new Date(iso);
    if (Number.isNaN(parsed.getTime())) return "Unknown date";
    return parsed.toLocaleString();
  };

  const loadNotes = useCallback(async () => {
    try {
      setIsLoading(true);
      const [rows, availableTags] = await Promise.all([
        listNotes(),
        listTags(),
      ]);
      setNotes(rows);
      setTags(availableTags);
    } catch {
      Alert.alert("Error", "Unable to load notes.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void loadNotes();
    }, [loadNotes]),
  );

  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim() && selectedTagIds.length === 0) return notes;

    const query = searchQuery.toLowerCase();
    return notes.filter((note) => {
      const matchesSearch =
        !searchQuery.trim() ||
        note.title.toLowerCase().includes(query) ||
        note.content.toLowerCase().includes(query);

      const matchesTagFilter =
        selectedTagIds.length === 0 ||
        note.tags.some((tag) => selectedTagIds.includes(tag.id));

      return matchesSearch && matchesTagFilter;
    });
  }, [notes, searchQuery, selectedTagIds]);

  const handleNotePress = (noteId: number) => {
    router.push(`/notes/${noteId}`);
  };

  const handleCreateNote = () => {
    router.push("/notes/create");
  };

  const handleClearSearch = () => {
    setSearchQuery("");
  };

  const handleToggleTagFilter = (tagId: number) => {
    setSelectedTagIds((current) =>
      current.includes(tagId)
        ? current.filter((id) => id !== tagId)
        : [...current, tagId],
    );
  };

  const handleClearTagFilters = () => {
    setSelectedTagIds([]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
      <VStack space="md" reversed={false} className="flex-1 p-4">
        <Input className="border border-gray-300 rounded-lg mb-2">
          <InputField
            className="text-base"
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search notes by title or content..."
          />
        </Input>

        {tags.length > 0 && (
          <VStack space="sm" className="mb-2">
            <HStack className="justify-between items-center">
              <Text className="text-xs text-gray-500">Filter by tags</Text>
              {selectedTagIds.length > 0 && (
                <Pressable onPress={handleClearTagFilters}>
                  <Text className="text-xs text-blue-500 font-semibold">
                    Clear tags
                  </Text>
                </Pressable>
              )}
            </HStack>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <HStack space="sm">
                {tags.map((tag) => {
                  const selected = selectedTagIds.includes(tag.id);
                  return (
                    <Pressable
                      key={tag.id}
                      onPress={() => handleToggleTagFilter(tag.id)}
                    >
                      <Badge
                        variant={selected ? "solid" : "outline"}
                        action={selected ? "info" : "muted"}
                      >
                        <BadgeText>{tag.name}</BadgeText>
                      </Badge>
                    </Pressable>
                  );
                })}
              </HStack>
            </ScrollView>
          </VStack>
        )}

        {searchQuery.trim() && (
          <HStack className="justify-between items-center mb-2">
            <Text className="text-sm text-gray-600">
              {filteredNotes.length} result
              {filteredNotes.length !== 1 ? "s" : ""} found
            </Text>
            <Pressable onPress={handleClearSearch}>
              <Text className="text-sm text-blue-500 font-semibold">Clear</Text>
            </Pressable>
          </HStack>
        )}

        {isLoading ? (
          <Text className="text-sm text-gray-600">Loading notes...</Text>
        ) : notes.length === 0 ? (
          <Text className="text-sm text-gray-600">
            No notes yet. Create one.
          </Text>
        ) : filteredNotes.length === 0 ? (
          <Text className="text-sm text-gray-600">
            No notes match "{searchQuery}". Try a different search.
          </Text>
        ) : (
          filteredNotes.map((note) => (
            <Pressable
              key={note.id}
              onPress={() => handleNotePress(note.id)}
              className="active:opacity-70"
            >
              <Box
                className={`p-4 rounded-lg border ${
                  note.is_pinned === 1
                    ? "bg-yellow-50 border-yellow-300"
                    : "bg-gray-100 border-gray-300"
                }`}
              >
                <HStack className="justify-between items-start mb-2">
                  <Text className="font-bold text-lg flex-1">{note.title}</Text>
                  {note.is_pinned === 1 && (
                    <Text className="text-yellow-600 text-lg ml-2">★</Text>
                  )}
                </HStack>
                <Text className="text-sm text-gray-600" numberOfLines={2}>
                  {note.content}
                </Text>
                {note.tags.length > 0 && (
                  <HStack className="mt-2" space="sm">
                    {note.tags.map((tag) => (
                      <Badge
                        key={tag.id}
                        size="sm"
                        variant="outline"
                        action="muted"
                      >
                        <BadgeText>{tag.name}</BadgeText>
                      </Badge>
                    ))}
                  </HStack>
                )}
                <Text className="text-xs text-gray-500 mt-2">
                  Updated: {formatTimestamp(note.updated_at)}
                </Text>
              </Box>
            </Pressable>
          ))
        )}
      </VStack>
    </SafeAreaView>
  );
}
