import { GluestackUIProvider } from "@/components/ui/gluestack-ui-provider";
import { SafeAreaView } from "@/components/ui/safe-area-view";
import "@/global.css";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import {
  DarkTheme,
  DefaultTheme,
  ThemeProvider,
} from "@react-navigation/native";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { useEffect, useState } from "react";
import { useColorScheme } from "@/components/useColorScheme";
import { Slot, Stack, usePathname } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { Fab, FabIcon } from "@/components/ui/fab";
import { MoonIcon, SunIcon, SlashIcon, AddIcon } from "@/components/ui/icon";
import { Alert } from "react-native";
import { initDb } from "@/lib/db";
import { useRouter } from "expo-router";

export {
  // Catch any errors thrown by the Layout component.
  ErrorBoundary,
} from "expo-router";

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
    SpaceMono: require("../assets/fonts/SpaceMono-Regular.ttf"),
    ...FontAwesome.font,
  });

  // Expo Router uses Error Boundaries to catch errors in the navigation tree.
  useEffect(() => {
    if (error) throw error;
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded && !error) {
    return null;
  }

  return <RootLayoutNav />;
}

function RootLayoutNav() {
  const router = useRouter();
  const pathname = usePathname();
  const systemColorScheme = useColorScheme();
  const [mode, setMode] = useState<"system" | "light" | "dark">("system");

  useEffect(() => {
    const setup = async () => {
      try {
        await initDb();
      } catch {
        Alert.alert("Database Error", "Unable to initialize notes database.");
      }
    };

    void setup();
  }, []);

  // Determine effective color scheme
  const effectiveColorScheme =
    mode === "system" ? (systemColorScheme ?? "light") : mode;

  const handleCreateNote = () => {
    router.push("/notes/create");
  };

  return (
    <GluestackUIProvider mode={mode}>
      <ThemeProvider
        value={effectiveColorScheme === "dark" ? DarkTheme : DefaultTheme}
      >
        <SafeAreaView style={{ flex: 1 }}>
          <Stack>
            <Stack.Screen
              name="index"
              options={{ title: "Notes", headerShown: true }}
            />
            <Stack.Screen
              name="notes/[id]"
              options={{ title: "Note Detail", headerShown: true }}
            />
            <Stack.Screen
              name="notes/create"
              options={{ title: "Create Note", headerShown: true }}
            />
          </Stack>
          {pathname === "/" && (
            <Fab onPress={handleCreateNote} className="m-6" size="lg">
              <FabIcon as={AddIcon} />
            </Fab>
          )}
        </SafeAreaView>
      </ThemeProvider>
    </GluestackUIProvider>
  );
}
