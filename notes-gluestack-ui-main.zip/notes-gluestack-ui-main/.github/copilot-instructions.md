# Project Guidelines

## Code Style

- Use TypeScript React components with Expo Router screen files in `app/` (examples: `app/index.tsx`, `app/notes/create.tsx`).
- Prefer local UI primitives from `components/ui/*` over raw React Native components where wrappers exist (`button`, `input`, `text`, `box`, `vstack`, `hstack`, `pressable`).
- Styling is `className`-first via NativeWind/Tailwind tokens; follow existing utility-style patterns in `app/index.tsx` and `app/notes/[id].tsx`.
- Keep imports on `@/` alias paths (configured in `babel.config.js`) for app-local modules.

## Architecture

- **Navigation**: File-based Expo Router with stack registration in `app/_layout.tsx` screens: `index` (home), `notes/[id]` (detail), `notes/create`.
- **Data Layer**: SQLite database (expo-sqlite) initialized in `lib/db.ts` with `notes` table (id, title, content, created_at, updated_at).
- **Repository Pattern**: `lib/notes-repository.ts` exports async CRUD functions: `listNotes()`, `getNoteById(id)`, `createNote()`, `updateNote()`, `deleteNote()`.
- **Screens**:
  - Home (`app/index.tsx`): loads notes on focus via `useFocusEffect`, renders list, routes to detail/create.
  - Detail (`app/notes/[id].tsx`): resolves `id` from `useLocalSearchParams()`, loads note and provides edit/delete UI.
  - Create (`app/notes/create.tsx`): form for new note, validates title, persists to SQLite, returns to previous screen.

## Build and Test

- Install deps: `npm install`
- Start dev server: `npm run start`
- Run platforms: `npm run ios`, `npm run android`, `npm run web`
- Web export build: `npm run build` or `npm run build:preview`
- Tests: `npm run test` (Jest watch mode); test files in `__tests__/` use React Testing Library + mocking

## Data Persistence & Async Patterns

- All data operations (`lib/notes-repository.ts`) are async and use try-catch with `Alert.alert()` for error handling.
- `lib/db.ts` manages single SQLite connection (cached promise) and schema initialization with WAL mode enabled.
- Screens use `useState` for form state; call repository methods directly (no global state or context).
- Use `useFocusEffect` to reload data when screen gains focus (prevents stale state across navigation).

## Project Conventions

- Header titles configured in `app/_layout.tsx` via `Stack.Screen options`, not per-screen.
- Root layout initializes database on mount via `initDb()` with error Alert.
- Form validation before async operations (e.g., require non-empty title in `app/notes/create.tsx`).
- Loading/error states managed with `Alert.alert()` and conditional rendering (see `app/index.tsx`, `app/notes/[id].tsx`).
- Theme mode cycles `system -> light -> dark` via FAB on root; set via `GluestackUIProvider mode` prop.

## Integration Points

- Expo Router entrypoint: `expo-router/entry` in `package.json`; typed routes enabled in `app.json`.
- NativeWind/Tailwind: configured via `babel.config.js`, `metro.config.js`, `tailwind.config.js`, `global.css`.
- Gluestack UI provider/config in `components/ui/gluestack-ui-provider/`; applied at root layout.
- Dependencies include `expo-sqlite`, `@gluestack-ui/core`, `nativewind`, `react-navigation`, `lucide-react-native` for icons.

## Testing Patterns

- Mock `@/lib/notes-repository` functions and `expo-router` hooks in component tests.
- Use `render()`, `fireEvent`, `screen`, `waitFor` from `@testing-library/react-native`.
- Example: [create-note.screen.test.tsx](__tests__/create-note.screen.test.tsx) tests validation and navigation.

## Security & Data Handling

- No auth, secrets, or external APIs currently integrated.
- Sensitive note content is persisted to SQLite; remove console logs if logging content in production.
- SQLite stores data locally on device; no network backup or export implemented.
