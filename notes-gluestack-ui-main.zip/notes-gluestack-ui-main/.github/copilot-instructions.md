# Project Guidelines

## Code Style
- Use TypeScript React components with Expo Router screen files in `app/` (examples: `app/index.tsx`, `app/notes/create.tsx`).
- Prefer local UI primitives from `components/ui/*` over raw React Native components where wrappers exist (`button`, `input`, `text`, `box`, `vstack`, `hstack`, `pressable`).
- Styling is `className`-first via NativeWind/Tailwind tokens; follow existing utility-style patterns in `app/index.tsx` and `app/notes/[id].tsx`.
- Keep imports on `@/` alias paths (configured in `babel.config.js`) for app-local modules.

## Architecture
- Navigation is file-based Expo Router with stack registration in `app/_layout.tsx` (`index`, `notes/[id]`, `notes/create`).
- Data source is local `notes.json`; no backend or persistent storage is wired yet.
- Home list (`app/index.tsx`) reads notes and routes to detail/create.
- Detail view (`app/notes/[id].tsx`) resolves `id` from route params and edits/deletes in memory only.
- Create view (`app/notes/create.tsx`) builds a new note object and returns without persisting to disk.

## Build and Test
- Install deps: `npm install`
- Start dev server: `npm run start`
- Run platforms: `npm run ios`, `npm run android`, `npm run web`
- Web export build: `npm run build` (or `npm run build:preview`)
- Tests: `npm run test` (Jest watch mode)

## Project Conventions
- Keep header titles and screen visibility configured in `app/_layout.tsx` rather than per-screen ad hoc.
- Use Gluestack provider + navigation theme from the root layout (`GluestackUIProvider`, `ThemeProvider`) as in `app/_layout.tsx`.
- Theme mode cycles `system -> light -> dark` via FAB on root route only; preserve this behavior unless task requests change.
- Current note mutations are demonstrative (console output) and do not persist; avoid implying persistence unless you implement it.

## Integration Points
- Expo Router entrypoint is `expo-router/entry` in `package.json`; typed routes enabled in `app.json` (`experiments.typedRoutes`).
- NativeWind/Tailwind pipeline spans `babel.config.js`, `metro.config.js`, `tailwind.config.js`, and `global.css`.
- Gluestack UI config/provider lives in `components/ui/gluestack-ui-provider/`.
- Note schema contract is defined by `notes.json` fields: `id`, `title`, `content`, `created_at`, `updated_at`.

## Security
- No auth, secrets, or external API integration are present in current app code.
- Avoid adding secrets to source files or logs.
- Note content is currently logged during create/update/delete flows (`app/notes/create.tsx`, `app/notes/[id].tsx`); remove or guard logs if handling sensitive user data.
