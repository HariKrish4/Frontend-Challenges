import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { beforeEach, describe, expect, it, jest } from "@jest/globals";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Alert } from "react-native";
import NoteDetailScreen from "@/app/notes/[id]";
import {
  deleteNote,
  getNoteById,
  listTags,
  updateNote,
  togglePinNote,
} from "@/lib/notes-repository";

jest.mock("@/lib/notes-repository", () => ({
  getNoteById: jest.fn(),
  listTags: jest.fn(),
  updateNote: jest.fn(),
  deleteNote: jest.fn(),
  togglePinNote: jest.fn(),
}));

const mockedUseRouter = useRouter as unknown as jest.MockedFunction<
  typeof useRouter
>;
const mockedUseLocalSearchParams =
  useLocalSearchParams as unknown as jest.MockedFunction<
    typeof useLocalSearchParams
  >;
const mockedGetNoteById = getNoteById as jest.MockedFunction<
  typeof getNoteById
>;
const mockedListTags = listTags as jest.MockedFunction<typeof listTags>;
const mockedUpdateNote = updateNote as jest.MockedFunction<typeof updateNote>;
const mockedDeleteNote = deleteNote as jest.MockedFunction<typeof deleteNote>;
const mockedTogglePinNote = togglePinNote as jest.MockedFunction<
  typeof togglePinNote
>;
const mockBack = jest.fn();

const baseNote = {
  id: 1,
  title: "Sample note",
  content: "Sample content",
  created_at: "2026-03-17T00:00:00.000Z",
  updated_at: "2026-03-17T00:00:00.000Z",
  is_pinned: 0,
  tags: [{ id: 2, name: "Work" }],
};

describe("NoteDetailScreen", () => {
  beforeEach(() => {
    mockedUseRouter.mockReturnValue({
      back: mockBack,
    } as unknown as ReturnType<typeof useRouter>);
    mockedUseLocalSearchParams.mockReturnValue({
      id: "1",
    } as ReturnType<typeof useLocalSearchParams>);
    mockedListTags.mockResolvedValue([
      { id: 1, name: "Personal" },
      { id: 2, name: "Work" },
    ]);
    mockedGetNoteById.mockResolvedValue(baseNote);
    mockedUpdateNote.mockResolvedValue(baseNote);
    mockedDeleteNote.mockResolvedValue(undefined);
    mockedTogglePinNote.mockResolvedValue(baseNote);
    mockBack.mockClear();
  });

  it("loads and displays the note", async () => {
    render(<NoteDetailScreen />);

    expect(await screen.findByText("Sample note")).toBeTruthy();
    expect(screen.getByText("Sample content")).toBeTruthy();
    expect(screen.getByText("Work")).toBeTruthy();
    expect(screen.getByText(/Created:/)).toBeTruthy();
    expect(screen.getByText(/Updated:/)).toBeTruthy();
    expect(mockedGetNoteById).toHaveBeenCalledWith(1);
  });

  it("shows validation alert when saving with empty title", async () => {
    render(<NoteDetailScreen />);

    await screen.findByText("Sample note");

    fireEvent.press(screen.getByText("Edit"));
    fireEvent.changeText(screen.getByPlaceholderText("Note title"), "   ");
    fireEvent.press(screen.getByText("Save"));

    expect(Alert.alert).toHaveBeenCalledWith(
      "Validation",
      "Please enter a note title.",
    );
    expect(mockedUpdateNote).not.toHaveBeenCalled();
  });

  it("updates note with trimmed values and exits edit mode", async () => {
    mockedUpdateNote.mockResolvedValue({
      ...baseNote,
      title: "Updated title",
      content: "Updated content",
    });

    render(<NoteDetailScreen />);

    await screen.findByText("Sample note");

    fireEvent.press(screen.getByText("Edit"));
    fireEvent.changeText(
      screen.getByPlaceholderText("Note title"),
      "  Updated title  ",
    );
    fireEvent.changeText(
      screen.getByPlaceholderText("Note content"),
      "  Updated content  ",
    );
    fireEvent.press(screen.getByText("Personal"));
    fireEvent.press(screen.getByText("Save"));

    await waitFor(() => {
      expect(mockedUpdateNote).toHaveBeenCalledWith(1, {
        title: "Updated title",
        content: "Updated content",
        tagIds: [2, 1],
      });
    });

    expect(await screen.findByText("Updated title")).toBeTruthy();
  });

  it("deletes note and navigates back", async () => {
    render(<NoteDetailScreen />);

    await screen.findByText("Sample note");
    fireEvent.press(screen.getByText("Delete"));

    expect(Alert.alert).toHaveBeenCalledWith(
      "Delete note?",
      "This action cannot be undone.",
      expect.any(Array),
    );

    const alertButtons = (Alert.alert as jest.Mock).mock.calls[0]?.[2] as
      | Array<{ onPress?: () => void }>
      | undefined;
    const deleteAction = alertButtons?.[1];
    deleteAction?.onPress?.();

    await waitFor(() => {
      expect(mockedDeleteNote).toHaveBeenCalledWith(1);
    });

    expect(mockBack).toHaveBeenCalledTimes(1);
  });

  it("does not delete note when confirmation is canceled", async () => {
    render(<NoteDetailScreen />);

    await screen.findByText("Sample note");
    fireEvent.press(screen.getByText("Delete"));

    const alertButtons = (Alert.alert as jest.Mock).mock.calls[0]?.[2] as
      | Array<{ onPress?: () => void }>
      | undefined;
    const cancelAction = alertButtons?.[0];
    cancelAction?.onPress?.();

    expect(mockedDeleteNote).not.toHaveBeenCalled();
    expect(mockBack).not.toHaveBeenCalled();
  });

  it("toggles pin status and updates display", async () => {
    const pinnedNote = { ...baseNote, is_pinned: 1 };
    mockedTogglePinNote.mockResolvedValue(pinnedNote);

    render(<NoteDetailScreen />);

    await screen.findByText("Sample note");
    fireEvent.press(screen.getByText("☆ Pin"));

    await waitFor(() => {
      expect(mockedTogglePinNote).toHaveBeenCalledWith(1);
    });
  });
});
