import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { beforeEach, describe, expect, it, jest } from "@jest/globals";
import { useRouter } from "expo-router";
import { Alert } from "react-native";
import CreateNoteScreen from "@/app/notes/create";
import { createNote, listTags } from "@/lib/notes-repository";

jest.mock("@/lib/notes-repository", () => ({
  createNote: jest.fn(),
  listTags: jest.fn(),
}));

const mockedUseRouter = useRouter as jest.MockedFunction<typeof useRouter>;
const mockedCreateNote = createNote as jest.MockedFunction<typeof createNote>;
const mockedListTags = listTags as jest.MockedFunction<typeof listTags>;
const mockBack = jest.fn();

describe("CreateNoteScreen", () => {
  beforeEach(() => {
    mockedUseRouter.mockReturnValue({
      back: mockBack,
    } as unknown as ReturnType<typeof useRouter>);
    mockedListTags.mockResolvedValue([
      { id: 1, name: "Personal" },
      { id: 2, name: "Work" },
    ]);
    mockBack.mockClear();
  });

  it("shows validation alert when title is empty", () => {
    render(<CreateNoteScreen />);

    fireEvent.press(screen.getByText("Create"));

    expect(Alert.alert).toHaveBeenCalledWith(
      "Validation",
      "Please enter a note title.",
    );
    expect(mockedCreateNote).not.toHaveBeenCalled();
    expect(mockBack).not.toHaveBeenCalled();
  });

  it("creates note with trimmed values and navigates back", async () => {
    mockedCreateNote.mockResolvedValue({
      id: 1,
      title: "Hello",
      content: "World",
      created_at: "2026-03-17T00:00:00.000Z",
      updated_at: "2026-03-17T00:00:00.000Z",
      is_pinned: 0,
      tags: [],
    });

    render(<CreateNoteScreen />);

    fireEvent.changeText(
      screen.getByPlaceholderText("Note title"),
      "  Hello  ",
    );
    fireEvent.changeText(
      screen.getByPlaceholderText("Note content"),
      "  World  ",
    );
    fireEvent.press(await screen.findByText("Work"));
    fireEvent.press(screen.getByText("Create"));

    await waitFor(() => {
      expect(mockedCreateNote).toHaveBeenCalledWith({
        title: "Hello",
        content: "World",
        tagIds: [2],
      });
    });

    expect(mockBack).toHaveBeenCalledTimes(1);
  });

  it("shows error alert when create note fails", async () => {
    mockedCreateNote.mockRejectedValue(new Error("insert failed"));

    render(<CreateNoteScreen />);

    fireEvent.changeText(
      screen.getByPlaceholderText("Note title"),
      "Test title",
    );
    fireEvent.press(screen.getByText("Create"));

    await waitFor(() => {
      expect(Alert.alert).toHaveBeenCalledWith(
        "Error",
        "Unable to create note.",
      );
    });

    expect(mockBack).not.toHaveBeenCalled();
  });
});
