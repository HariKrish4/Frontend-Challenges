import {
  createNote,
  createTag,
  deleteNote,
  getNoteById,
  listNotes,
  listTags,
  setNoteTags,
  togglePinNote,
  updateNote,
} from "@/lib/notes-repository";
import { beforeEach, describe, expect, it, jest } from "@jest/globals";
import { getDb, initDb } from "@/lib/db";

jest.mock("@/lib/db");

type MockDb = {
  getAllAsync: ReturnType<typeof jest.fn>;
  getFirstAsync: ReturnType<typeof jest.fn>;
  runAsync: ReturnType<typeof jest.fn>;
};

const mockedGetDb = getDb as jest.MockedFunction<typeof getDb>;
const mockedInitDb = initDb as jest.MockedFunction<typeof initDb>;

describe("notes-repository", () => {
  const mockDb: MockDb = {
    getAllAsync: jest.fn(),
    getFirstAsync: jest.fn(),
    runAsync: jest.fn(),
  };

  beforeEach(() => {
    mockedInitDb.mockResolvedValue(undefined);
    mockedGetDb.mockResolvedValue(mockDb as never);
    mockDb.getAllAsync.mockReset();
    mockDb.getFirstAsync.mockReset();
    mockDb.runAsync.mockReset();
  });

  it("lists notes ordered by is_pinned and updated_at with hydrated tags", async () => {
    mockDb.getAllAsync
      .mockResolvedValueOnce([
        {
          id: 1,
          title: "A",
          content: "B",
          created_at: "2026-03-17T00:00:00.000Z",
          updated_at: "2026-03-17T00:00:00.000Z",
          is_pinned: 0,
        },
      ])
      .mockResolvedValueOnce([{ note_id: 1, id: 2, name: "Work" }]);

    const result = await listNotes();

    expect(mockedInitDb).toHaveBeenCalledTimes(1);
    expect(mockDb.getAllAsync).toHaveBeenNthCalledWith(
      1,
      "SELECT id, title, content, created_at, updated_at, is_pinned FROM notes ORDER BY is_pinned DESC, datetime(updated_at) DESC",
    );
    expect(result[0]?.tags).toEqual([{ id: 2, name: "Work" }]);
  });

  it("lists notes filtered by tags", async () => {
    mockDb.getAllAsync.mockResolvedValueOnce([]);

    await listNotes([1, 2]);

    expect(mockDb.getAllAsync).toHaveBeenNthCalledWith(
      1,
      expect.stringContaining("WHERE nt.tag_id IN (?, ?)"),
      1,
      2,
    );
  });

  it("gets note by id with tags", async () => {
    mockDb.getFirstAsync.mockResolvedValue({
      id: 12,
      title: "Title",
      content: "Content",
      created_at: "2026-03-17T00:00:00.000Z",
      updated_at: "2026-03-17T00:00:00.000Z",
      is_pinned: 0,
    });
    mockDb.getAllAsync.mockResolvedValue([
      { note_id: 12, id: 3, name: "Ideas" },
    ]);

    const note = await getNoteById(12);

    expect(mockDb.getFirstAsync).toHaveBeenCalledWith(
      "SELECT id, title, content, created_at, updated_at, is_pinned FROM notes WHERE id = ?",
      12,
    );
    expect(note?.tags).toEqual([{ id: 3, name: "Ideas" }]);
  });

  it("creates note, sets tags, and reads inserted record", async () => {
    const nowSpy = jest
      .spyOn(Date.prototype, "toISOString")
      .mockReturnValue("2026-03-17T00:00:00.000Z");

    mockDb.runAsync.mockResolvedValue({ lastInsertRowId: 7 });
    mockDb.getFirstAsync.mockResolvedValue({
      id: 7,
      title: "Title",
      content: "Content",
      created_at: "2026-03-17T00:00:00.000Z",
      updated_at: "2026-03-17T00:00:00.000Z",
      is_pinned: 0,
    });
    mockDb.getAllAsync.mockResolvedValue([]);

    await createNote({ title: "Title", content: "Content", tagIds: [2, 3] });

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT INTO notes (title, content, created_at, updated_at) VALUES (?, ?, ?, ?)",
      "Title",
      "Content",
      "2026-03-17T00:00:00.000Z",
      "2026-03-17T00:00:00.000Z",
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "DELETE FROM notes_tags WHERE note_id = ?",
      7,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      7,
      2,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      7,
      3,
    );

    nowSpy.mockRestore();
  });

  it("updates note and updates tag links", async () => {
    const nowSpy = jest
      .spyOn(Date.prototype, "toISOString")
      .mockReturnValue("2026-03-17T00:00:00.000Z");

    mockDb.getFirstAsync.mockResolvedValue({
      id: 5,
      title: "Updated",
      content: "Text",
      created_at: "2026-03-17T00:00:00.000Z",
      updated_at: "2026-03-17T00:00:00.000Z",
      is_pinned: 0,
    });
    mockDb.getAllAsync.mockResolvedValue([]);

    await updateNote(5, { title: "Updated", content: "Text", tagIds: [1] });

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "UPDATE notes SET title = ?, content = ?, updated_at = ? WHERE id = ?",
      "Updated",
      "Text",
      "2026-03-17T00:00:00.000Z",
      5,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "DELETE FROM notes_tags WHERE note_id = ?",
      5,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      5,
      1,
    );

    nowSpy.mockRestore();
  });

  it("sets note tags by replacing old links", async () => {
    await setNoteTags(9, [2, 2, 4]);

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "DELETE FROM notes_tags WHERE note_id = ?",
      9,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      9,
      2,
    );
    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      9,
      4,
    );
  });

  it("lists tags alphabetically", async () => {
    mockDb.getAllAsync.mockResolvedValue([]);

    await listTags();

    expect(mockDb.getAllAsync).toHaveBeenCalledWith(
      "SELECT id, name FROM tags ORDER BY name COLLATE NOCASE ASC",
    );
  });

  it("creates tag and reads it back", async () => {
    mockDb.runAsync.mockResolvedValue(undefined);
    mockDb.getFirstAsync.mockResolvedValue({ id: 2, name: "Work" });

    const tag = await createTag("Work");

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "INSERT OR IGNORE INTO tags (name) VALUES (?)",
      "Work",
    );
    expect(mockDb.getFirstAsync).toHaveBeenCalledWith(
      "SELECT id, name FROM tags WHERE name = ?",
      "Work",
    );
    expect(tag).toEqual({ id: 2, name: "Work" });
  });

  it("deletes note by id", async () => {
    mockDb.runAsync.mockResolvedValue(undefined);

    await deleteNote(3);

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "DELETE FROM notes WHERE id = ?",
      3,
    );
  });

  it("toggles pin status and returns updated note", async () => {
    mockDb.getFirstAsync
      .mockResolvedValueOnce({
        id: 4,
        title: "A",
        content: "B",
        created_at: "2026-03-17T00:00:00.000Z",
        updated_at: "2026-03-17T00:00:00.000Z",
        is_pinned: 0,
      })
      .mockResolvedValueOnce({
        id: 4,
        title: "A",
        content: "B",
        created_at: "2026-03-17T00:00:00.000Z",
        updated_at: "2026-03-17T00:00:00.000Z",
        is_pinned: 1,
      });
    mockDb.getAllAsync.mockResolvedValue([]);

    await togglePinNote(4);

    expect(mockDb.runAsync).toHaveBeenCalledWith(
      "UPDATE notes SET is_pinned = ? WHERE id = ?",
      1,
      4,
    );
  });
});
