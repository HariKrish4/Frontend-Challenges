import * as SQLite from "expo-sqlite";

const DATABASE_NAME = "notes.db";

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;
let initializationPromise: Promise<void> | null = null;

export async function getDb() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync(DATABASE_NAME);
  }

  return databasePromise;
}

export async function initDb() {
  if (!initializationPromise) {
    initializationPromise = (async () => {
      const db = await getDb();
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          content TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          is_pinned INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS tags (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS notes_tags (
          note_id INTEGER NOT NULL,
          tag_id INTEGER NOT NULL,
          PRIMARY KEY (note_id, tag_id),
          FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
          FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_notes_tags_note_id ON notes_tags(note_id);
        CREATE INDEX IF NOT EXISTS idx_notes_tags_tag_id ON notes_tags(tag_id);
      `);

      // If table exists without is_pinned column, add it
      try {
        await db.execAsync(
          "ALTER TABLE notes ADD COLUMN is_pinned INTEGER DEFAULT 0",
        );
      } catch {
        // Column already exists, ignore error
      }

      await db.execAsync(`
        INSERT OR IGNORE INTO tags (name) VALUES ('Personal');
        INSERT OR IGNORE INTO tags (name) VALUES ('Work');
        INSERT OR IGNORE INTO tags (name) VALUES ('Ideas');
      `);
    })();
  }

  return initializationPromise;
}
