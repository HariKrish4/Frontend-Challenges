import { getDb, initDb } from "@/lib/db";

export type Tag = {
  id: number;
  name: string;
};

export type Note = {
  id: number;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
  is_pinned: number;
  tags: Tag[];
};

type NotePayload = {
  title: string;
  content: string;
  tagIds?: number[];
};

type NoteRow = Omit<Note, "tags">;

type NoteTagRow = {
  note_id: number;
  id: number;
  name: string;
};

function dedupeTagIds(tagIds: number[] = []) {
  return Array.from(new Set(tagIds)).filter((id) => Number.isFinite(id));
}

async function hydrateNotesWithTags(notes: NoteRow[]) {
  if (notes.length === 0) {
    return [] as Note[];
  }

  const db = await getDb();
  const noteIds = notes.map((note) => note.id);
  const placeholders = noteIds.map(() => "?").join(", ");

  const noteTagRows = await db.getAllAsync<NoteTagRow>(
    `SELECT nt.note_id, t.id, t.name
     FROM notes_tags nt
     INNER JOIN tags t ON t.id = nt.tag_id
     WHERE nt.note_id IN (${placeholders})
     ORDER BY t.name COLLATE NOCASE ASC`,
    ...noteIds,
  );

  const tagsByNoteId = new Map<number, Tag[]>();
  for (const row of noteTagRows) {
    const noteTags = tagsByNoteId.get(row.note_id) ?? [];
    noteTags.push({ id: row.id, name: row.name });
    tagsByNoteId.set(row.note_id, noteTags);
  }

  return notes.map((note) => ({
    ...note,
    tags: tagsByNoteId.get(note.id) ?? [],
  }));
}

export async function listTags() {
  await initDb();
  const db = await getDb();

  return db.getAllAsync<Tag>(
    "SELECT id, name FROM tags ORDER BY name COLLATE NOCASE ASC",
  );
}

export async function createTag(name: string) {
  await initDb();
  const db = await getDb();
  const trimmedName = name.trim();

  if (!trimmedName) return null;

  await db.runAsync(
    "INSERT OR IGNORE INTO tags (name) VALUES (?)",
    trimmedName,
  );

  return db.getFirstAsync<Tag>(
    "SELECT id, name FROM tags WHERE name = ?",
    trimmedName,
  );
}

export async function setNoteTags(noteId: number, tagIds: number[]) {
  await initDb();
  const db = await getDb();
  const uniqueTagIds = dedupeTagIds(tagIds);

  await db.runAsync("DELETE FROM notes_tags WHERE note_id = ?", noteId);

  for (const tagId of uniqueTagIds) {
    await db.runAsync(
      "INSERT OR IGNORE INTO notes_tags (note_id, tag_id) VALUES (?, ?)",
      noteId,
      tagId,
    );
  }
}

export async function listNotes(tagFilterIds: number[] = []) {
  await initDb();
  const db = await getDb();
  const uniqueFilterIds = dedupeTagIds(tagFilterIds);

  const noteRows = uniqueFilterIds.length
    ? await db.getAllAsync<NoteRow>(
        `SELECT DISTINCT n.id, n.title, n.content, n.created_at, n.updated_at, n.is_pinned
         FROM notes n
         INNER JOIN notes_tags nt ON nt.note_id = n.id
         WHERE nt.tag_id IN (${uniqueFilterIds.map(() => "?").join(", ")})
         ORDER BY n.is_pinned DESC, datetime(n.updated_at) DESC`,
        ...uniqueFilterIds,
      )
    : await db.getAllAsync<NoteRow>(
        "SELECT id, title, content, created_at, updated_at, is_pinned FROM notes ORDER BY is_pinned DESC, datetime(updated_at) DESC",
      );

  return hydrateNotesWithTags(noteRows);
}

export async function getNoteById(id: number) {
  await initDb();
  const db = await getDb();

  const note = await db.getFirstAsync<NoteRow>(
    "SELECT id, title, content, created_at, updated_at, is_pinned FROM notes WHERE id = ?",
    id,
  );

  if (!note) return null;

  const [hydrated] = await hydrateNotesWithTags([note]);
  return hydrated;
}

export async function createNote(payload: NotePayload) {
  await initDb();
  const db = await getDb();
  const now = new Date().toISOString();

  const result = await db.runAsync(
    "INSERT INTO notes (title, content, created_at, updated_at) VALUES (?, ?, ?, ?)",
    payload.title,
    payload.content,
    now,
    now,
  );

  await setNoteTags(result.lastInsertRowId, payload.tagIds ?? []);

  return getNoteById(result.lastInsertRowId);
}

export async function updateNote(id: number, payload: NotePayload) {
  await initDb();
  const db = await getDb();
  const now = new Date().toISOString();

  await db.runAsync(
    "UPDATE notes SET title = ?, content = ?, updated_at = ? WHERE id = ?",
    payload.title,
    payload.content,
    now,
    id,
  );

  if (payload.tagIds) {
    await setNoteTags(id, payload.tagIds);
  }

  return getNoteById(id);
}

export async function togglePinNote(id: number) {
  await initDb();
  const db = await getDb();

  const note = await getNoteById(id);
  if (!note) return null;

  const newPinStatus = note.is_pinned ? 0 : 1;
  await db.runAsync(
    "UPDATE notes SET is_pinned = ? WHERE id = ?",
    newPinStatus,
    id,
  );

  return getNoteById(id);
}

export async function deleteNote(id: number) {
  await initDb();
  const db = await getDb();

  await db.runAsync("DELETE FROM notes WHERE id = ?", id);
}
