
import React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import RootStack from './src/navigation/RootStack';
import { StatusBar } from 'expo-status-bar';

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <NavigationContainer theme={DefaultTheme}>
        <RootStack />
        <StatusBar style="dark" />
      </NavigationContainer>
    </QueryClientProvider>
  );
}
