
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ErrorState({ message = 'Something went wrong' }: { message?: string }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Error</Text>
      <Text style={styles.subtitle}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, alignItems: 'center' },
  title: { fontSize: 18, fontWeight: '600', color: '#b00020' },
  subtitle: { marginTop: 8, color: '#666' },
});
