
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useFilterStore } from '@store/filters';
import type { BloodGroup } from '@api/types';

const options: (BloodGroup | 'Any')[] = ['Any','A+','A-','B+','B-','AB+','AB-','O+','O-'];

export default function BloodGroupPicker() {
  const bloodGroup = useFilterStore((s) => s.bloodGroup);
  const setBloodGroup = useFilterStore((s) => s.setBloodGroup);

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Blood group</Text>
      <View style={styles.row}>
        {options.map((opt) => (
          <TouchableOpacity key={opt} style={[styles.chip, bloodGroup===opt && styles.chipActive]} onPress={() => setBloodGroup(opt)}>
            <Text style={[styles.chipText, bloodGroup===opt && styles.chipTextActive]}>{opt}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 8 },
  label: { marginBottom: 6, fontWeight: '600' },
  row: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: '#ccc', margin: 4 },
  chipActive: { backgroundColor: '#e91e63', borderColor: '#e91e63' },
  chipText: { color: '#333' },
  chipTextActive: { color: '#fff', fontWeight: '600' },
});
