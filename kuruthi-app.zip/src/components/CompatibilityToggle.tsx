
import React from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
import { useFilterStore } from '@store/filters';

export default function CompatibilityToggle() {
  const compatible = useFilterStore((s) => s.compatible);
  const setCompatible = useFilterStore((s) => s.setCompatible);
  return (
    <View style={styles.container}>
      <Text style={styles.label}>Compatibility filter</Text>
      <Switch value={compatible} onValueChange={setCompatible} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: 8 },
  label: { fontWeight: '600' },
});
