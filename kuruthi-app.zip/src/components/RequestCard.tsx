
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import type { Request } from '@api/types';
import StatusChip from './StatusChip';

export default function RequestCard({ req, onEdit, onCancel }: { req: Request; onEdit?: () => void; onCancel?: () => void }) {
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{req.patient_name} • {req.blood_group}</Text>
        <StatusChip status={req.status} />
      </View>
      <Text style={styles.sub}>Hospital: {req.hospital_name}</Text>
      <Text style={styles.sub}>Deadline: {new Date(req.deadline).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</Text>
      {req.status === 'Requested' && (
        <View style={styles.actions}>
          {onEdit && (
            <TouchableOpacity style={[styles.btn, styles.edit]} onPress={onEdit}><Text style={styles.btnText}>Edit</Text></TouchableOpacity>
          )}
          {onCancel && (
            <TouchableOpacity style={[styles.btn, styles.cancel]} onPress={onCancel}><Text style={styles.btnText}>Cancel</Text></TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginVertical: 6, borderWidth: 1, borderColor: '#eee' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 16, fontWeight: '700' },
  sub: { marginTop: 4, color: '#555' },
  actions: { flexDirection: 'row', gap: 12, marginTop: 8 },
  btn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  edit: { backgroundColor: '#03a9f4' },
  cancel: { backgroundColor: '#f44336' },
  btnText: { color: '#fff', fontWeight: '600' },
});
