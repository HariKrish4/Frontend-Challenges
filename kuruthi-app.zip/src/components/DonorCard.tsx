
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import type { Donor } from '@api/types';

export default function DonorCard({ donor }: { donor: Donor }) {
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.name}>{donor.name}</Text>
        <Text style={styles.badge}>{donor.blood_group}</Text>
      </View>
      <View style={styles.row}>
        {typeof donor.distance_km === 'number' && (
          <Text style={styles.meta}>{donor.distance_km} km</Text>
        )}
        {donor.area && <Text style={styles.meta}>{donor.area}</Text>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginVertical: 6, borderWidth: 1, borderColor: '#eee' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { fontSize: 16, fontWeight: '600' },
  badge: { backgroundColor: '#2196f3', color: '#fff', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, overflow: 'hidden' },
  row: { flexDirection: 'row', gap: 12, marginTop: 8 },
  meta: { color: '#555' },
});
