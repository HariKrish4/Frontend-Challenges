
import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import type { RequestStatus } from '@api/types';

export default function StatusChip({ status }: { status: RequestStatus }) {
  const color =
    status === 'Requested' ? '#607d8b' :
    status === 'Accepted' ? '#ff9800' :
    status === 'Completed' ? '#4caf50' :
    status === 'Expired' ? '#9e9e9e' : '#f44336';
  return (
    <View style={[styles.chip,{ borderColor: color }]}> 
      <Text style={[styles.text,{ color }]}>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  chip: { borderWidth: 1, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 16 },
  text: { fontWeight: '600' },
});
