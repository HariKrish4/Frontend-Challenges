
import { create } from 'zustand';
import type { BloodGroup } from '@api/types';

interface FilterState {
  bloodGroup: BloodGroup | 'Any';
  compatible: boolean;
  setBloodGroup: (bg: BloodGroup | 'Any') => void;
  setCompatible: (c: boolean) => void;
}

export const useFilterStore = create<FilterState>((set) => ({
  bloodGroup: 'Any',
  compatible: true,
  setBloodGroup: (bloodGroup) => set({ bloodGroup }),
  setCompatible: (compatible) => set({ compatible }),
}));
