
export const colors = {
  primary: '#e91e63',
};
