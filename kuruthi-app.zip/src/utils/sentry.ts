
// Enable later when DSN available
// import * as Sentry from 'sentry-expo';
// const dsn = Constants?.expoConfig?.extra?.SENTRY_DSN as string;
// Sentry.init({ dsn, enableInExpoDevelopment: true });
