
import { z } from 'zod';

export const phoneSchema = z.string().regex(/^[6-9]\d{9}$/,{ message: 'Enter 10-digit Indian mobile starting 6-9' });
export const altPhoneSchema = z.string().regex(/^[6-9]\d{9}$/).optional().or(z.literal('').transform(()=>'')).optional();

export const ageSchema = z
  .number({ invalid_type_error: 'Age must be a number' })
  .min(0, { message: 'Age cannot be negative' })
  .max(120, { message: 'Age must be ≤ 120' });

export const deadlineSchema = z.string().refine((iso) => {
  const d = new Date(iso);
  return d.getTime() >= Date.now();
}, { message: 'Deadline must be in the future' });
