
import type { BloodGroup } from '@api/types';

// Return true if donor blood group is compatible with recipient/request blood group
export function isCompatible(donor: BloodGroup, recipient: BloodGroup): boolean {
  const abo = (bg: BloodGroup) => bg.replace('+','').replace('-','');
  const rh = (bg: BloodGroup) => (bg.endsWith('+') ? '+' : '-');

  const dAbo = abo(donor);
  const rAbo = abo(recipient);
  const dRh = rh(donor);
  const rRh = rh(recipient);

  // ABO rules
  const aboOk =
    dAbo === rAbo ||
    (dAbo === 'O') ||
    (rAbo === 'AB');

  // Rh rules: negative can donate to both, positive only to positive
  const rhOk = dRh === '-' || dRh === rRh;

  return aboOk && rhOk;
}
