
export const IST_TIMEZONE = 'Asia/Kolkata';

export function formatIST(isoUtc: string): string {
  try {
    const d = new Date(isoUtc);
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: IST_TIMEZONE,
      year: 'numeric', month: 'short', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    }).format(d);
  } catch {
    return isoUtc;
  }
}

export function nowUtcIso(): string {
  return new Date().toISOString();
}
