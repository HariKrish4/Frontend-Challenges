
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createRequest, listMyRequests, updateRequest, getRequest, revealDonorContact } from '@api/rpc';
import type { Request } from '@api/types';

const PAGE_SIZE = 20;

export function useMyRequests(userId: string) {
  return useInfiniteQuery<Request[], Error>({
    queryKey: ['myRequests', userId],
    queryFn: async ({ pageParam = 1 }) => listMyRequests(userId, pageParam as number, PAGE_SIZE),
    getNextPageParam: (lastPage, pages) => (lastPage.length === PAGE_SIZE ? pages.length + 1 : undefined),
    initialPageParam: 1,
  });
}

export function useRequest(id: string) {
  return useQuery<Request | null, Error>({
    queryKey: ['request', id],
    queryFn: () => getRequest(id),
  });
}

export function useCreateRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: createRequest,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['myRequests'] });
    },
  });
}

export function useUpdateRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<Request> }) => updateRequest(id, patch),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['myRequests'] });
      qc.invalidateQueries({ queryKey: ['request'] });
    },
  });
}

export function useRevealDonorContact() {
  return useMutation({
    mutationFn: (requestId: string) => revealDonorContact(requestId),
  });
}
