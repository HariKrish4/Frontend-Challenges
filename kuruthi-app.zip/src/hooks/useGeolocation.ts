
import * as Location from 'expo-location';
import { useEffect, useState } from 'react';

export function useGeolocation() {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<'granted'|'denied'|'undetermined'>('undetermined');
  const [error, setError] = useState<string|undefined>();

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setPermissionStatus(status === 'granted' ? 'granted' : 'denied');
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        setCoords({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      } catch (e: any) {
        setError(e?.message ?? 'Location error');
      }
    })();
  }, []);

  return { coords, permissionStatus, error };
}
