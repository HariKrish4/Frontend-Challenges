
import { useInfiniteQuery } from '@tanstack/react-query';
import { rpcDonorsNearby } from '@api/rpc';
import { useFilterStore } from '@store/filters';
import type { BloodGroup, Donor } from '@api/types';

export function useDonors(location: { lat: number | null; lng: number | null }) {
  const bloodGroup = useFilterStore((s) => s.bloodGroup);
  const compatible = useFilterStore((s) => s.compatible);

  return useInfiniteQuery<Donor[], Error>({
    queryKey: ['donors', location, bloodGroup, compatible],
    queryFn: async ({ pageParam = 1 }) => {
      const bg = bloodGroup === 'Any' ? null : (bloodGroup as BloodGroup);
      return rpcDonorsNearby({
        lat: location.lat,
        lng: location.lng,
        blood_group: bg,
        compatible,
        page: pageParam as number,
        pageSize: 20,
      });
    },
    getNextPageParam: (lastPage, pages) => (lastPage.length === 20 ? pages.length + 1 : undefined),
    initialPageParam: 1,
  });
}
