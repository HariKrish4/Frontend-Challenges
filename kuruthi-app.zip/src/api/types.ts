
export type BloodGroup =
  | 'A+'
  | 'A-'
  | 'B+'
  | 'B-'
  | 'AB+'
  | 'AB-'
  | 'O+'
  | 'O-';

export interface Donor {
  id: string;
  name: string;
  blood_group: BloodGroup;
  area: string | null;
  lat: number | null;
  lng: number | null;
  distance_km?: number; // computed by RPC or client
}

export type RequestStatus = 'Requested' | 'Accepted' | 'Completed' | 'Expired' | 'Cancelled';

export interface Request {
  id: string;
  user_id: string;
  patient_name: string;
  age?: number | null;
  patient_id?: string | null;
  contact_person: string;
  contact_phone: string;
  alternate_phone?: string | null;
  hospital_name: string;
  address?: string | null;
  blood_group: BloodGroup;
  deadline: string; // UTC ISO
  reason: string;
  lat?: number | null;
  lng?: number | null;
  status: RequestStatus;
  created_at: string; // UTC ISO
  accepted_at?: string | null;
  completed_at?: string | null;
}
