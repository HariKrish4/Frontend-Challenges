
import { supabase } from './supabase';
import type { BloodGroup, Donor, Request } from './types';

export async function rpcDonorsNearby(params: {
  lat: number | null;
  lng: number | null;
  blood_group: BloodGroup | null;
  compatible: boolean;
  page: number;
  pageSize: number;
}): Promise<Donor[]> {
  // Expect an RPC that returns donors sorted by distance and includes distance_km
  const { data, error } = await supabase.rpc('donors_nearby', {
    lat: params.lat,
    lng: params.lng,
    blood_group: params.blood_group,
    compatible: params.compatible,
    page: params.page,
    page_size: params.pageSize,
  });
  if (error) throw error;
  return (data ?? []) as Donor[];
}

export async function revealDonorContact(requestId: string): Promise<{ phone: string } | null> {
  const { data, error } = await supabase.rpc('reveal_donor_contact', { request_id: requestId });
  if (error) throw error;
  return data as { phone: string } | null;
}

export async function createRequest(payload: Partial<Request>): Promise<Request> {
  const { data, error } = await supabase.from('requests').insert(payload).select('*').single();
  if (error) throw error;
  return data as Request;
}

export async function updateRequest(id: string, patch: Partial<Request>): Promise<Request> {
  const { data, error } = await supabase.from('requests').update(patch).eq('id', id).select('*').single();
  if (error) throw error;
  return data as Request;
}

export async function listMyRequests(userId: string, page: number, pageSize: number): Promise<Request[]> {
  const { data, error } = await supabase
    .from('requests')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .range((page - 1) * pageSize, page * pageSize - 1);
  if (error) throw error;
  return (data ?? []) as Request[];
}

export async function getRequest(id: string): Promise<Request | null> {
  const { data, error } = await supabase.from('requests').select('*').eq('id', id).single();
  if (error) throw error;
  return data as Request;
}
