
import { createClient } from '@supabase/supabase-js';
import Constants from 'expo-constants';

const url = Constants?.expoConfig?.extra?.KURUTHI_SUPABASE_URL as string;
const anon = Constants?.expoConfig?.extra?.KURUTHI_SUPABASE_ANON_KEY as string;

export const supabase = createClient(url, anon, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});
