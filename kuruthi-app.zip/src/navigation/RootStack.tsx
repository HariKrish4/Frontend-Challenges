
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Tabs from './Tabs';
import RequestDetailScreen from '@screens/RequestDetailScreen';
import CreateRequestScreen from '@screens/CreateRequestScreen';

export type RootStackParamList = {
  Tabs: undefined;
  RequestDetail: { id: string };
  CreateRequest: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
      <Stack.Screen name="CreateRequest" component={CreateRequestScreen} options={{ title: 'Create Request' }} />
      <Stack.Screen name="RequestDetail" component={RequestDetailScreen} options={{ title: 'Request Detail' }} />
    </Stack.Navigator>
  );
}
