
import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { z } from 'zod';
import { phoneSchema, deadlineSchema } from '@utils/validation';
import type { BloodGroup, Request } from '@api/types';
import { useCreateRequest } from '@hooks/useRequests';
import { useNavigation } from '@react-navigation/native';
import { useGeolocation } from '@hooks/useGeolocation';

const bgOptions: BloodGroup[] = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];

const schema = z.object({
  patient_name: z.string().min(1, 'Patient name is required'),
  age: z.preprocess((v) => {
    const s = String(v ?? '').trim();
    if (s === '') return undefined; // optional
    const n = Number(s);
    return Number.isFinite(n) ? n : undefined;
  }, z.number().min(0, { message: 'Age cannot be negative' }).max(120, { message: 'Age must be ≤ 120' }).optional()),
  patient_id: z.string().optional(),
  contact_person: z.string().min(1, 'Contact person is required'),
  contact_phone: phoneSchema,
  alternate_phone: z.string().optional(),
  hospital_name: z.string().min(1, 'Hospital name is required'),
  address: z.string().optional(),
  blood_group: z.enum(bgOptions as any),
  deadline: deadlineSchema,
  reason: z.string().min(1, 'Reason is required'),
});

export default function CreateRequestScreen() {
  const nav = useNavigation();
  const { coords } = useGeolocation();
  const { mutateAsync, isPending } = useCreateRequest();
  const [form, setForm] = useState<any>({ blood_group: 'O+', deadline: new Date().toISOString() });
  const [errors, setErrors] = useState<Record<string,string>>({});

  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }));

  const submit = async () => {
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const errs: Record<string,string> = {};
      parsed.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
      setErrors(errs);
      return;
    }
    const payload: Partial<Request> = {
      ...parsed.data,
      lat: coords?.lat ?? null,
      lng: coords?.lng ?? null,
      status: 'Requested',
      created_at: new Date().toISOString(),
    };
    try {
      const created = await mutateAsync(payload);
      // Navigate to My Requests tab
      // @ts-ignore nested navigator
      nav.navigate('Tabs', { screen: 'MyRequests' });
      Alert.alert('Success', 'Request created');
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to create');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Create Request</Text>

      {[
        ['patient_name','Patient Name*'],
        ['age','Age'],
        ['patient_id','Patient ID'],
        ['contact_person','Contact Person*'],
        ['contact_phone','Contact Phone*'],
        ['alternate_phone','Alternate Phone'],
        ['hospital_name','Hospital Name*'],
        ['address','Address'],
        ['reason','Reason*'],
      ].map(([key,label]) => (
        <View key={key} style={styles.field}>
          <Text style={styles.label}>{label}</Text>
          <TextInput
            style={[styles.input, errors[key] && styles.inputError]}
            value={form[key] ?? ''}
            onChangeText={(t) => set(key, t)}
            keyboardType={key.includes('phone') ? 'phone-pad' : key === 'age' ? 'number-pad' : 'default'}
          />
          {errors[key] && <Text style={styles.err}>{errors[key]}</Text>}
        </View>
      ))}

      <View style={styles.field}>
        <Text style={styles.label}>Blood Group*</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {bgOptions.map((bg) => (
            <TouchableOpacity key={bg} style={[styles.chip, form.blood_group===bg && styles.chipActive]} onPress={() => set('blood_group', bg)}>
              <Text style={[styles.chipText, form.blood_group===bg && styles.chipTextActive]}>{bg}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.field}>
        <Text style={styles.label}>Deadline* (UTC ISO)</Text>
        <TextInput style={[styles.input, errors['deadline'] && styles.inputError]} value={form.deadline ?? ''} onChangeText={(t) => set('deadline', t)} />
        {errors['deadline'] && <Text style={styles.err}>{errors['deadline']}</Text>}
        <Text style={{ color: '#666', marginTop: 4 }}>Stored in UTC; shown in IST elsewhere.</Text>
      </View>

      <TouchableOpacity style={styles.submit} onPress={submit} disabled={isPending}>
        <Text style={styles.submitText}>{isPending ? 'Submitting...' : 'Create Request'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  header: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
  field: { marginBottom: 12 },
  label: { marginBottom: 6, fontWeight: '600' },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 8 },
  inputError: { borderColor: '#f44336' },
  err: { color: '#f44336', marginTop: 4 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: '#ccc', margin: 4 },
  chipActive: { backgroundColor: '#4caf50', borderColor: '#4caf50' },
  chipText: { color: '#333' },
  chipTextActive: { color: '#fff', fontWeight: '600' },
  submit: { backgroundColor: '#e91e63', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  submitText: { color: '#fff', fontWeight: '700' },
});
