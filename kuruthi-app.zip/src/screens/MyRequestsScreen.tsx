
import React from 'react';
import { View, FlatList, ActivityIndicator, Alert } from 'react-native';
import RequestCard from '@components/RequestCard';
import { useMyRequests, useUpdateRequest } from '@hooks/useRequests';
import type { Request } from '@api/types';

// For demo: use a fixed user id; replace with auth user
const CURRENT_USER_ID = 'demo-user-id';

export default function MyRequestsScreen() {
  const { data, isLoading, isError, error, fetchNextPage, hasNextPage, isFetchingNextPage } = useMyRequests(CURRENT_USER_ID);
  const { mutateAsync } = useUpdateRequest();

  const items: Request[] = data?.pages.flat() ?? [];

  return (
    <View style={{ flex: 1, padding: 12 }}>
      {isLoading && <ActivityIndicator style={{ marginTop: 24 }} />}
      {isError && Alert.alert('Error', error?.message ?? 'Failed to load')}
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RequestCard
            req={item}
            onEdit={() => Alert.alert('Edit', 'Implement edit form screen')}
            onCancel={async () => {
              try { await mutateAsync({ id: item.id, patch: { status: 'Cancelled' } }); }
              catch (e: any) { Alert.alert('Error', e?.message ?? 'Failed to cancel'); }
            }}
          />
        )}
        onEndReached={() => hasNextPage && fetchNextPage()}
        onEndReachedThreshold={0.6}
        ListFooterComponent={isFetchingNextPage ? <ActivityIndicator /> : null}
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </View>
  );
}
