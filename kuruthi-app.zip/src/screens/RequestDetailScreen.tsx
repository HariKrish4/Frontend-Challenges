
import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity, Alert } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { useRequest, useRevealDonorContact, useUpdateRequest } from '@hooks/useRequests';
import { formatIST } from '@utils/datetime';

export default function RequestDetailScreen() {
  const route = useRoute<any>();
  const id = route.params?.id as string;
  const { data, isLoading, isError, error } = useRequest(id);
  const { mutateAsync: reveal } = useRevealDonorContact();
  const { mutateAsync: update } = useUpdateRequest();

  if (isLoading) return <ActivityIndicator style={{ marginTop: 24 }} />;
  if (isError) return <Text>{error?.message ?? 'Error loading request'}</Text>;
  if (!data) return <Text>Not found</Text>;

  const r = data;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{r.patient_name} • {r.blood_group}</Text>
      <Text style={styles.field}>Hospital: {r.hospital_name}</Text>
      {r.address && <Text style={styles.field}>Address: {r.address}</Text>}
      <Text style={styles.field}>Reason: {r.reason}</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Timestamps</Text>
        <Text>Created: {formatIST(r.created_at)}</Text>
        {r.accepted_at && <Text>Accepted: {formatIST(r.accepted_at)}</Text>}
        {r.completed_at && <Text>Completed: {formatIST(r.completed_at)}</Text>}
      </View>

      {r.status === 'Accepted' && (
        <TouchableOpacity style={styles.btn} onPress={async () => {
          try {
            const contact = await reveal(r.id);
            if (contact?.phone) {
              Alert.alert('Donor Contact', contact.phone);
            } else {
              Alert.alert('Info', 'Contact not available');
            }
          } catch (e: any) {
            Alert.alert('Error', e?.message ?? 'Failed to reveal contact');
          }
        }}>
          <Text style={styles.btnText}>Reveal Donor Contact</Text>
        </TouchableOpacity>
      )}

      {r.status === 'Accepted' && (
        <TouchableOpacity style={[styles.btn, styles.success]} onPress={async () => {
          try { await update({ id: r.id, patch: { status: 'Completed', completed_at: new Date().toISOString() } }); Alert.alert('Marked Completed'); }
          catch (e: any) { Alert.alert('Error', e?.message ?? 'Failed'); }
        }}>
          <Text style={styles.btnText}>Mark Completed</Text>
        </TouchableOpacity>
      )}

      <TouchableOpacity style={[styles.btn, styles.warn]} onPress={async () => {
        try { await update({ id: r.id, patch: { status: 'Expired' } }); Alert.alert('Marked Expired'); }
        catch (e: any) { Alert.alert('Error', e?.message ?? 'Failed'); }
      }}>
        <Text style={styles.btnText}>Mark Expired</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
  field: { marginTop: 6 },
  section: { marginTop: 16 },
  sectionTitle: { fontWeight: '700' },
  btn: { backgroundColor: '#2196f3', padding: 12, borderRadius: 8, alignItems: 'center', marginTop: 12 },
  btnText: { color: '#fff', fontWeight: '700' },
  success: { backgroundColor: '#4caf50' },
  warn: { backgroundColor: '#9e9e9e' },
});
