
import React from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import BloodGroupPicker from '@components/BloodGroupPicker';
import CompatibilityToggle from '@components/CompatibilityToggle';
import DonorCard from '@components/DonorCard';
import EmptyState from '@components/EmptyState';
import ErrorState from '@components/ErrorState';
import { useGeolocation } from '@hooks/useGeolocation';
import { useDonors } from '@hooks/useDonors';

export default function HomeScreen() {
  const { coords, permissionStatus } = useGeolocation();
  const { data, isLoading, isError, error, fetchNextPage, hasNextPage, isFetchingNextPage } = useDonors({
    lat: coords?.lat ?? null,
    lng: coords?.lng ?? null,
  });

  const donors = data?.pages.flat() ?? [];

  return (
    <View style={styles.container}>
      <View style={styles.filters}>
        <BloodGroupPicker />
        <CompatibilityToggle />
      </View>

      {permissionStatus === 'denied' && (
        <View style={styles.banner}><Text style={styles.bannerText}>Location permission denied. Showing donors without distance.</Text></View>
      )}

      {isLoading && <ActivityIndicator style={{ marginTop: 24 }} />}
      {isError && <ErrorState message={error?.message} />}

      {!isLoading && donors.length === 0 && <EmptyState title="No donors found" subtitle="Try changing filters" />}

      <FlatList
        data={donors}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <DonorCard donor={item} />}
        onEndReached={() => hasNextPage && fetchNextPage()}
        onEndReachedThreshold={0.6}
        ListFooterComponent={isFetchingNextPage ? <ActivityIndicator /> : null}
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 12 },
  filters: { marginBottom: 8 },
  banner: { backgroundColor: '#fff3cd', padding: 8, borderRadius: 8, borderWidth: 1, borderColor: '#ffeeba', marginBottom: 8 },
  bannerText: { color: '#856404' },
});
