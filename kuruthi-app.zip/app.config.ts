
import type { ExpoConfig } from 'expo/config';

const config: ExpoConfig = {
  name: 'Kuruthi',
  slug: 'kuruthi',
  scheme: 'kuruthi',
  version: '0.1.0',
  orientation: 'portrait',
  platforms: ['ios', 'android'],
  jsEngine: 'hermes',
  extra: {
    KURUTHI_SUPABASE_URL: process.env.KURUTHI_SUPABASE_URL,
    KURUTHI_SUPABASE_ANON_KEY: process.env.KURUTHI_SUPABASE_ANON_KEY,
    SENTRY_DSN: process.env.SENTRY_DSN,
  },
  plugins: [
    'sentry-expo',
  ],
};

export default config;
