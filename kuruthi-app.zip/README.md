
# Kuruthi (Expo + TypeScript + Supabase)

Kuruthi is a React Native (Expo) app to manage and discover blood donation requests.

## Features
- Bottom tabs: **Home**, **My Requests** (Profile later)
- **Home**: fetch nearby donors from Supabase (REST/RPC), pass user GPS (lat/lng), filter by blood group and compatibility, sort by distance, infinite scroll
- **Create Request**: validated form, silently captures GPS and submits to Supabase
- **My Requests**: list user's requests with status chips; edit/cancel when `Requested`; lazy pagination
- **Request Detail**: view audit timestamps; actions to mark completed/expired; reveal donor contact via RPC only when accepted
- State: **Zustand** (UI) + **React Query** (server state)
- Utilities: Haversine distance, IST display (store UTC), ABO/Rh compatibility
- Quality: EAS builds, env vars for Supabase, Sentry (stubbed)

## Setup
1. **Prerequisites**: Node 18+, Expo CLI, EAS CLI
2. **Clone & install**
   ```bash
   npm i
   ```
3. **Environment (EAS secrets)**: set on build profile
   - `KURUTHI_SUPABASE_URL`
   - `KURUTHI_SUPABASE_ANON_KEY`
   - `SENTRY_DSN` (optional)
4. **Run**
   ```bash
   npx expo start
   ```

### Supabase endpoints expected
> Adjust names to your backend. Provided RPC names are examples.
- `rpc: donors_nearby(lat, lng, blood_group text|null, compatible boolean)` → returns donors with distance_km
- `table: donors` (id, name, blood_group, area, lat, lng, ...)
- `table: requests` (id, user_id, patient_name, ..., blood_group, deadline, reason, lat, lng, status, created_at, accepted_at, completed_at)
- `rpc: reveal_donor_contact(request_id uuid)` → returns phone only if request accepted

## Development Notes
- All timestamps stored **UTC**; display in IST using `Asia/Kolkata` timezone utilities
- Client-side compatibility logic in `src/utils/compatibility.ts` should match backend filtering
- Location: uses `expo-location` with graceful denial fallback

## CI / EAS
- `eas.json` contains profiles
- Add secrets via `eas secret:create --scope project`

## Sentry
- Stubbed via `sentry-expo`; enable by setting `SENTRY_DSN` and uncommenting init in `src/utils/sentry.ts`

