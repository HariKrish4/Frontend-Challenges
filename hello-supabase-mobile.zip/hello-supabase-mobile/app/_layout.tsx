import { AuthProvider, useAuth } from "@/config/auth-context";
import { Stack } from "expo-router";
import React from "react";
import { ActivityIndicator, View } from "react-native";

function RootLayoutContent() {
  const { session, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#3b82f6" />
      </View>
    );
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      {session ? <Stack.Screen name="home" /> : <Stack.Screen name="signin" />}
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <AuthProvider>
      <RootLayoutContent />
    </AuthProvider>
  );
}
