# Debugging Guide

## Common Issues & Solutions

### 1. Supabase Connection Issues

#### Error: "Missing Supabase credentials"

**Cause**: Environment variables not set

**Solution**:
1. Create `.env.local` in project root
2. Add credentials from your Supabase dashboard:
   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```
3. Restart the development server

#### Error: "Connection refused"

**Cause**: Invalid Supabase URL

**Solution**:
- Copy the exact URL from Supabase Settings > API
- Include the full `https://` URL
- Check for typos

#### Error: "Invalid API key"

**Cause**: Wrong API key used

**Solution**:
- Use the **Anon Key** (not Service Role Key)
- Copy from Supabase Settings > API > "anon" row
- Paste exactly as shown in the dashboard

### 2. Authentication Issues

#### Error: "User not found" or "Invalid credentials"

**Solution**:
1. Verify user exists in Supabase Auth
2. Check email and password are correct
3. Create a new test account if needed
4. Go to Supabase > Authentication > Users to manage accounts

#### Error: "Email already exists"

**Cause**: Account already registered

**Solution**:
1. Use a different email
2. Or sign in with existing credentials
3. Delete the test user from Supabase dashboard if needed

#### Session expires immediately

**Cause**: AsyncStorage not working properly

**Solution**:
1. Check `@react-native-async-storage/async-storage` is installed
2. Verify AsyncStorage is properly configured in `config/supabase.ts`
3. On web, check browser LocalStorage is enabled
4. Clear app cache and restart

### 3. Database Issues

#### Error: "relation "todos" does not exist"

**Cause**: Table not created in database

**Solution**:
1. Go to Supabase SQL Editor
2. Run the SQL from `SETUP.md` to create the table
3. Verify table exists in Supabase Tables view

#### Error: "permission denied for relation todos"

**Cause**: Row Level Security (RLS) policies not configured

**Solution**:
1. Enable RLS on todos table (if not enabled)
2. Create the policies from `SETUP.md`
3. Verify policies match the SQL provided

#### Error: "new row violates row-level security policy"

**Cause**: User doesn't have permission to perform the operation

**Solution**:
1. Verify user is authenticated (`authService.getCurrentUser()`)
2. Check RLS policy user_id matches auth.uid()
3. Go to Supabase > Authentication to verify user exists
4. Check policy syntax in SQL Editor

#### Todos not appearing

**Solution**:
1. Check todos exist in Supabase > todos table
2. Verify you're querying the right user's todos
3. Check RLS policies allow SELECT for the user
4. Clear app cache and refresh

### 4. Real-time Subscription Issues

#### Real-time updates not working

**Cause**: Replication not enabled or subscriptions not configured

**Solution**:
1. Check Supabase project has replication enabled
2. Verify webhook or publication is configured
3. Check that `subscribeToTodos()` is being called
4. Verify RLS policies allow the operations

#### Error: "channel subscription failed"

**Cause**: Invalid channel configuration

**Solution**:
1. Check channel name in `config/api.ts`
2. Verify table name is correct
3. Check event types are valid ('*', 'INSERT', 'UPDATE', 'DELETE')

### 5. UI/Navigation Issues

#### Stuck on sign-in screen after signing in

**Cause**: Auth state not updating properly

**Solution**:
1. Check `auth-context.tsx` is wrapping the app
2. Verify `useAuth()` hook is being used
3. Check browser console for errors
4. Restart the development server

#### Blank screen or white screen

**Cause**: Navigation misconfiguration

**Solution**:
1. Check `app/_layout.tsx` exports correctly
2. Verify file naming follows Expo Router conventions
3. Check `app.json` has correct entry point
4. Clear metro cache: `yarn start --reset-cache`

#### Styles not applying

**Solution**:
1. Check StyleSheet is imported from `react-native`
2. Verify style names are correct (camelCase)
3. Check colors are valid hex or named values
4. Clear app cache and rebuild

### 6. Build & Deployment Issues

#### Error: "Module not found"

**Cause**: Missing dependency or incorrect import

**Solution**:
1. Check import paths use `@/` alias correctly
2. Verify the file exists at that path
3. Install missing package: `yarn add package-name`
4. Restart development server

#### Error: "Cannot find module '@types/node'"

**Cause**: Type definitions missing

**Solution**:
```bash
yarn add --dev @types/node
```

#### Build fails on EAS

**Solution**:
1. Run `yarn lint` locally first
2. Fix any TypeScript or eslint errors
3. Commit changes to git
4. Try `eas build --platform ios` or `--platform android`
5. Check EAS logs for detailed errors

### 7. Performance Issues

#### App is slow or freezes

**Cause**: Too many re-renders or large dataset

**Solution**:
1. Check if `useTodos()` is being overused
2. Implement pagination for large todo lists
3. Use `React.memo()` for expensive components
4. Check for unnecessary useEffect dependencies

#### FlatList scrolling is sluggish

**Solution**:
1. Add `removeClippedSubviews={true}` to FlatList
2. Implement `getItemLayout` for better performance
3. Use `useMemo()` for computed data
4. Optimize re-renders with `React.memo`

### 8. TypeScript Errors

#### Error: "Property does not exist on type"

**Solution**:
1. Check type definitions are correct in `types/index.ts`
2. Verify object properties match the type
3. Use optional chaining: `?.` for optional properties
4. Add type guards for dynamic properties

#### Error: "Cannot assign type X to type Y"

**Solution**:
1. Check types match exactly
2. Convert types using `as` if absolutely necessary
3. Use proper type inference
4. Check for null/undefined before using

### 9. Testing the App

#### How to test authentication:

1. **Create a test account**:
   - Sign up with test email
   - Go to Supabase > Authentication > Users to verify

2. **Test sign in**:
   - Close and reopen app
   - Should stay logged in (session persisted)

3. **Test sign out**:
   - Should return to sign-in screen
   - Session should be cleared

#### How to test todos:

1. **Create a todo**:
   - Type in the input
   - Tap the plus button
   - Todo should appear in list

2. **Toggle completion**:
   - Tap checkbox
   - Text should show strikethrough
   - Should update in database

3. **Delete a todo**:
   - Tap trash icon
   - Should be removed from list
   - Should be deleted in database

## Debugging Tools

### Console Logging

Add to any file:
```typescript
console.log('Debug message:', value);
console.error('Error message:', error);
console.warn('Warning message:', warning);
```

View logs in Expo console or metro debugger.

### React Native Debugger

```bash
npm install -g react-native-debugger
react-native-debugger
```

### Supabase Dashboard

1. Monitor in real-time:
   - Authentication > Users (view all users)
   - SQL Editor (run queries)
   - Database > Logs (check errors)
   - Realtime (view subscriptions)

2. Create test data:
   - Use SQL Editor to insert test todos
   - Verify RLS policies work

### Network Tab

In Expo Go app:
1. Shake device to open dev menu
2. Choose "Network Tab"
3. Monitor all API requests and responses

### TypeScript Checking

```bash
# Check for TypeScript errors
yarn tsc --noEmit
```

## Getting Help

1. **Check the documentation**:
   - `README.md` - Overview
   - `SETUP.md` - Setup instructions
   - `QUICKSTART.md` - Quick reference

2. **Review error messages** - they usually point to the problem

3. **Check Supabase status** - [status.supabase.com](https://status.supabase.com)

4. **Review relevant code**:
   - `config/api.ts` - API operations
   - `config/auth-context.tsx` - Auth state
   - `hooks/useTodos.ts` - Todo operations

5. **Useful resources**:
   - [Supabase Docs](https://supabase.com/docs)
   - [Expo Docs](https://docs.expo.dev/)
   - [React Native Docs](https://reactnative.dev/)

## Common Fixes

**Always try these first**:
1. Clear cache: `yarn start --reset-cache`
2. Restart dev server
3. Clear app cache (app settings > Storage)
4. Verify environment variables are set
5. Check Supabase project status

**Reset everything**:
```bash
yarn install  # Fresh install
rm -rf node_modules
rm yarn.lock
yarn install
yarn start --reset-cache
```

---

**Still stuck?** Check the error message in the console - it usually tells you exactly what went wrong! 🐛
