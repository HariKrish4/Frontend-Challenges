import { supabase } from './supabase';

export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface Todo {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
}

// Auth Functions
export const authService = {
  async signUp(email: string, password: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });
    if (error) throw error;
    return data;
  },

  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
    return data;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  async getCurrentUser() {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error) throw error;
    return user;
  },

  async resetPassword(email: string) {
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    if (error) throw error;
  },
};

// Todo Functions
export const todoService = {
  async getTodos() {
    const { data, error } = await supabase
      .from('todos_mobile')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data as Todo[];
  },

  async createTodo(title: string, description?: string) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('todos_mobile')
      .insert([
        {
          title,
          description,
          user_id: user.id,
          completed: false,
        },
      ])
      .select();
    if (error) throw error;
    return data?.[0] as Todo;
  },

  async updateTodo(id: string, updates: Partial<Todo>) {
    const { data, error } = await supabase
      .from('todos_mobile')
      .update(updates)
      .eq('id', id)
      .select();
    if (error) throw error;
    return data?.[0] as Todo;
  },

  async deleteTodo(id: string) {
    const { error } = await supabase.from('todos_mobile').delete().eq('id', id);
    if (error) throw error;
  },

  async toggleTodo(id: string, completed: boolean) {
    return this.updateTodo(id, { completed });
  },
};

// Real-time Subscriptions
export const subscribeToTodos = (
  callback: (todos: Todo[]) => void,
  onError?: (error: Error) => void
) => {
  const subscription = supabase
    .channel('todos-channel')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'todos_mobile',
      },
      async (payload: any) => {
        // Fetch all todos again to keep state in sync
        try {
          const todos = await todoService.getTodos();
          callback(todos);
        } catch (error) {
          onError?.(error as Error);
        }
      }
    )
    .subscribe();

  return subscription;
};
