# Hello Supabase Mobile

A React Native (Expo, TypeScript) mobile app demonstrating Supabase backend integration with authentication and real-time database operations.

## Features

- 🔐 **Authentication** - Sign up and sign in with Supabase Auth
- 📝 **Todo Management** - Create, read, update, and delete todos
- ⚡ **Real-time Sync** - Real-time database subscriptions
- 💾 **Persistent Sessions** - Secure session storage with AsyncStorage
- 🎨 **Beautiful UI** - Clean and intuitive user interface
- 📱 **Cross-platform** - Works on iOS, Android, and Web

## Prerequisites

Before you begin, ensure you have:

- Node.js (v18+) and npm/yarn installed
- An Expo account (free at [expo.dev](https://expo.dev))
- A Supabase account (free at [supabase.com](https://supabase.com))
- Expo Go app installed on your mobile device (optional, for testing)

## Setup Instructions

### 1. Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign up/sign in
2. Click "New Project" and fill in the details
3. Wait for the project to be created
4. Go to Settings > API to find:
   - Project URL
   - Anon Key (public)

### 2. Create Database Tables

In your Supabase project dashboard, go to SQL Editor and run:

```sql
-- Create todos table
CREATE TABLE todos_mobile (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users (id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE todos_mobile ENABLE ROW LEVEL SECURITY;

-- Create policy for users to see their own todos
CREATE POLICY "Users can view their own todos" ON todos_mobile
  FOR SELECT USING (auth.uid() = user_id);

-- Create policy for users to insert their own todos
CREATE POLICY "Users can insert their own todos" ON todos_mobile
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Create policy for users to update their own todos
CREATE POLICY "Users can update their own todos" ON todos_mobile
  FOR UPDATE USING (auth.uid() = user_id);

-- Create policy for users to delete their own todos
CREATE POLICY "Users can delete their own todos" ON todos_mobile
  FOR DELETE USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX todos_user_id_idx ON todos_mobile(user_id);
CREATE INDEX todos_created_at_idx ON todos_mobile(created_at);
```

### 3. Configure Environment Variables

Create a `.env.local` file in the project root:

```bash
EXPO_PUBLIC_SUPABASE_URL=your_project_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
```

### 4. Install Dependencies

```bash
yarn install
# or
npm install
```

## Running the App

### Start the development server:

```bash
yarn start
# or
npm start
```

### Run on different platforms:

**iOS:**
```bash
yarn ios
# or press 'i' in the Expo CLI
```

**Android:**
```bash
yarn android
# or press 'a' in the Expo CLI
```

**Web:**
```bash
yarn web
# or press 'w' in the Expo CLI
```

## Project Structure

```
hello-supabase-mobile/
├── app/
│   ├── _layout.tsx          # Root layout with auth navigation
│   ├── signin.tsx           # Sign in/up screen
│   └── home.tsx             # Main todo list screen
├── config/
│   ├── supabase.ts          # Supabase client setup
│   ├── api.ts               # API functions for todos and auth
│   └── auth-context.tsx     # React context for auth state
├── components/              # Reusable components
├── .env.local              # Environment variables (create from template)
├── app.json                # Expo app configuration
├── package.json            # Project dependencies
└── tsconfig.json           # TypeScript configuration
```

## Usage

### Sign Up / Sign In

1. Open the app
2. Enter your email and password
3. Tap "Sign In" to log in or "Create Account" to register
4. After authentication, you'll be taken to the home screen

### Manage Todos

- **Add Todo**: Type in the input field and tap the plus button
- **Toggle Completion**: Tap the checkbox next to a todo
- **Delete Todo**: Tap the trash icon
- **Sign Out**: Tap the logout icon in the header

## Key Files

### [config/supabase.ts](config/supabase.ts)
Initializes the Supabase client with proper configuration for React Native:
- URL Polyfill for React Native
- AsyncStorage for session persistence
- Auto token refresh enabled

### [config/api.ts](config/api.ts)
Provides service functions for:
- User authentication (sign up, sign in, sign out)
- Todo CRUD operations
- Real-time subscriptions

### [config/auth-context.tsx](config/auth-context.tsx)
React Context for managing global auth state:
- Persists session across app restarts
- Listens for auth state changes
- Provides auth functions to components

## Development Tips

- Use the Expo CLI for fast development and testing
- AsyncStorage persists your session, so you stay logged in after closing the app
- Modify the styles in each screen file to customize the UI
- Add more features by creating new tables and API functions

## Common Issues & Solutions

### "Missing Supabase credentials" warning
- Make sure `.env.local` file exists with correct credentials
- Credentials should be from your Supabase project dashboard

### "Auth user is null" errors
- Check that authentication table exists in Supabase
- Verify Row Level Security (RLS) policies are configured correctly

### Database queries fail
- Ensure `todos` table exists
- Check RLS policies allow the operations
- Verify user is authenticated before making requests

## Deployment

To build and deploy for production:

```bash
# Build for iOS
eas build --platform ios

# Build for Android
eas build --platform android

# Submit to app stores
eas submit --platform ios
eas submit --platform android
```

See [Expo EAS documentation](https://docs.expo.dev/eas/) for more details.

## Resources

- [Supabase Documentation](https://supabase.com/docs)
- [Expo Documentation](https://docs.expo.dev/)
- [React Native Documentation](https://reactnative.dev/)
- [React Native + Supabase Guide](https://supabase.com/docs/guides/getting-started/tutorials/with-expo-react-native)

## License

MIT
