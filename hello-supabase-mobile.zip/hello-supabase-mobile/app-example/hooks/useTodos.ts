import { todoService } from '@/config/api';
import { Todo } from '@/types';
import { useCallback, useEffect, useState } from 'react';

export function useTodos() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load all todos
  const loadTodos = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await todoService.getTodos();
      setTodos(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    loadTodos();
  }, [loadTodos]);

  // Add todo
  const addTodo = useCallback(
    async (title: string, description?: string) => {
      try {
        const newTodo = await todoService.createTodo(title, description);
        setTodos((prev) => [newTodo, ...prev]);
        return newTodo;
      } catch (err: any) {
        setError(err.message);
        throw err;
      }
    },
    []
  );

  // Update todo
  const updateTodo = useCallback(
    async (id: string, updates: Partial<Todo>) => {
      try {
        const updated = await todoService.updateTodo(id, updates);
        setTodos((prev) =>
          prev.map((t) => (t.id === id ? updated : t))
        );
        return updated;
      } catch (err: any) {
        setError(err.message);
        throw err;
      }
    },
    []
  );

  // Toggle todo completion
  const toggleTodo = useCallback(
    async (id: string, completed: boolean) => {
      return updateTodo(id, { completed });
    },
    [updateTodo]
  );

  // Delete todo
  const deleteTodo = useCallback(async (id: string) => {
    try {
      await todoService.deleteTodo(id);
      setTodos((prev) => prev.filter((t) => t.id !== id));
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  }, []);

  // Refresh todos
  const refresh = useCallback(async () => {
    return loadTodos();
  }, [loadTodos]);

  // Clear error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    todos,
    isLoading,
    error,
    addTodo,
    updateTodo,
    toggleTodo,
    deleteTodo,
    refresh,
    clearError,
  };
}

export function useFilteredTodos(
  todos: Todo[],
  filter: 'all' | 'completed' | 'pending' = 'all'
) {
  return todos.filter((todo) => {
    if (filter === 'completed') return todo.completed;
    if (filter === 'pending') return !todo.completed;
    return true;
  });
}

export function useSearchTodos(todos: Todo[], searchText: string) {
  return todos.filter(
    (todo) =>
      todo.title.toLowerCase().includes(searchText.toLowerCase()) ||
      (todo.description?.toLowerCase().includes(searchText.toLowerCase()) ?? false)
  );
}
