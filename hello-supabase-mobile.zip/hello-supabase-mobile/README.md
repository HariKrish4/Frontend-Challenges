# Hello Supabase Mobile

A production-ready React Native (Expo, TypeScript) mobile application demonstrating comprehensive Supabase backend integration. This app features user authentication, real-time database operations, and a beautiful todo management interface.

## ✨ Features

- **🔐 Authentication**: Sign up and sign in with Supabase Auth
- **📝 Todo Management**: Create, read, update, and delete todos with real-time sync
- **⚡ Real-time Updates**: Real-time database subscriptions for live data
- **💾 Persistent Sessions**: Secure session storage using AsyncStorage
- **🎨 Beautiful UI**: Clean, intuitive, and responsive user interface
- **📱 Cross-platform**: Works seamlessly on iOS, Android, and Web
- **🔒 Type-safe**: Full TypeScript support for better developer experience
- **🏗️ Production-ready**: Proper error handling, loading states, and validation

## 📦 Tech Stack

- **Frontend**: React Native, Expo, TypeScript
- **Backend**: Supabase (PostgreSQL, Auth, Real-time)
- **State Management**: React Context API
- **Storage**: AsyncStorage (persistent sessions)
- **Navigation**: Expo Router
- **UI Components**: React Native built-in components

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn
- Expo CLI: `npm install -g expo-cli`
- Supabase account (free at [supabase.com](https://supabase.com))

### Installation

1. **Clone or navigate to the project**

   ```bash
   cd hello-supabase-mobile
   ```

2. **Install dependencies**

   ```bash
   yarn install
   # or
   npm install
   ```

3. **Set up Supabase**

   - Create a new project at [supabase.com](https://supabase.com)
   - Go to Settings > API to get your Project URL and Anon Key
   - Create a `.env.local` file in the root directory:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=your_project_url
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
   ```

4. **Create database tables**

   In your Supabase project, go to SQL Editor and run the SQL from [SETUP.md](./SETUP.md#3-create-database-tables)

5. **Start the development server**

   ```bash
   yarn start
   # or
   npm start
   ```

6. **Run on your device or emulator**

   - **iOS**: Press `i`
   - **Android**: Press `a`
   - **Web**: Press `w`

## 📁 Project Structure

```
hello-supabase-mobile/
├── app/                          # Expo Router screens
│   ├── _layout.tsx              # Root layout with auth navigation
│   ├── signin.tsx               # Sign in/up screen
│   └── home.tsx                 # Main todo list screen
│
├── config/
│   ├── supabase.ts              # Supabase client initialization
│   ├── api.ts                   # API service layer for todos and auth
│   └── auth-context.tsx         # React Context for auth state
│
├── hooks/
│   └── useTodos.ts              # Custom hook for todo operations
│
├── utils/
│   └── helpers.ts               # Utility functions
│
├── types/
│   └── index.ts                 # TypeScript type definitions
│
├── app.json                      # Expo configuration
├── package.json                  # Dependencies and scripts
├── tsconfig.json                 # TypeScript configuration
└── README.md                     # This file
```

## 🎯 Key Components

### Authentication (`config/auth-context.tsx`)

Provides global authentication state using React Context:
- Session persistence across app restarts
- Automatic auth state listener
- Sign up, sign in, and sign out functions
- User session and profile data

### API Service (`config/api.ts`)

Centralized API layer for all backend operations:
- User authentication methods
- Todo CRUD operations
- Real-time subscriptions
- Proper error handling

### Custom Hook (`hooks/useTodos.ts`)

React hook for todo management:
- Load, add, update, delete todos
- Filter and search todos
- Error handling
- Automatic state updates

## 💡 Usage Examples

### Sign In

```typescript
import { useAuth } from '@/config/auth-context';

export default function LoginScreen() {
  const { signIn } = useAuth();
  
  const handleSignIn = async () => {
    await signIn('user@example.com', 'password');
  };
  
  return (
    <Button title="Sign In" onPress={handleSignIn} />
  );
}
```

### Manage Todos

```typescript
import { useTodos } from '@/hooks/useTodos';

export default function TodoScreen() {
  const { todos, addTodo, toggleTodo, deleteTodo } = useTodos();
  
  const handleAdd = async () => {
    await addTodo('New todo', 'Description');
  };
  
  return (
    // Render todos and buttons
  );
}
```

### Check Auth State

```typescript
import { useAuth } from '@/config/auth-context';

export default function App() {
  const { user, isLoading } = useAuth();
  
  if (isLoading) return <LoadingScreen />;
  
  return user ? <HomeScreen /> : <SignInScreen />;
}
```

## 📚 API Reference

### Auth Service

```typescript
// Sign up
authService.signUp(email: string, password: string)

// Sign in
authService.signIn(email: string, password: string)

// Sign out
authService.signOut()

// Get current user
authService.getCurrentUser()

// Reset password
authService.resetPassword(email: string)
```

### Todo Service

```typescript
// Get all todos
todoService.getTodos()

// Create todo
todoService.createTodo(title: string, description?: string)

// Update todo
todoService.updateTodo(id: string, updates: Partial<Todo>)

// Delete todo
todoService.deleteTodo(id: string)

// Toggle completion
todoService.toggleTodo(id: string, completed: boolean)
```

## 🔧 Configuration

All configuration is done through environment variables:

```env
# Required: Supabase credentials
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

The app automatically initializes with these values when starting.
   ```

2. Start the app

   ```bash
   npx expo start
   ```

In the output, you'll find options to open the app in a

- [development build](https://docs.expo.dev/develop/development-builds/introduction/)
- [Android emulator](https://docs.expo.dev/workflow/android-studio-emulator/)
- [iOS simulator](https://docs.expo.dev/workflow/ios-simulator/)
- [Expo Go](https://expo.dev/go), a limited sandbox for trying out app development with Expo

You can start developing by editing the files inside the **app** directory. This project uses [file-based routing](https://docs.expo.dev/router/introduction).

## Get a fresh project

When you're ready, run:

```bash
npm run reset-project
```

This command will move the starter code to the **app-example** directory and create a blank **app** directory where you can start developing.

## Learn more

To learn more about developing your project with Expo, look at the following resources:

- [Expo documentation](https://docs.expo.dev/): Learn fundamentals, or go into advanced topics with our [guides](https://docs.expo.dev/guides).
- [Learn Expo tutorial](https://docs.expo.dev/tutorial/introduction/): Follow a step-by-step tutorial where you'll create a project that runs on Android, iOS, and the web.

## Join the community

Join our community of developers creating universal apps.

- [Expo on GitHub](https://github.com/expo/expo): View our open source platform and contribute.
- [Discord community](https://chat.expo.dev): Chat with Expo users and ask questions.
