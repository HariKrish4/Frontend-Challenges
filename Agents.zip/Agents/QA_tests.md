# QA_tests.md

> Comprehensive QA test plan for the **Pomodoro 25/5 Mobile App** (React Native, Expo, Supabase). 
> Scope covers functional, reliability, offline, notifications, i18n, performance, security, accessibility, and release readiness. 
>
> **Non‑negotiable product rules tested throughout**: Focus **25:00** + Break **5:00**, **no long break**, **break does not auto‑start**, labels are tags only (UPSC/JEE/NEET/Work/Coding), mobile‑only, offline‑first with later sync to Supabase, local notifications for end‑of‑focus and end‑of‑break, languages EN/HI/TA, IST‑first.

---

## 1. Test Strategy Overview

**Goals**
- Validate core flows (start/complete focus, manual start break, complete break).
- Ensure timer accuracy (±2s over 25 minutes) and reliability in background/terminated states using **scheduled local notifications**.
- Guarantee offline-first behavior with robust sync and idempotency.
- Verify i18n (EN/HI/TA), Indic font rendering, and accessibility.
- Confirm security (RLS owner-only access), privacy, and error resilience.

**Out of Scope (MVP)**
- Payments, social/community features, web/PWA.

**Environments**
- **Devices**: iOS (latest 2 major versions, at least one with notch), Android 11–14 + 1 OEM with aggressive battery mgmt (e.g., Xiaomi/Realme).
- **Builds**: Debug + Release/Production.

---

## 2. Test Matrix (High-Level)

| Area | Objective | Priority |
|---|---|:--:|
| Functional – Timer & Flows | Validate 25/5 fixed flow with manual break | P0 |
| Notifications | Fire on-time in background/terminated; tap routing | P0 |
| Offline & Sync | Capture offline, sync to Supabase without duplicates | P0 |
| i18n & Fonts | EN/HI/TA switch, Indic rendering | P0 |
| Stats & Streaks | Accurate counts/aggregations | P1 |
| Performance | Cold start, UI responsiveness | P1 |
| Accessibility | Screen reader, contrast, target sizes | P1 |
| Security & RLS | Owner-only data access enforced | P1 |
| Error Handling | Network loss, permission denial | P1 |

---

## 3. Detailed Test Cases

### 3.1 Functional – Timer & Core Flows (P0)
1. **Start Focus (Idle → FocusActive)**
   - Pre: App installed, permissions not yet requested.
   - Steps: Launch → Tap *Start Focus (25:00)*.
   - Verify: Countdown begins; *Pause*/*Stop* visible; session stored locally; notification scheduled for +25m.

2. **Complete Focus (FocusActive → FocusComplete)**
   - Steps: Let countdown elapse OR fast-forward via debug hook; app may be in foreground.
   - Verify: Focus completes; FocusComplete screen shows; *Start Break (5:00)* CTA visible; no auto-start.

3. **Manual Start Break (FocusComplete → BreakActive)**
   - Steps: Tap *Start Break*.
   - Verify: 05:00 countdown; *Pause*/*Skip* visible; break notification scheduled for +5m.

4. **Skip Break (BreakActive → Idle)**
   - Steps: Tap *Skip*.
   - Verify: No break completion recorded; Idle screen with *Start Focus*.

5. **Stop Mid-Focus**
   - Steps: Start focus → *Stop* at ~12:00.
   - Verify: Session saved with `actual_minutes≈12`; no break prompted; stats update accordingly.

6. **Pause/Resume Focus**
   - Steps: Start focus → *Pause* → wait 10s → *Resume*.
   - Verify: Remaining time accounts for pause; no drift beyond ±2s.

7. **Label Assignment**
   - Steps: Select label (e.g., UPSC) before focus.
   - Verify: Label saved with session; durations unchanged (25/5).

### 3.2 Notifications – Background/Terminated (P0)
8. **Focus End – Foreground**
   - Verify: Local notification arrives at ~25m; tapping routes to FocusComplete; app state consistent.

9. **Focus End – Background**
   - Steps: Start focus → background app.
   - Verify: Notification fires on time; tap restores and routes to FocusComplete.

10. **Focus End – Terminated**
    - Steps: Start focus → kill app.
    - Verify: Notification still fires; tap launches app → FocusComplete.

11. **Break End – Background/Terminated**
    - Steps: Start break → background/kill.
    - Verify: Notification fires on time; tap returns to BreakComplete → *Start Next Focus*.

12. **Permission Denied**
    - Steps: Deny notifications.
    - Verify: App shows non-blocking guidance; timers still run; no crashes.

13. **Duplicate Notification Prevention**
    - Steps: Rapidly start/stop; ensure old schedules canceled.
    - Verify: Only the latest end-of-session notification fires.

### 3.3 Offline-First & Sync (P0)
14. **Offline Focus Session**
    - Steps: Airplane mode → Start & complete focus.
    - Verify: Local save; queued for sync; no crash.

15. **Offline Multiple Sessions**
    - Steps: Record 3–5 focus/break runs offline (include a stop & skip).
    - Verify: All persisted locally; queue reflects entries.

16. **Reconnect & Sync**
    - Steps: Go online.
    - Verify: Upserts to Supabase; deduped via `(device_id, started_at)`; local flagged as synced.

17. **Conflict – Same session edited on two devices** (if multi-device account available)
    - Steps: Modify `ended_at` on device A offline; device B online updates.
    - Verify: **Last-write-wins**; no duplicates.

18. **Server Down / 500**
    - Steps: Simulate Supabase failure.
    - Verify: Retries with backoff; user not blocked; no data loss.

### 3.4 i18n, Locale, Timezone (P0)
19. **Language Switch EN/HI/TA**
    - Steps: Switch language in Settings.
    - Verify: All screens strings update immediately; no clipped text.

20. **Indic Fonts Rendering**
    - Verify: Hindi/Tamil glyphs render correctly on Android and iOS.

21. **IST Defaults**
    - Verify: Session times and streak rollups align to IST.

### 3.5 Stats & Streaks (P1)
22. **Daily Counts**
    - Verify: Pomodoros/day reflects completed focus sessions.

23. **Total Focus Minutes**
    - Verify: `25 × completed focuses`.

24. **Weekly Histogram**
    - Verify: Aggregates per day; timezone aware.

25. **Streak Logic**
    - Verify: ≥1 focus/day increments streak; gaps reset.

### 3.6 Performance (P1)
26. **Cold Start**
    - Verify: < 2.5s on mid-range Android (Release build).

27. **Timer Smoothness**
    - Verify: No dropped frames during countdown.

28. **Memory Footprint**
    - Verify: No leaks across cycles; GC stable.

### 3.7 Accessibility (P1)
29. **Screen Reader Labels**
    - VoiceOver/TalkBack announces controls meaningfully.

30. **Touch Target Sizes**
    - ≥ 44×44dp; verify buttons and chips.

31. **Color/Contrast**
    - Meets WCAG AA for text & essential UI.

### 3.8 Security, Privacy, RLS (P1)
32. **RLS Owner-Only Access**
    - Verify another user cannot read/modify your sessions.

33. **Auth Flows**
    - Magic link + phone OTP (optional) work; sign-out clears local sensitive data if requested.

34. **Data Minimization**
    - Only required fields stored; verify no PII leaks in logs.

### 3.9 Error Handling & Resilience (P1)
35. **Network Loss Mid-Sync**
    - Verify retries; user can continue offline.

36. **Storage Full**
    - Simulate low disk; verify friendly error and continued basic operation.

37. **Clock Skew**
    - Change device time while session runs; verify timestamp-diff logic remains stable with notifications as ground truth.

---

## 4. Automation Plan

**Unit Tests**
- Timer math (timestamp diff, pause/resume, drift clamps).
- State machine transitions.
- Repository layer (SQLite insert/query/migrations).

**Integration/E2E (Detox)**
- Start focus → background/terminate → notification → return → complete → manual start break → complete.
- Offline burst → reconnect → server sync verification.

**CI Recommendations**
- GitHub Actions: lint, unit tests, build, Detox (Android emulator), artifact upload.

---

## 5. Test Data & Fixtures
- **Labels**: UPSC, JEE, NEET, Work, Coding.
- **Locales**: en, hi, ta.
- **Accounts**: at least two test users; one multi-device scenario.
- **Network conditions**: offline, 2G, 3G, flakey Wi‑Fi.

---

## 6. Tools & Instrumentation
- **Detox** for E2E.
- **Jest** for unit/integration.
- **Sentry** (optional) for crash/error visibility.
- **PostHog** (optional) for product events.
- **Android Studio Profiler / Xcode Instruments** for performance.

---

## 7. Acceptance Criteria (MVP)
- End-of-focus and end-of-break notifications reliably fire on time in background/terminated states on iOS and Android.
- Timer accuracy within **±2 seconds** over a 25-minute interval (allowing for OS scheduling variance, notification is the authoritative boundary).
- Break **never auto-starts**; manual start required.
- Sessions are captured offline and later synced to Supabase without duplication (idempotency via `(device_id, started_at)`).
- RLS ensures owner-only data access.
- Language switch EN/HI/TA works everywhere; Indic glyphs render correctly.

---

## 8. Manual Test Checklists

### iOS
- [ ] Foreground: 25m/5m flows
- [ ] Background: notifications & routing
- [ ] Terminated: notifications & routing
- [ ] Permissions: allow/deny flows
- [ ] Language: EN → HI → TA round‑trip
- [ ] Accessibility: VoiceOver labels

### Android (Stock + OEM)
- [ ] Foreground + Background + Terminated
- [ ] Battery optimization on/off
- [ ] Notification channel & priority
- [ ] Permissions: allow/deny flows
- [ ] Language: EN → HI → TA round‑trip
- [ ] Accessibility: TalkBack labels

---

## 9. Regression Suite (post-MVP)
- Stats query accuracy with large histories
- Migration from older SQLite schema versions
- Multi-device conflict resolution edge cases
- Notification rescheduling after OS updates

---

## 10. Release Readiness
- [ ] All P0/P1 test cases passed in Release builds
- [ ] Store listing copy verified (permissions rationale)
- [ ] Crash-free sessions baseline acceptable
- [ ] Privacy policy present; sign-out behavior verified
- [ ] Final smoke on TestFlight / Play Internal Testing

---

## 11. Test Artifacts
- Test reports (unit/E2E)
- Device logs for notification timing
- Screenshots/videos for critical flows
- SQL snapshots (before/after sync)

---

## 12. Maintenance
- Keep this plan versioned alongside app releases.
- Update matrices when adding languages, labels, or features beyond MVP.

