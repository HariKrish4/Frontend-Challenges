# todo.md

> Actionable, developer-facing checklist for the **Pomodoro (25/5) Mobile App** — React Native (Expo) + Supabase. 
> **Hard rules:** Fixed 25 min focus / 5 min break, **no long break**, **break does not auto-start**, labels are tags only (UPSC/JEE/NEET/Work/Coding), mobile-only, offline-first (SQLite) with later sync to Supabase, local notifications for end-of-focus and end-of-break, languages EN/HI/TA, IST-first.

---

## 0) Milestones (high-level)
- [ ] **M0 – Blueprint (Stage 0)**: Architecture, folder map, routes, risks, NFRs, dependency list (specs only)
- [ ] **M1 – Project Scaffold**: Expo app baseline, navigation, state scaffolds, i18n init, Supabase client
- [ ] **M2 – Timer Engine**: Timestamp-diff countdowns, state machine, fixed durations enforced
- [ ] **M3 – Local Persistence**: SQLite schema, repositories, offline capture
- [ ] **M4 – Notifications**: Local scheduling for 25/5; background/terminated handling; permission UX
- [ ] **M5 – Sync to Supabase**: Upserts, idempotency, backoff/retry, conflict policy
- [ ] **M6 – UI Screens**: Home/Focus/Break/Complete/Stats/Settings/Labels/Auth
- [ ] **M7 – i18n**: EN/HI/TA strings; runtime toggle; fonts
- [ ] **M8 – QA & Perf**: Unit + E2E + manual background tests; performance budget; accessibility
- [ ] **M9 – Release Prep**: Store copy, permissions text, build configs, telemetry hooks, privacy policy draft

---

## 1) Stage 0 – Blueprint (spec-only)
> Reference: **Agents.md → Blueprint Agent** and **P1: Stage 0 Blueprint**

- [ ] Write **folder/file map** with purposes
- [ ] Draft **navigation map** (routes, params)
- [ ] Confirm **non-functional requirements** (NFRs):
  - [ ] Timer accuracy **±2s** over 25 minutes
  - [ ] Cold start < **2.5s** on mid-range Android
  - [ ] Background/terminated notifications must fire on time
  - [ ] Accessibility: tap target ≥ 44x44, labels for elements
- [ ] Risks & mitigations (iOS background limits, Android OEM battery killers, permission denial, offline conflicts)
- [ ] Dependencies list & versions (Expo SDK, TS, Zustand/Redux, expo-notifications, expo-sqlite, supabase-js)

**Exit criteria:** All specs reviewed; no code produced; constraints restated.

---

## 2) Stage 1 – Project Scaffold
> Reference: **Agents.md → Scaffold Agent**

- [ ] Init Expo (TypeScript)
- [ ] Add dependencies: react-navigation, zustand (or RTK if decided), expo-notifications, expo-sqlite, @supabase/supabase-js, react-i18next
- [ ] Create **folder structure** from Blueprint
- [ ] Implement **navigation shell** (no business logic)
- [ ] Initialize **Supabase client** (env-driven)
- [ ] Add **Zustand store skeletons** (app/session/ui)
- [ ] Add **i18n init** with placeholders (en/hi/ta)
- [ ] Add **theme tokens** (spacing, radius, typography scale)

**Exit criteria:** App runs, can navigate between placeholder screens.

---

## 3) Stage 2 – Timer Engine (Core domain)
> Reference: **Agents.md → Timer Engine Agent** and **P3 Prompt**

- [ ] Implement **timestamp-diff** utility (monotonic reference; avoid setInterval drift)
- [ ] Define **state machine**:
  - Idle → FocusActive → FocusComplete → BreakReady → BreakActive → BreakComplete → Idle
- [ ] Enforce **fixed durations** (Focus = 25, Break = 5) at the **state layer**
- [ ] Events & handlers: `startFocus`, `completeFocus`, `startBreak` (manual), `completeBreak`, `pause`, `stop`, `skipBreak`
- [ ] Guard: **no auto-start** of break; **no long break**
- [ ] Write unit tests for drift and transitions (specs first)

**Exit criteria:** Simulated runs hit ±2s; state transitions correct; tests pass.

---

## 4) Stage 3 – Local Persistence (SQLite)
> Reference: **Agents.md → Offline Sync Agent (local part)** and **P5 Prompt**

- [ ] Create SQLite **schema** mirroring Supabase tables: `profiles`, `sessions`, `exam_presets`
- [ ] Migrations mechanism (versioned SQL or lightweight ORM migrations)
- [ ] Repositories: `SessionRepo`, `ProfileRepo`, `PresetRepo`
- [ ] Capture sessions **locally first** on every event
- [ ] Deterministic keys: `(device_id, started_at)` for idempotency
- [ ] Add **local queue** for unsynced writes + status flags

**Exit criteria:** Airplane-mode flows produce correct local data with no crashes.

---

## 5) Stage 4 – Notifications (Local, scheduled)
> Reference: **Agents.md → Notifications Agent** and **P4 Prompt**

- [ ] Permission UX (iOS/Android) with rationale
- [ ] Android notification **channel** and priority
- [ ] Schedule local notifications at **start + 25m** (focus) and **start + 5m** (break)
- [ ] On notification tap, route to the **appropriate screen/state**
- [ ] Background/terminated tests

**Exit criteria:** Notifications fire on time with app killed/backgrounded on both platforms.

---

## 6) Stage 5 – Supabase Schema, RLS & Sync
> Reference: **Agents.md → Schema & Contracts Agent** + **Offline Sync Agent**

- [ ] Author **Supabase SQL DDL** (**TO APPLY LATER**) for `profiles`, `sessions`, `exam_presets`
- [ ] Enable RLS; policy: owner-only (`auth.uid() = user_id`)
- [ ] Implement **sync worker**:
  - [ ] Push unsynced local rows → Supabase (upsert)
  - [ ] Pull server updates → SQLite
  - [ ] Conflict: **last-write-wins**
  - [ ] Retry with backoff; connectivity listeners
- [ ] Ensure **planned_minutes ∈ {25,5}** on all inserts

**Exit criteria:** Offline-created sessions sync cleanly after reconnect; no duplicates.

---

## 7) Stage 6 – UI Screens & Components
> Reference: **Agents.md → UI/UX Agent**

**Screens**
- [ ] **HomeTimer (Idle)**: 25:00, Start Focus, label chips, cycles today, language switcher
- [ ] **FocusActive**: countdown, Pause/Stop, current label
- [ ] **FocusComplete**: success state, **Start Break (manual)** CTA
- [ ] **BreakActive**: 05:00, Pause/Skip
- [ ] **BreakComplete**: **Start Next Focus** CTA
- [ ] **Stats**: Pomodoros/day, total focus minutes, weekly histogram, top labels
- [ ] **Settings**: Language (EN/HI/TA), notification toggles, timezone (IST default), preset selection **(labels only)**
- [ ] **LabelsPicker**: assign label to upcoming session
- [ ] **Auth**: Email magic link + optional phone OTP

**Components**
- [ ] Button, Chip, Countdown, Progress/Cycle indicator, StatCard, EmptyState, FormSwitch

**Exit criteria:** UI matches wireframes; no duration controls present anywhere.

---

## 8) Stage 7 – i18n (EN/HI/TA)
> Reference: **Agents.md → i18n Agent**

- [ ] Create `en.json`, `hi.json`, `ta.json` with all screen strings
- [ ] Implement **runtime language toggle**
- [ ] Verify Indic rendering on Android (font fallbacks)
- [ ] Snapshot tests to prevent key regressions

**Exit criteria:** Language swap works app-wide; QA on devices.

---

## 9) Stage 8 – Stats & Telemetry (Optional but recommended)
- [ ] Compute **Pomodoros today**, **total focus minutes** (25 × completed focus), **streak** (≥1 focus/day), **weekly bars**
- [ ] (Optional) Wire **Sentry** and **PostHog**; events: `session_started`, `session_completed`, `break_started`, `break_completed`, `app_open`

**Exit criteria:** Stats render correctly; events visible in dashboards (if enabled).

---

## 10) Stage 9 – QA, Performance, Accessibility
> Reference: **Agents.md → QA & Reliability Agent**

**Automated**
- [ ] Unit tests: timer drift, state machine transitions, repos
- [ ] E2E (Detox): Start Focus → background → notif fires → return → complete → start Break (manual)

**Manual Matrix**
- [ ] iOS: foreground, background, terminated; permissions allowed/denied
- [ ] Android: stock + OEM with aggressive battery mgmt; background/terminated
- [ ] Offline burst: record 5 sessions offline → reconnect → verify sync

**Performance**
- [ ] Cold start < 2.5s; JS bundle size check; avoid heavy re-renders

**Accessibility**
- [ ] TalkBack/VoiceOver labels; contrast; touch target sizes

**Exit criteria:** All P0 tests pass; performance & accessibility budgets met.

---

## 11) Stage 10 – Release Prep
- [ ] App icons, splash
- [ ] Store listings (EN first; plan HI/TA copy later)
- [ ] Permissions copy (notifications rationale)
- [ ] Build configs: Android channel IDs; iOS entitlements
- [ ] Versioning & changelog
- [ ] Privacy policy & data retention notes (DPDP awareness)

**Exit criteria:** Signed builds available; smoke tests on TestFlight/Play Internal Testing.

---

## Backlog / Nice-to-Haves (post-MVP)
- [ ] Web push (if a web client ever added in future — out of scope now)
- [ ] Visual themes (dark mode, high-contrast)
- [ ] WhatsApp share of achievements
- [ ] Deeper analytics dashboards
- [ ] Razorpay/UPI subscription (Edge Functions webhook)

---

## Prompts Quick Links (from Agents.md)
- **P1**: Stage 0 Blueprint (no code)
- **P2**: Schema & Contracts (DDL + RLS + types, spec-only)
- **P3**: Timer Engine (spec → code later)
- **P4**: Notifications (spec → code later)
- **P5**: Offline Sync (spec → code later)
- **P6**: UI/UX Build (plan first)

> Usage pattern: _“Use Agents.md → P3 to design the timer engine spec, then wait for me to say PROCEED WITH CODE.”_

---

## Environment & Secrets Checklist
- [ ] `EXPO_PUBLIC_SUPABASE_URL`
- [ ] `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- [ ] `EXPO_PUBLIC_ANDROID_NOTIF_CHANNEL_ID`
- [ ] `SENTRY_DSN` (optional)
- [ ] `EXPO_PUBLIC_POSTHOG_KEY` (optional)

---

## Definition of Done (MVP)
- [ ] Fixed 25/5 enforced at state & UI; no settings to change durations
- [ ] Break **requires manual** start
- [ ] Focus/break notifications fire on time in background/terminated states
- [ ] Offline-first session capture with later Supabase sync under RLS
- [ ] EN/HI/TA language switch works
- [ ] Stats page shows Pomodoros/day, total focus minutes, weekly chart, top labels

---

## Decision Log (keep updated)
- 2026‑01‑07: Fixed 25/5 only; no long break; manual break start; labels are tags only.
- 2026‑01‑07: Mobile-only; Supabase backend; no separate server for MVP.

---

## Risks & Mitigations (track)
- [ ] iOS background timer assumptions → **Mitigation**: rely on scheduled local notifications as ground truth
- [ ] Android OEM battery optimizations → **Mitigation**: foreground-friendly scheduling, user education, channel priority
- [ ] Offline conflicts/duplicates → **Mitigation**: `(device_id, started_at)` idempotency; LWW policy
- [ ] Localization quality → **Mitigation**: manual proofing for HI/TA, font fallbacks

---

## How to Use this File
1. Start at the top milestone that isn’t checked yet.
2. For each stage, run the matching **Prompt** from _Agents.md_ to produce a **spec first**.
3. When satisfied, tell the assistant **“PROCEED WITH CODE for Stage X”** to generate implementation files.
4. Check off tasks; keep this file as the single source of execution truth.
