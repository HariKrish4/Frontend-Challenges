# AGENTS.md

## Project Description

- This project is to [Insert project purpose here and rough overview of plan and end goals].

## Behavioural Instructions

- [Insert instructions here]

## Getting Started

- The user is going to give you a task.
- Read the relevant materials outlined in this document to get up to speed, including:
  - README.md
  - INDEX.md
  - TODO.md
- Discuss the task until you fully understand the scope, intent, and expected outcome before writing any code.

## Repository Layout & Tooling

### Root Directory

- `AGENTS.md`: This guide; keep it authoritative for all agentic AI contributors.
- `README.md`: Project overview and onboarding steps.
- `INDEX.md`: A list of all files in this repository and an accompanying description

### Documentation Directory (`docs/`)

- `docs/` mirrors the repo layout for human-readable explainers.
- Follow the Documentation Standards below for required explainers and folder README rules.

### Frontend Directory (`frontend/`)

- [Insert instructions regarding your frontend structure if applicable].

### Backend Directory (`backend/`)

- [Insert instructions regarding your backend structure if applicable].

### Logs & Scripts & Temp Files

- `logs/`: disposable local logs only. Not deployed, not public, safe to delete at any time.
- `scripts/`: disposable helper scripts that do not impact the product code (agent helpers or one-off utilities). Not deployed, not public, safe to delete at any time.
- `temp/`: disposable scratch space for temporary files. Not deployed, not public, safe to delete at any time.

## TODO Management

- Maintain a single canonical `TODO.md` in the repo root. Create or refresh it after every editing action you take.
- Model entries like a lightweight Jira board:
  - `## Epic: <name> [Status]` with description, desired outcome, and definition of done.
  - Under each epic, list Features (`- Feature: … – status/notes`).
  - Nest Stories/Tasks as checkboxes (`- [ ] Story: …`) and keep them small enough for a single working session.
  - Place Bugs beneath the impacted feature or in a `### Bugs` subsection if they span areas.
  - Update Stories, Features and Epics as is necessary after every edit.

## Documentation Standards

- Docs mirror the repo layout under `docs/` with one explainer per file: `path/to/file.ext` -> `docs/path/to/file.ext.md`.
- Every folder in `docs/` must include a `README.md` summarizing the folder’s purpose and key contents.
- Each explainer must cover what the file does, why it exists, and how it works (inputs/outputs, side effects, dependencies, and non-obvious decisions).
- `INDEX.md`: maintain a root index that lists all files, links to their adjacent explainers, and has a brief one-liner on what the file does. Update it in the same action as file changes.

## Code Commenting & Docstrings

- Write clear docstrings for public APIs, service functions, and any function with side effects, I/O, concurrency, security, or non-obvious logic.
- Add concise inline comments where the intent is not obvious from the code; aim to remove ambiguity for a reader unfamiliar with the area.
- Avoid noise: no historical commentary and no redundant comments for trivially self-explanatory code.

## Tech Stack & Project Layout Principles

- [Insert project specific standards here]
  - Naming conventions
  - frontend conventions
  - backend conventions

## Collaboration & Git Workflow

- [Insert collaboration and versioning instructions here]
- Never let the Agent merge to main.

## Testing & Quality

- [Insert testing and quality standards and conventions here]

## Definition of Done

- [insert DoD for your work]

## Out of Scope (for now)

- [insert recurring AI suggestions here that you do not want to work on].
