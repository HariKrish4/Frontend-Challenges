# AGENTS.md

## Project Description

- This project is to [Insert project purpose here and rough overview of plan and end goals].

## Goals

- Prefer simple, maintainable choices and avoid premature complexity.
- Design agent tools in small, composable slices so each capability can be invoked independently.
- Keep requirements lean until production hardening is required.

## Getting Started

- Ask the user (or teammate) which task to focus on; consult `TODO.md` at the repo root and keep it up to date.
- Session kickoff flow: ask what we will work on in this session. The user will respond with an epic (from `TODO.md` or ad hoc). If the epic is new, add it to `TODO.md` immediately.
- Discovery first: discuss the epic until we fully understand the scope, intent, and expected outcome before writing any code.
- Use the helper scripts in `tools/` (`setup.sh`, `start.sh`, `stop.sh`) rather than inventing new entrypoints.

## Behavioural Instructions

- Never use emojis.
- Champion UX: flag any flows, copy, or visuals that might confuse users.
- Be direct and confident; offer better alternatives when you see them.
- Stop when the value plateaus; do not suggest extras unless they genuinely help the product.
- Embrace minimalism: favour intuitive flows, clear labels, tidy docs, and concise comments that explain non-obvious logic.
- Modularity is the name of the game: abstract capabilities so no single file or group of files becomes overly cumbersome.
- When the codebase is already complicated, do only one small thing at a time. Initial builds in new repos can move faster, but we still take epics one story at a time rather than tackling the full epic.
- Keep `requirements.txt` accurate whenever dependencies change.
- Delay redundancy/failover work until production hardening. While initially building, it is better to understand failures when they happen rather than have them fail silently and be missed by QA.

## TODO Management

- Maintain a single canonical `TODO.md` in the repo root. Create or refresh it at the start of each session.
- At session start, record the chosen epic under `TODO.md` if it’s not already present and link any supporting discovery notes.
- Model entries like a lightweight Jira board:
  - `## Epic: <name> [Status]` with description, desired outcome, and definition of done.
  - Under each epic, list Features (`- Feature: … – status/notes`).
  - Nest Stories/Tasks as checkboxes (`- [ ] Story: …`) and keep them small enough for a single working session.
  - Place Bugs beneath the impacted feature or in a `### Bugs` subsection if they span areas.
- Always work one story at a time within an epic. Keep stories scoped to a single working session, especially when the codebase is complex.
- Link out to other docs instead of duplicating detail. When work completes, tick the checkbox, note the outcome, and move finished items to the bottom so in-progress work stays visible.

## Repository Layout & Tooling

### Root Directory

- `AGENTS.md`: This guide; keep it authoritative for all agentic AI contributors.
- `README.md`: Project overview and onboarding steps.
- `mise.toml`: Task automation/environment config.
- `sample-swagger.yaml`: Primary Swagger spec; add new endpoints here.
- `FILES_INDEX.md`: Canonical index linking to collocated per-file explainers (`[basename].md` next to each file).
- `QA_tests.md`: Manual QA test cases for completed epics and their core flows.

### Tools Directory (`tools/`)

- Shell helpers: `start.sh`, `stop.sh`, `setup.sh`, `go.sh`.
- `sample-app.yaml`: Example application config.
- `swagger_api_generator.py`: Generates FastAPI handlers from the Swagger spec. Example usage: `./tools/swagger_api_generator.py sample-swagger.yaml`.
- Temporary tools or scripts must live under a clearly named `temp/` or `to_be_deleted/` folder to keep the codebase clean; remove them once the task completes.
- Extend these scripts instead of adding parallel ones.

### Frontend Directory (`frontend/`)

- `vite.config.js`: Vite configuration.
- `index.html`: Entry HTML shell.
- `package.json`: Dependency manifest.
- `src/`: Contains `App.jsx`, `main.jsx`, `config.js`, and the broader component tree.

### Backend Directory (`backend/`)

- `requirements.txt`: Backend dependencies—update whenever packages change.
- `app.yaml`: Deployment/configuration data.
- `src/main.py`: FastAPI entrypoint.
- `src/config.py`: Central configuration.
- `src/db.py`: Database access and psycopg2 wiring.
- `src/handlers/`: Generated endpoint handlers such as `findPetsByTags.py`, `findPetsByStatus.py`, `uploadFile.py`, etc.

### Skills (`skills/`)

- Houses agent-facing skillpacks (e.g., `agentic-tool-creator`, `brand-guidelines`, `skill-writer`, `qa-test-writer`). These guide AI agents rather than the application runtime.
- Only add or edit a skill when you are explicitly defining new agent behaviour; otherwise treat the directory as read-only context.

### Logs & Scripts

- Use `./tools/start.sh` and `./tools/stop.sh` to run the stack; they also define log locations (`frontend/frontend.out`, `backend/backend.out`). Tail those files when debugging instead of creating new log streams.
- Temporary files created for local investigation or throwaway utilities must be placed under `temp/` or `to_be_deleted/` and removed once they’re no longer needed.

## Documentation Standards

- Collocated file explainers: for any file added or modified, create or update an adjacent `[basename].md` in the same directory (e.g., `src/db.py` has `src/db.md`). Keep it concise: purpose, inputs/outputs, side effects, dependencies, and non-obvious decisions.
- `FILES_INDEX.md`: maintain a root index that lists all files and links to their adjacent `[basename].md` explainers. Update it in the same PR as file changes.
- Generated files: if a file is generated, note the generator and source spec in its explainer. Prefer documenting the generator over repeating details in each generated handler.
- Directory-level summaries: for folders with many small files, use a folder `README.md` that summarizes the set, then create explainers only for non-obvious files.

## Tech Stack & Project Layout Principles

- Backend: Pure FastAPI plus psycopg2/Postgres—avoid extra frameworks unless aligned with the team.
- Frontend: React (JavaScript via Vite). Keep the structure under `src/` aligned with the pattern described below.
- Treat the repo as a cookie-cutter layout: top-level `backend/`, `frontend/`, `tools/`, and `skills/`.
- Favour modular abstractions so features remain composable; avoid concentrating unrelated logic in large files or tightly coupled groups.

## API Generation Workflow

- Add new endpoints by editing `sample-swagger.yaml` (do not change `tools/swagger-template.yaml`; it is reference-only).
- Ensure each `paths.<path>.operationId` is unique.
- Use `yq` to update the spec, e.g.:

```sh
yq eval '.paths."/test" = {
  "get": {
    "operationId": "getTest",
    "summary": "Test endpoint",
    "responses": {
      "200": {
        "description": "successful operation"
      }
    }
  }
}' -i sample-swagger.yaml
```

- After editing the spec, run `./tools/swagger_api_generator.py sample-swagger.yaml` to regenerate FastAPI handlers.
- Document which spec file you used each time you regenerate code.

## Frontend Code Organisation

- Keep everything under `src/` (or Expo `app/` if that pattern emerges) with folders such as `screens/`, `components/`, `state/`, `services/`, `utils/`, `assets/`.
- Use functional components and React hooks exclusively.
- One component per file when possible; keep modules focused.
- Business logic belongs in `services/` or state managers; UI components stay presentation-focused.

## Environment Setup

- Always load environment variables via `python-dotenv` before any LLM initialisation.
- Never hardcode credentials or API keys.

## Naming & Style

- Files: kebab-case for assets, PascalCase for React components.
- Functions: `verbNoun`; components: PascalCase.
- Prefer explicit TypeScript-style typings on shared APIs (even when authoring in JS, document expected shapes).
- Module docstrings: every Python module should include a short module-level docstring outlining its purpose and main exports.
- Function/method docstrings:
  - Required for public APIs (FastAPI route handlers, services exposed to other modules), agent tools/skills, and functions with side effects (I/O, DB, network), concurrency, security, or non-obvious logic.
  - Optional for trivial, pure helpers where the name and type hints fully convey intent. If you touch such a function and it lacks a docstring, add a one-liner when helpful.
- Docstring format: Summary line; Args; Returns; Raises; Side Effects/Dependencies. Keep docstrings brief and actionable; do not duplicate obvious code.
- Update on edit: when you modify a function, ensure its docstring stays accurate in the same PR.

## Commits & PRs

- Conventional Commits: `feat:`, `fix:`, `chore:`, `refactor:`, `docs:`, `test:`.
- Keep PRs small; limit scope to a single concern.
- Include brief descriptions, testing notes, and screenshots for UI changes.
- Mark each new file as Local or Deployable in PRs.

## Collaboration & Git Workflow

- Default branch protection: no direct pushes to `main`; use branches and PRs, squash or fast-forward merges only after review.
- Branch naming: prefix with `feat/`, `fix/`, or `chore/`; keep scope focused and align messages with Conventional Commits. Suggest a logical branch name based on the user-selected epic to be worked on.
- Working cycle: pull `main`, create branch, code, run checks/tests, commit, push, open PR, review, squash/merge, delete branch, pull `main`.
- Conflict handling: rebase on `main` before opening a PR, resolve locally, and force-push if needed; pull frequently.
- Repo hygiene: ensure remotes/auth are set; keep `.gitignore` covering local-only assets; keep TODOs tight and move decisions into versioned docs.

## Testing & Quality

- Minimum expectation: unit tests for utilities and critical state logic; snapshot tests are acceptable when UI is stable.
- Follow project-wide lint/format settings once they exist (ESLint/Prettier, etc.).
- Docstring hygiene: run style checks locally; ensure public handlers and agent tools include docstrings. Keep them current when changing signatures or behavior.
- Upon completion of an epic, write QA tests for the epic’s core flows in `QA_tests.md`. Use the `qa-test-writer` skill to assist, and research whether existing test coverage is sufficient, needs edits, or should be replaced. Keep tests concise, actionable, and aligned to the happy path plus key edge cases.
- Document any manual verification steps in PRs.

## Data & Privacy

- Never log PII; scrub payloads before error reporting.
- When collecting telemetry for agents/tools, keep data tightly scoped to debugging signals.

## Definition of Done

- [insert DoD for your work]
- App builds and runs with no unhandled errors.
- Happy path is implemented and documented in `README.md`.
- QA_tests.md is updated with core flow tests for the completed epic, validated for clarity and relevance.
- Basic empty states and error feedback are present.
- Type checks pass; no runtime warnings in core flows.
- Module-level docstring exists for any new Python module.
- Public APIs and agent tools include up-to-date docstrings; complex functions touched in the change set have accurate docstrings.

## Out of Scope (for now)

- [insert recurring AI suggestions here that you do not want to work on].