# Pomodoro 25/5 Mobile App

A minimalist, distraction-free **mobile-only** Pomodoro application for India, built with **React Native (Expo)** and **Supabase**, designed around one core philosophy:

> **Focus for 25 minutes. Break for 5 minutes. No configuration. No decisions. Just consistency.**

This app enforces classic Pomodoro intervals, supports **offline-first usage with SQLite**, works reliably in **background/terminated** states via scheduled **local notifications**, and is tuned for Indian users with **English, Hindi, and Tamil** language support.

---

## ⭐ Features

### 🎯 **Fixed Pomodoro Cycle**
- 25-minute Focus session
- 5-minute Break session
- **Break does NOT auto-start** — user must tap
- **No long break**
- No configurable intervals → a pure, disciplined workflow

### 🔖 **Labels (Exam + Work presets)**
Labels help categorize sessions without altering durations.
- UPSC
- JEE
- NEET
- Work
- Coding

### 📱 **Mobile-Only Experience**
- Built for iOS & Android using React Native Expo
- No web client (by design)

### 🌐 **Offline-First**
- Uses **SQLite** to capture all sessions locally
- Syncs later to Supabase when connectivity returns
- No data loss even if app is killed

### 🔔 **Reliable Local Notifications**
- Notification at the end of 25-minute focus
- Notification at the end of 5-minute break
- Functions correctly in background or terminated state

### 🌏 **India-Focused**
- Language support: **English (EN), Hindi (HI), Tamil (TA)**
- IST-first timezone
- Exam labels tailored for Indian users

### 📊 **Stats Dashboard**
- Pomodoros completed today
- Total focus minutes
- Weekly bar chart
- Streak counter
- Top labels

### 🔐 **Supabase Integration**
- Auth: Email magic link + optional phone OTP
- Secure Postgres storage
- Row Level Security (RLS) enabled

---

## 🏗️ Tech Stack

### **Frontend & Mobile**
- React Native (Expo)
- TypeScript
- Zustand (or Redux Toolkit)
- React Navigation
- expo-notifications
- expo-sqlite

### **Backend**
- Supabase (Auth, Postgres, RLS)
- Supabase JS SDK

### **Dev & Observability**
- Sentry (optional)
- PostHog (optional)

---

## 📁 Project Structure
(This will be fully generated in Stage 0 via `Agents.md`)

```
/app
/src
  /components
  /screens
  /state
  /db
  /lib
  /i18n
  /types
```

---

## 🧠 Core Principles

### **1. Non-configurable durations**
No setting screen for timer length. No customization. Prevents decision fatigue.

### **2. Manual break start**
Break never starts automatically.

### **3. Offline-first always**
Every session is saved locally first, synced later.

### **4. Notifications are ground truth**
Timers cannot be trusted in background → notifications ensure accuracy.

### **5. Mobile-only simplicity**
Avoid unnecessary complexity.

---

## 🚦 Development Workflow
This project uses a multi-agent workflow described in **Agents.md**.

### Stages (high-level):
1. **Blueprint** (architecture, folder structure, routes)
2. **Scaffold** (Expo project, navigation, state shells)
3. **Timer Engine** (timestamp-diff powered)
4. **Local Persistence** (SQLite)
5. **Notifications** (local scheduling)
6. **Sync Engine** (Supabase upserts)
7. **UI Screens**
8. **i18n** (EN/HI/TA)
9. **QA & Performance**
10. **Release Prep**

See **todo.md** for the actionable checklist.

---

## 📜 Environment Variables
Set these in your `.env` or via Expo app config:

```
EXPO_PUBLIC_SUPABASE_URL=
EXPO_PUBLIC_SUPABASE_ANON_KEY=
EXPO_PUBLIC_ANDROID_NOTIF_CHANNEL_ID=
SENTRY_DSN=
EXPO_PUBLIC_POSTHOG_KEY=
```

---

## 📦 Installation (placeholder)
Will be populated once scaffold stage is completed.

```
# after project generation
npm install
npm start
```

---

## 🧪 Testing
- Unit tests for timer logic (accuracy ±2s)
- E2E tests for notifications (background/terminated)
- Offline sync tests (SQLite → Supabase)
- Accessibility checks

---

## 🛡️ License
TBD

---

## ✨ Acknowledgements
- Built with love for students & professionals in India.
- 100% focused on discipline, routine, and simplicity.

