# Agents.md

> Operating model for AI-assisted development of the **Pomodoro (25/5) Mobile App** (React Native + Expo, Supabase). 
> This playbook defines specialized agents, their responsibilities, inputs/outputs, prompts, guardrails, handoffs, and acceptance checks. 
>
> **Key product constraints**: Mobile-only; Focus **25:00** + Break **5:00** (non‑configurable); **Break does not auto-start**; **No long break**; **Exam presets = labels only** (UPSC, JEE, NEET, Work, Coding); **Offline-first** with SQLite + later sync to **Supabase**; Local notifications for focus/break end; Languages **EN/HI/TA**; IST-first.

---

## 0) Orchestration Overview

**Pipeline (Stages & Handoffs)**
1. **Blueprint Agent** ➜ 2. **Schema & Contracts Agent** ➜ 3. **Scaffold Agent** ➜ 4. **Timer Engine Agent** ➜ 5. **Notifications Agent** ➜ 6. **Offline Sync Agent** ➜ 7. **i18n Agent** ➜ 8. **UI/UX Agent** ➜ 9. **QA & Reliability Agent** ➜ 10. **Release Agent**.

**Global Guardrails (apply to all agents)**
- Do **not** change core product rules (25/5 fixed, manual break start, no long break, labels don’t alter duration).
- Never introduce web/Desktop scope.
- Prefer **timestamp-diff** over `setInterval` for timers; schedule local notifications as the ground-truth boundaries.
- Protect privacy; store only minimum data; follow Supabase RLS owner-only policies.
- Make the app fully functional **offline**; never block on network.

---

## 1) Blueprint Agent
**Purpose**: Produce Stage 0 blueprint (no code): folders, screens, navigation map, dependencies, risk register, and effort breakdown.

**Inputs**: Project constraints (above) + platform choices.

**Outputs**:
- Folder/file map with purposes
- Navigation map (screens & params)
- Non-functional requirements (timer accuracy ±2s, cold start <2.5s, accessibility)
- Risk/mitigation list (iOS background, webworker N/A, notification permissions)

**Prompt Skeleton**:
- "Generate Stage 0 blueprint. Do not emit code. Include structure, routes, risks, and NFRs for RN (Expo) + Supabase, fixed 25/5 with manual break."

**Acceptance**:
- No code blocks that implement logic; only specs. Aligns with constraints.

---

## 2) Schema & Contracts Agent
**Purpose**: Define Supabase SQL DDL, RLS, and local SQLite schema; TypeScript interfaces (spec-only).

**Inputs**: Data entities and access rules.

**Outputs**:
- **Supabase (TO APPLY LATER)**: `profiles`, `sessions`, `exam_presets`; RLS policies (owner-only).
- **SQLite** mirrored schema; migration plan; deterministic IDs (`device_id + started_at`).
- **Types**: `Session`, `Profile`, `ExamPreset` (no implementation).

**Guardrails**: Planned minutes restricted to **25** (focus) and **5** (break).

**Acceptance**: DDL compiles logically; policies enforce `auth.uid() = user_id`.

---

## 3) Scaffold Agent
**Purpose**: Create Expo project baseline and plumb dependencies (no business logic yet).

**Inputs**: Package list, folder map, environment variables.

**Outputs**:
- Expo app, TypeScript config, React Navigation, Zustand store skeleton, theme tokens, i18n init (EN/HI/TA), Supabase client init, Sentry/PostHog stubs (optional).

**Guardrails**: No timer logic; no durations in settings; keep screens empty shells.

**Acceptance**: App compiles; navigation between placeholder screens works.

---

## 4) Timer Engine Agent
**Purpose**: Implement accurate 25/5 countdowns with pause/stop and manual break start.

**Inputs**: Engine requirements; UI events.

**Outputs**:
- Timer utilities using **timestamp-diff** from a captured `startedAt` reference.
- State machine: `Idle → FocusActive → FocusComplete → BreakReady → BreakActive → BreakComplete → Idle`.
- Enforce **fixed durations**; expose events `startFocus`, `completeFocus`, `startBreak`, `completeBreak`, `pause`, `stop`, `skipBreak`.

**Guardrails**: No auto-start of break; no long break; clamp drift.

**Acceptance**: Simulated 25‑minute runs remain within ±2s; events produce correct session records.

---

## 5) Notifications Agent
**Purpose**: Ensure scheduled local notifications fire at end-of-focus and end-of-break when app is backgrounded/terminated.

**Inputs**: Platform capabilities (iOS/Android), permissions strategy.

**Outputs**:
- Permission flow; Android channel; schedule at `start + 25m` / `start + 5m`.
- Handlers for notification taps (route the user to the right screen/state).

**Guardrails**: No push reliance for core timing; local notifications are mandatory.

**Acceptance**: Manual QA matrix passes across iOS/Android with app killed/backgrounded.

---

## 6) Offline Sync Agent
**Purpose**: Capture sessions offline in SQLite and sync to Supabase when online.

**Inputs**: Repository interfaces; conflict strategy.

**Outputs**:
- Local queues; upsert logic to Supabase with idempotency via `(device_id, started_at)`.
- Last-write-wins; retry with exponential backoff; connectivity listeners.

**Guardrails**: Never block UI on network; don’t duplicate sessions.

**Acceptance**: Airplane-mode test passes with multi-session backlog syncing correctly.

---

## 7) i18n Agent
**Purpose**: Multilingual UI (EN/HI/TA) with Indic-friendly fonts.

**Inputs**: Copy deck; key names; language switch UX.

**Outputs**:
- `en.json`, `hi.json`, `ta.json`; runtime language toggle; RTL-safe checks if extended later.

**Guardrails**: Don’t hardcode strings in components.

**Acceptance**: Snapshot tests show strings swap correctly; fonts render on Android.

---

## 8) UI/UX Agent
**Purpose**: Build accessible, minimal UI matching the wireframes.

**Inputs**: Wireframe specs; component list.

**Outputs**:
- Screens: HomeTimer, FocusActive, FocusComplete (manual Start Break), BreakActive, BreakComplete, Stats, Settings, LabelsPicker, Auth.
- Components: Button, Chip (labels), Countdown, Progress, StatCard, EmptyState.

**Guardrails**: No duration controls in Settings; ensure large touch targets; maintain visual calm.

**Acceptance**: Usability checks pass; TalkBack/VoiceOver reads landmarks.

---

## 9) QA & Reliability Agent
**Purpose**: Validate functional flows, background behavior, and offline sync.

**Inputs**: Test matrix; acceptance criteria.

**Outputs**:
- Detox E2E test plan; manual background notification test cases; timer drift unit tests.
- Bug triage rules; performance budget checks.

**Guardrails**: Don’t relax acceptance thresholds without approval.

**Acceptance**: All P0 tests pass (timer accuracy, notifications in background, offline capture & sync).

---

## 10) Release Agent
**Purpose**: Ship confident builds and track health.

**Inputs**: Store metadata; environment config.

**Outputs**:
- Build configs (Android channel IDs, iOS permissions copy), release notes, versioning, feature flags.
- Post-release dashboard: crashes (Sentry), key events (PostHog), retention queries.

**Guardrails**: Respect app store guidelines (no background abuse); clear privacy policy.

**Acceptance**: Signed builds; smoke tests; privacy review checklist complete.

---

## Prompts Library (Copy-Paste Ready)

### P1: Stage 0 Blueprint (No Code)
"""
Generate Stage 0 blueprint for a mobile-only Pomodoro app (Expo + Supabase). Fixed 25/5, manual break start, no long break, labels-only presets, offline-first (SQLite), local notifications for session ends, EN/HI/TA, IST-first. Output: folder map, routes, NFRs, risks, dependency list. Do NOT write code.
"""

### P2: Schema & Contracts (Spec Only)
"""
Produce Supabase SQL DDL (TO APPLY LATER), RLS owner-only, mirrored SQLite schema, and TypeScript interfaces for Profile, Session, ExamPreset. Enforce planned_minutes ∈ {25,5}. No implementation code.
"""

### P3: Timer Engine (Spec → Code Later)
"""
Design a timestamp-diff timer engine with states: Idle → FocusActive → FocusComplete → BreakReady → BreakActive → BreakComplete → Idle. Manual break start only. Define public events and expected side effects. No code yet.
"""

### P4: Notifications (Spec → Code Later)
"""
Specify local notification scheduling for 25/5, permission UX, Android channel, tap-handling routing. Assume Expo Notifications. No code yet.
"""

### P5: Offline Sync (Spec → Code Later)
"""
Define SQLite tables, sync queue, idempotency via (device_id, started_at), conflict resolution (LWW), retry/backoff, connectivity listeners. No code yet.
"""

### P6: UI/UX Build (When Ready)
"""
Map components to screens based on wireframes. Ensure accessibility, large tap targets, clear hierarchy. No duration settings. Prepare a file-by-file generation plan.
"""

---

## Acceptance Criteria (MVP)
- End-of-focus and end-of-break notifications fire on time in background/terminated states.
- Manual break start only; no auto-chaining.
- Fixed durations enforced at state & UI.
- Offline session capture with later Supabase sync under RLS.
- Multilingual switch EN/HI/TA works reliably.

---

## Ops & Configuration Checklist
- Env: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SENTRY_DSN?`, `POSTHOG_KEY?`, `ANDROID_NOTIF_CHANNEL_ID`.
- Privacy: keep only necessary fields; allow user sign-out & local data wipe.
- Monitoring: basic events (session_started/completed, break_started/completed), crash reporting enabled.

---

## Change Control
- Any request to add configurable durations or long breaks must be rejected or explicitly approved as a non-MVP scope change.

