# Copilot Instructions for Pomodoro App

## Project Overview

**Pomodoro App** is a mobile-only productivity timer built with React Native (Expo), TypeScript, and JavaScript. The app implements a fixed 25-minute focus / 5-minute break cycle with multilingual support (English, Hindi, Tamil), offline-first capabilities, and cloud synchronization via Supabase.

**Key Characteristics:**
- React Native + Expo with TypeScript (strict mode enabled)
- Functional components only
- File-based routing via Expo Router
- State management with Zustand
- Material Design 3 theming (no external UI library)
- Offline-first architecture (SQLite + Supabase sync)
- Magic link + OTP authentication

---

## Architecture & Project Structure

### Directory Organization

```
src/
├── app/                 # Expo Router screens (file-based routing)
│   ├── _layout.tsx     # Root layout
│   ├── (auth)/         # Auth group: login, OTP verification
│   ├── (timer)/        # Timer group: focus, break, home
│   ├── (stats)/        # Stats group: analytics dashboard
│   └── (settings)/     # Settings group: preferences, logout
├── components/          # Reusable UI components
│   ├── common/         # Generic components (Button, Card, Chip, etc.)
│   ├── timer/          # Timer-specific components
│   ├── stats/          # Statistics display components
│   └── modals/         # Modal dialogs (LanguageSelector, PermissionPrompt)
├── services/           # Business logic & external integrations
│   ├── supabase/       # Supabase auth & database
│   ├── sqlite/         # SQLite local database & repositories
│   ├── notifications/  # Push notification scheduling
│   ├── sync/           # Offline sync engine
│   ├── timer/          # Timer engine
│   └── connectivity/   # Network status management
├── store/              # Zustand state stores
├── theme/              # Design tokens (colors, typography, spacing)
├── locales/            # i18n translation files (en.json, hi.json, ta.json)
├── types/              # TypeScript type definitions
│   ├── domain.ts      # Business domain types
│   ├── store.ts       # State shape types
│   ├── api.ts         # Supabase API types
│   └── navigation.ts  # Router param lists
└── utils/              # Utilities (date/time, validation, constants)
```

### Import Path Aliases

Use TypeScript path aliases for clean, absolute imports:

```typescript
// ✅ DO
import { Button } from '@components/common/Button';
import { colors } from '@theme/colors';
import { useAuthStore } from '@store/authStore';
import { SESSION_STATUS } from '@utils/constants';

// ❌ AVOID
import { Button } from '../../../../components/common/Button';
```

**Defined Aliases:**
- `@app/*` → `src/app/*`
- `@components/*` → `src/components/*`
- `@theme/*` → `src/theme/*`
- `@locales/*` → `src/locales/*`
- `@services/*` → `src/services/*`
- `@store/*` → `src/store/*`
- `@types/*` → `src/types/*`
- `@utils/*` → `src/utils/*`

---

## TypeScript Guidelines

### Strict Compiler Options

- `"strict": true` — All strict type checks enabled
- `"jsx": "react-jsx"` — Modern JSX transform
- `"forceConsistentCasingInFileNames": true`
- `"resolveJsonModule": true` — For importing JSON files

### Type Annotation Best Practices

#### Always annotate function parameters and return types

```typescript
// ✅ DO
import React from 'react';

interface Props {
  title: string;
  count?: number;
  onPress: () => void;
}

export const MyComponent: React.FC<Props> = ({ title, count = 0, onPress }) => {
  const handlePress = (): void => {
    onPress();
  };

  return <View />;
};

// ❌ AVOID
export const MyComponent = ({ title, count, onPress }) => {
  // Implicit types are not acceptable
};
```

#### Use `React.FC` with explicit Props interface

```typescript
// ✅ DO
interface ButtonProps {
  label: string;
  variant?: 'primary' | 'secondary' | 'tertiary';
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ label, variant = 'primary', disabled }) => {
  // ...
};

// ❌ AVOID (mixing implicit and explicit typing)
export const Button = (props: any) => {
  // ...
};
```

#### Prefer discriminated unions for variant props

```typescript
// ✅ DO
type ButtonProps = 
  | { variant: 'primary'; color?: never } 
  | { variant: 'secondary'; color: string };

export const Button: React.FC<ButtonProps> = (props) => {
  if (props.variant === 'secondary') {
    // TypeScript knows color exists here
    console.log(props.color);
  }
};

// ❌ AVOID
interface ButtonProps {
  variant: string;
  color?: string;
}
```

#### Use `const` assertions for literal types

```typescript
// ✅ DO
const SESSION_STATUS = {
  FOCUS: 'focus',
  BREAK: 'break',
} as const;

type SessionStatus = typeof SESSION_STATUS[keyof typeof SESSION_STATUS];

// ❌ AVOID
const SESSION_STATUS = {
  FOCUS: 'focus',
  BREAK: 'break',
};
// Type is inferred as string, not literal
```

---

## Functional Components & Hooks

### Component Structure

Always use functional components with modern React patterns:

```typescript
import React, { useState, useCallback, useEffect } from 'react';
import { View, Text } from 'react-native';
import { useTranslation } from 'react-i18next';
import { Button } from '@components/common/Button';

interface CounterProps {
  initialValue?: number;
  onCountChange?: (count: number) => void;
}

export const Counter: React.FC<CounterProps> = ({ initialValue = 0, onCountChange }) => {
  const { t } = useTranslation();
  const [count, setCount] = useState<number>(initialValue);

  useEffect(() => {
    onCountChange?.(count);
  }, [count, onCountChange]);

  const handleIncrement = useCallback((): void => {
    setCount((prev) => prev + 1);
  }, []);

  return (
    <View>
      <Text>{count}</Text>
      <Button label={t('increment')} onPress={handleIncrement} />
    </View>
  );
};
```

### Hook Rules

1. **Always use `useCallback` for stable function references:**
   ```typescript
   // ✅ DO
   const handlePress = useCallback(() => {
     doSomething();
   }, [dependency]);

   // ❌ AVOID (function recreated on every render)
   const handlePress = () => {
     doSomething();
   };
   ```

2. **Use `useEffect` for side effects with proper dependencies:**
   ```typescript
   // ✅ DO
   useEffect(() => {
     const subscription = store.subscribe(handleChange);
     return () => subscription.unsubscribe();
   }, [handleChange]);

   // ❌ AVOID (missing dependencies)
   useEffect(() => {
     subscription.subscribe(handleChange);
   });
   ```

3. **Extract custom hooks for reusable logic:**
   ```typescript
   // ✅ DO (in hooks/useTimerFormat.ts)
   export const useTimerFormat = (): string => {
     const [formatted, setFormatted] = useState('00:00');
     // Logic here
     return formatted;
   };

   // Usage
   const formattedTime = useTimerFormat();
   ```

---

## Best Practices

### Accessibility (a11y)

1. **Use semantic accessible properties:**
   ```typescript
   // ✅ DO
   <TouchableOpacity
     accessibilityRole="button"
     accessibilityLabel={t('startTimer')}
     accessibilityHint={t('startsAFocusSession')}
     onPress={handleStart}
   >
     <Text>{t('start')}</Text>
   </TouchableOpacity>

   // ❌ AVOID
   <TouchableOpacity onPress={handleStart}>
     <Text>S</Text>
   </TouchableOpacity>
   ```

2. **Ensure sufficient color contrast:**
   - Use the theme colors in `@theme/colors.ts`
   - Test contrast ratios for compliance with WCAG AA (4.5:1 for text)

3. **Support screen reader announcements:**
   ```typescript
   import { AccessibilityInfo } from 'react-native';

   useEffect(() => {
     AccessibilityInfo.announceForAccessibility(
       t('focusSessionStarted')
     );
   }, [isActive]);
   ```

4. **Make interactive elements easily tappable:**
   - Minimum touch target: 44x44 points
   - Use `hitSlop` for small buttons:
     ```typescript
     <TouchableOpacity hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
     ```

### Performance Optimization

1. **Memoize expensive components:**
   ```typescript
   // ✅ DO
   export const StatCard = React.memo(({ stat }: Props) => {
     // Prevents re-render if prop unchanged
     return null;
   });

   // Specify custom comparison
   export const MemoComponent = React.memo(Component, (prevProps, nextProps) => {
     return prevProps.id === nextProps.id; // Return true to skip re-render
   });
   ```

2. **Optimize list rendering with FlatList:**
   ```typescript
   // ✅ DO
   import { FlatList } from 'react-native';

   <FlatList
     data={items}
     keyExtractor={(item) => item.id}
     renderItem={({ item }) => <Item data={item} />}
     removeClippedSubviews={true}
     maxToRenderPerBatch={10}
     updateCellsBatchingPeriod={50}
   />

   // ❌ AVOID (ScrollView with map)
   <ScrollView>
     {items.map((item) => <Item key={item.id} data={item} />)}
   </ScrollView>
   ```

3. **Lazy-load images with `expo-image`:**
   ```typescript
   import { Image } from 'expo-image';

   // ✅ DO
   <Image
     source={imageUrl}
     cachePolicy="memory-disk"
     contentFit="cover"
     transition={500}
   />
   ```

4. **Avoid inline object/function creation in styles:**
   ```typescript
   // ✅ DO
   const styles = StyleSheet.create({
     button: { paddingVertical: spacing[3] },
   });

   // ❌ AVOID (recreated on every render)
   style={{ paddingVertical: spacing[3] }}
   ```

5. **Use `useMemo` for expensive computations:**
   ```typescript
   // ✅ DO
   const filteredSessions = useMemo(() => {
     return sessions.filter((s) => s.date > startDate);
   }, [sessions, startDate]);
   ```

### Error Handling

1. **Use ErrorBoundary for component errors:**
   ```typescript
   import { ErrorBoundary } from '@components/common/ErrorBoundary';

   <ErrorBoundary fallback={<ErrorUI />}>
     <RiskyComponent />
   </ErrorBoundary>
   ```

2. **Handle async errors in async operations:**
   ```typescript
   // ✅ DO
   const handleAuth = async (): Promise<void> => {
     try {
       setError(null);
       setLoading(true);
       await performAuth();
     } catch (err) {
       const message = err instanceof Error ? err.message : 'Unknown error';
       setError(message);
     } finally {
       setLoading(false);
     }
   };
   ```

3. **Log errors appropriately:**
   ```typescript
   // ✅ DO
   if (__DEV__) {
     console.error('Failed to sync:', error);
   }
   // Don't expose sensitive errors to users
   ```

---

## Specific Libraries & Integrations

### Expo Router (File-Based Routing)

**Purpose:** Navigation with file-based routing structure

**Usage:**
```typescript
// File: src/app/(timer)/index.tsx
import { useRouter } from 'expo-router';

export default function HomeTimer() {
  const router = useRouter();

  const handleStartFocus = () => {
    router.push('/(timer)/focus-active');
  };

  return <View>{/* UI */}</View>;
}
```

**Key Points:**
- Directory structure defines routes automatically
- Groups `(name)/` are for organization, not URL segments
- Use `useRouter()` hook for navigation
- Pass typed params via router.push() using navigation.ts types

### Zustand (State Management)

**Purpose:** Global state management for timer, auth, notifications, sync

**Store Structure:**
```typescript
import { create } from 'zustand';

interface TimerState {
  // State
  duration: number;
  isActive: boolean;
  // Methods
  start: () => void;
  pause: () => void;
  reset: () => void;
}

export const useTimerStore = create<TimerState>((set, get) => ({
  duration: 1500,
  isActive: false,

  start: () => set({ isActive: true }),
  pause: () => set({ isActive: false }),
  reset: () => set({ duration: 1500, isActive: false }),
}));
```

**Usage in Components:**
```typescript
// ✅ DO (select specific properties to avoid unnecessary re-renders)
const isActive = useTimerStore((state) => state.isActive);
const pause = useTimerStore((state) => state.pause);

// ❌ AVOID (subscribes to entire store)
const state = useTimerStore();
```

**Best Practices:**
- Keep stores focused (one concern per store)
- Use selector functions for derived state
- Persist state to AsyncStorage when needed
- Type all state explicitly

### React-i18next (Internationalization)

**Purpose:** Multi-language support (English, Hindi, Tamil)

**Setup (already configured in `i18n.ts`):**
```typescript
import { useTranslation } from 'react-i18next';

export const MyScreen: React.FC = () => {
  const { t, i18n } = useTranslation();

  const handleLanguageChange = (lang: 'en' | 'hi' | 'ta'): void => {
    i18n.changeLanguage(lang);
  };

  return <Text>{t('startTimer')}</Text>;
};
```

**Adding New Translations:**
1. Add key-value pairs to `src/locales/en.json`, `hi.json`, `ta.json`
2. Use `t('key')` in components
3. For interpolation: `t('greeting', { name: 'Hari' })`

**Translation File Structure:**
```json
{
  "common": {
    "start": "Start",
    "pause": "Pause"
  },
  "timer": {
    "focus": "Focus Session",
    "break": "Break Time"
  }
}
```

### Supabase (Backend & Auth)

**Purpose:** Authentication (magic link + OTP), cloud database sync

**Initialization (in `services/supabase/client.ts`):**
```typescript
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const SUPABASE_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
```

**Usage Pattern:**
```typescript
// Magic link auth
const { error } = await supabase.auth.signInWithOtp({
  email: userEmail,
  options: { shouldCreateUser: true },
});

// Fetch data
const { data, error } = await supabase
  .from('sessions')
  .select('*')
  .eq('user_id', userId);

// Real-time subscription
const subscription = supabase
  .channel('sessions')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'sessions' }, (payload) => {
    // Handle changes
  })
  .subscribe();

// Cleanup
await supabase.removeChannel(subscription);
```

**Best Practices:**
- Always handle errors from Supabase calls
- Use `.eq()`, `.in()`, `.gt()` for filtering (not client-side)
- Cache auth tokens securely
- Handle offline-first scenarios (sync later)

### SQLite (Offline-First Local Database)

**Purpose:** Store sessions, profiles, presets locally for offline access

**Setup (in `services/sqlite/db.ts`):**
```typescript
import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabaseSync('pomodoro.db');

export const initDatabase = async (): Promise<void> => {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      duration_minutes INT,
      created_at DATETIME,
      synced BOOLEAN DEFAULT 0
    );
  `);
};
```

**Repository Pattern (in `sqlite/repositories/`):**
```typescript
import * as SQLite from 'expo-sqlite';

export class SessionRepository {
  constructor(private db: SQLite.SQLiteDatabase) {}

  async create(session: Session): Promise<void> {
    const result = await this.db.runAsync(
      'INSERT INTO sessions (id, user_id, duration_minutes) VALUES (?, ?, ?)',
      [session.id, session.userId, session.durationMinutes]
    );
  }

  async findById(id: string): Promise<Session | null> {
    const result = await this.db.getFirstAsync<Session>(
      'SELECT * FROM sessions WHERE id = ?',
      [id]
    );
    return result || null;
  }
}
```

### Expo Notifications

**Purpose:** Push notifications for focus/break session reminders

**Pattern:**
```typescript
import * as Notifications from 'expo-notifications';

export const scheduleNotification = async (
  title: string,
  body: string,
  secondsFromNow: number
): Promise<string> => {
  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: 'default',
    },
    trigger: { seconds: secondsFromNow, type: 'time' },
  });
  return id;
};

// Handle notification response
Notifications.addNotificationResponseReceivedListener((response) => {
  const data = response.notification.request.content.data;
  // Navigate or update state based on data
});
```

### Theme System

**Purpose:** Centralized design tokens (Material Design 3)

**Colors (`src/theme/colors.ts`):**
```typescript
export const colors = {
  primary: '#E73C1D',       // Red
  secondary: '#008080',      // Teal
  neutral: { light: '#F5F5F5', dark: '#1A1A1A' },
  semantic: { success: '#4CAF50', error: '#F44336', warning: '#FF9800' },
};
```

**Usage:**
```typescript
// ✅ DO
import { colors } from '@theme/colors';
import { spacing } from '@theme/spacing';
import { typography } from '@theme/typography';

const styles = StyleSheet.create({
  button: {
    backgroundColor: colors.primary,
    paddingVertical: spacing[3],
    ...typography.labelLarge,
  },
});

// ❌ AVOID (hardcoded values)
const styles = StyleSheet.create({
  button: {
    backgroundColor: '#E73C1D',
    paddingVertical: 12,
  },
});
```

---

## Code Style & Naming Conventions

### File Naming

- **Components:** PascalCase (`Button.tsx`, `TimerDisplay.tsx`)
- **Screens:** PascalCase with `-layout` suffix for Expo Router layouts (`_layout.tsx`)
- **Hooks:** camelCase with `use` prefix (`useTimerFormat.ts`)
- **Types:** PascalCase (`domain.ts`, `navigation.ts`)
- **Utilities & Services:** camelCase (`validators.ts`, `dateTime.ts`)

### Variable Naming

```typescript
// ✅ DO
const focusSessionTimer = 1500;
const isFocusActive = true;
const onSessionComplete = () => {};
const handleStartPress = () => {};

// ❌ AVOID
const timer = 1500;            // Too generic
const active = true;            // Unclear what's active
const callback = () => {};      // Non-specific callback name
const func = () => {};          // Non-descriptive
```

### Import Organization

```typescript
// Order: React → External → Aliases → Relative
import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import { Button } from '@components/common/Button';
import { useTimerStore } from '@store/timerStore';
import { SESSION_STATUS } from '@utils/constants';
import { calculateTimeRemaining } from './utils';
```

### Comment Guidelines

```typescript
// ✅ DO (explain why, not what)
// Reset timer to default because user navigated back
const handleNavigationBack = (): void => {
  resetTimer();
};

// ❌ AVOID (stating the obvious)
// Set active to false
setActive(false);
```

---

## Common Patterns

### Pattern: Controlled Component with Optional Default

```typescript
interface ControlledInputProps {
  value: string;
  onChange: (value: string) => void;
  defaultValue?: string;
}

export const ControlledInput: React.FC<ControlledInputProps> = ({
  value,
  onChange,
  defaultValue = '',
}) => {
  return (
    <TextInput
      value={value}
      onChangeText={onChange}
      placeholder={defaultValue}
    />
  );
};
```

### Pattern: Async State Management

```typescript
interface AsyncState<T> {
  data: T | null;
  isLoading: boolean;
  error: string | null;
}

const useAsyncData = <T,>(fetcher: () => Promise<T>): AsyncState<T> => {
  const [state, setState] = useState<AsyncState<T>>({
    data: null,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    (async () => {
      try {
        setState((prev) => ({ ...prev, isLoading: true }));
        const data = await fetcher();
        setState({ data, isLoading: false, error: null });
      } catch (error) {
        setState({
          data: null,
          isLoading: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    })();
  }, [fetcher]);

  return state;
};
```

### Pattern: Conditional Rendering with Guard Clauses

```typescript
// ✅ DO (early returns)
export const TimerScreen: React.FC = () => {
  const { isLoading, data, error } = useAsyncData(fetchSessions);

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorUI message={error} />;
  if (!data) return null;

  return <TimerList sessions={data} />;
};

// ❌ AVOID (nested ternaries)
export const TimerScreen: React.FC = () => {
  const { isLoading, data, error } = useAsyncData(fetchSessions);

  return isLoading ? <LoadingSpinner /> : error ? <ErrorUI /> : <TimerList />;
};
```

---

## Testing & Validation

### Type Checking

```bash
# Run TypeScript compiler
npm run type-check
```

### Linting

```bash
# Run ESLint
npm run lint
```

### Running Tests

```bash
# Jest unit tests
npm test

# E2E tests (if configured)
npm run test:e2e
```

### Validation Utilities

Use functions from `@utils/validators.ts`:

```typescript
import { 
  validateEmail, 
  validatePhone, 
  validateOTP, 
  sanitizeLabel 
} from '@utils/validators';

// ✅ DO
if (!validateEmail(email)) {
  setError(t('invalidEmail'));
  return;
}

const cleanLabel = sanitizeLabel(userInput);
```

---

## Development Workflow

### Starting Development

```bash
# Install dependencies
npm install

# Start dev server
npm start

# Run on specific platform
npm run ios
npm run android
```

### Before Committing

```bash
# Type check
npm run type-check

# Lint code
npm run lint

# Test
npm test
```

### Building for Deployment

```bash
# iOS
npm run build-ios

# Android
npm run build-android
```

---

## Troubleshooting & Common Issues

### Issue: Component not re-rendering after state change

**Cause:** Missing dependency in `useCallback` or `useEffect`

**Solution:**
```typescript
// Run ESLint with hooks plugin to catch this
// Add all dependencies to dependency array
useEffect(() => {
  doSomething(value);
}, [value]); // Include value in deps
```

### Issue: "Cannot find module" with path aliases

**Cause:** TypeScript cache or build issue

**Solution:**
```bash
npm run type-check  # Verify aliases are correct
rm -rf node_modules .expo  # Clean cache
npm install
```

### Issue: Zustand store not updating components

**Cause:** Not using selector functions

**Solution:**
```typescript
// ✅ DO (use selector to subscribe to specific property)
const state = useTimerStore((s) => ({ isActive: s.isActive, start: s.start }));

// ❌ AVOID (subscribes to entire store)
const state = useTimerStore();
```

---

## Summary of Key Rules

1. **Always use TypeScript** with strict mode; annotate all function signatures
2. **Use only functional components** with React hooks
3. **Use path aliases** for all imports (`@components/*`, `@utils/*`, etc.)
4. **Memoize components and callbacks** to prevent unnecessary re-renders
5. **Handle errors explicitly** with try-catch and ErrorBoundary
6. **Follow Material Design 3** with theme colors/typography/spacing
7. **Use Zustand stores** for global state (timer, auth, sync, notifications)
8. **Use Expo Router groups** for organizing screens
9. **Support accessibility** with semantic roles, labels, and contrast
10. **Optimize performance** with React.memo, useMemo, FlatList for lists
11. **Maintain i18n** for all user-facing strings (en, hi, ta)
12. **Use SQLite repositories** for offline-first data access
13. **Keep components small** and focused on a single responsibility
14. **Comment on the why**, not the what
15. **Run type-check and lint** before committing code

---

## Resources

- [React Native Docs](https://reactnative.dev)
- [Expo Documentation](https://docs.expo.dev)
- [Expo Router](https://expo.dev/router)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)
- [Zustand Docs](https://github.com/pmndrs/zustand)
- [React-i18next](https://react.i18next.com)
- [Supabase JS Client](https://supabase.com/docs/reference/javascript)
- [Material Design 3](https://m3.material.io)
