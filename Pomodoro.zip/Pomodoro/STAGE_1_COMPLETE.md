# Pomodoro App — Stage 1 Complete ✅

## Overview
Mobile-only Pomodoro timer for India using React Native (Expo), TypeScript, and Supabase.

**Fixed Cycle:** 25 min focus → Manual 5 min break  
**Languages:** English, Hindi, Tamil (in-app toggle)  
**Offline-First:** SQLite local storage + Supabase sync  
**Auth:** Supabase magic link + phone OTP  

---

## What's Been Built (Stage 1)

### ✅ Project Setup
- `package.json` — All dependencies (React Native, Expo, Zustand, i18next, Supabase JS SDK)
- `app.json` — Expo configuration with iOS/Android platform setup
- `.gitignore`, `eas.json`, `tsconfig.json`

### ✅ UI & Theme
- **Colors:** Primary (red), Secondary (teal), Neutral grays, Semantic (success, error, warning)
- **Typography:** Material Design 3 scales (display, headline, title, body, label)
- **Spacing:** 4px-based scale (0–96)
- **Components:**
  - `Button` (primary/secondary/tertiary variants, lg/md/sm sizes)
  - `Chip` (preset/custom labels)
  - `Countdown` (MM:SS display)
  - `Card` (shadow, rounded)
  - `LoadingSpinner`
  - `ErrorBoundary`
  - Timer-specific: `TimerDisplay`, `SessionControls`, `BreakStartCTA`
  - Stats: `StatCard`, `StreakCard`, `WeeklyHistogram`, `TopLabelsBar`
  - Modals: `PermissionPrompt`, `LanguageSelector`

### ✅ Internationalization
- **Languages:** English (en.json), Hindi (hi.json), Tamil (ta.json)
- **i18next integration** with device locale auto-detection
- **Strings for:** Auth, Timer, Presets, Stats, Settings, Notifications, Common UI

### ✅ Routing (Expo Router)
- **Root:** `src/app/_layout.tsx` — Session check, splash handling
- **Auth Group:** `(auth)/` → AuthScreen, OTPVerifyScreen
- **Timer Group:** `(timer)/` → HomeTimer, FocusActive, FocusComplete, BreakActive, BreakComplete
- **Stats Group:** `(stats)/` → StatsScreen
- **Settings Group:** `(settings)/` → SettingsScreen

### ✅ Placeholder Screens
All screens are **functional placeholders** with correct routing and UI structure:
- **Auth:** Email/OTP entry flows (Supabase integration pending)
- **HomeTimer:** Start Focus button, 25m countdown display
- **FocusActive:** Timer countdown, Pause/Stop/Skip controls
- **FocusComplete:** Label picker (presets + custom), "Start Break" CTA
- **BreakActive:** 5m timer, controls
- **BreakComplete:** Auto-return to home after 3s
- **Stats:** Placeholder KPIs (today's count, total minutes, streak, weekly histogram, top labels)
- **Settings:** Language selector, notification toggle, logout

### ✅ Types & Utilities
- **Domain types:** `Session`, `TimerState`, `Profile`, `ExamPreset`, `StatsAggregate`, `SyncQueue`
- **Store types:** `TimerStoreState`, `SyncStoreState`, `AuthStoreState`, `NotificationStoreState`
- **Utilities:**
  - `dateTime.ts` — IST formatting, day/week ranges
  - `device.ts` — Device ID generation (AsyncStorage-based)
  - `validators.ts` — Email, phone, OTP, label validation
  - `constants.ts` — Durations, statuses, session types, presets

---

## Next Steps: Stage 2 (When Ready)

### Domain State & Timer Engine
- [ ] Zustand stores for timer, sync, auth, notifications
- [ ] Timer engine (monotonic timestamp-diff approach)
- [ ] State machine for focus/break/pause/stop
- [ ] Pause/resume/skip logic
- [ ] Background-resilient timer handling

### Deliverable
- Fully functional timer with pause/resume
- State persistence across app restarts (in-memory + SQLite prep)
- Proper time display and session transitions

---

## File Structure Summary

```
src/
├── app/                  # Expo Router structure
│   ├── _layout.tsx       # Root navigation
│   ├── (auth)/           # Auth flow screens
│   ├── (timer)/          # Timer screens
│   ├── (stats)/          # Stats screen
│   └── (settings)/       # Settings screen
├── components/
│   ├── common/           # Button, Chip, Countdown, Card, etc.
│   ├── timer/            # TimerDisplay, SessionControls, BreakStartCTA
│   ├── stats/            # StatCard, StreakCard, WeeklyHistogram, TopLabelsBar
│   └── modals/           # PermissionPrompt, LanguageSelector
├── types/                # domain.ts, store.ts, api.ts, navigation.ts
├── utils/                # dateTime, device, validators, constants
├── locales/              # en.json, hi.json, ta.json + i18n.ts
├── theme/                # colors, typography, spacing
└── store/                # (Zustand stores — empty, to be filled in Stage 2)
```

---

## Quick Start

```bash
# Install dependencies
npm install

# Start Expo development server
npm start

# Run on iOS simulator
npm run ios

# Run on Android emulator
npm run android
```

---

## Architecture Notes

### Mobile-First Design
- Portrait orientation only (mobile-first requirement)
- Bottom-sheet/modal interactions for secondary flows
- Touch-friendly button sizes (48dp minimum)

### Offline-First Ready
- All screens are **placeholders** but structured for SQLite integration (Stage 3)
- Zustand stores will manage local state before sync
- Supabase client already in package.json, waiting for init (Stage 3)

### Notification Wiring
- `PermissionPrompt` modal asks for permissions on first run
- Settings toggle for on/off
- Actual scheduling logic deferred to Stage 4

### i18n Ready
- All hardcoded strings replaced with i18n keys
- Language toggle in Settings (immediate UI update pending Zustand store)
- Indic font support (NotoSans Devanagari, Tamil) in app.json

---

## Status: ✅ Stage 1 Complete

**All UI scaffolding, routing, and type definitions are in place. Ready for Stage 2 (state management & timer engine).**

