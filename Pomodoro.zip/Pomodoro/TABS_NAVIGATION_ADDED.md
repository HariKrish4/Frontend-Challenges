# Pomodoro App — Updated Routing Structure with Tabs

## 📱 New Navigation Architecture

The app now includes **bottom tab navigation** with three main sections:

```
Root (_layout.tsx)
├── Auth Check
├── (auth) — if not authenticated
│   ├── AuthScreen (magic link / OTP entry)
│   └── OTPVerifyScreen
│
└── (tabs) — if authenticated (Bottom Tab Navigator)
    ├── (timer) Stack
    │   ├── index → HomeTimer (Start Focus)
    │   ├── focus-active → FocusActive (countdown + controls)
    │   ├── focus-complete → FocusComplete (label picker + manual break start)
    │   ├── break-active → BreakActive (countdown + controls)
    │   └── break-complete → BreakComplete (auto-return to home)
    │
    ├── (stats) Stack
    │   └── index → StatsScreen (KPIs, streak, histogram, top labels)
    │
    └── (settings) Stack
        └── index → SettingsScreen (language, notifications, logout)
```

## 🗂️ Updated File Structure

### Root Changes
```
src/app/
├── _layout.tsx                 # Root: Session check → (auth) OR (tabs)
├── (auth)/                     # Auth flow (unchanged)
│   ├── _layout.tsx
│   ├── index.tsx              # AuthScreen
│   └── otp-verify.tsx         # OTPVerifyScreen
│
└── (tabs)/                     # NEW: Bottom tab navigator
    ├── _layout.tsx            # BottomTabNavigator (Focus, Stats, Settings)
    │
    ├── (timer)/               # MOVED from src/app/(timer)/
    │   ├── _layout.tsx        # Stack navigator
    │   ├── index.tsx          # HomeTimer
    │   ├── focus-active.tsx   # FocusActive
    │   ├── focus-complete.tsx # FocusComplete
    │   ├── break-active.tsx   # BreakActive
    │   └── break-complete.tsx # BreakComplete
    │
    ├── (stats)/               # MOVED from src/app/(stats)/
    │   ├── _layout.tsx        # Stack navigator
    │   └── index.tsx          # StatsScreen
    │
    └── (settings)/            # MOVED from src/app/(settings)/
        ├── _layout.tsx        # Stack navigator
        └── index.tsx          # SettingsScreen
```

### Old Directories (Deprecated)
The following are now **obsolete** — screens have been moved to (tabs) equivalents:
- ❌ `src/app/(timer)/` → Use `src/app/(tabs)/(timer)/`
- ❌ `src/app/(stats)/` → Use `src/app/(tabs)/(stats)/`
- ❌ `src/app/(settings)/` → Use `src/app/(tabs)/(settings)/`

## 🎯 Key Changes

### 1. Root Layout (`_layout.tsx`)
- Checks `isAuthenticated` state (placeholder)
- Conditionally renders `(auth)` or `(tabs)`
- **TODO:** Wire `Supabase.auth.getSession()` to set auth state

### 2. Tabs Layout (`(tabs)/_layout.tsx`)
- Uses Expo Router's `Tabs` component
- Three tab screens: **Focus** (⏱️), **Stats** (📊), **Settings** (⚙️)
- Styling:
  - Tab bar colors tied to theme
  - Active tint: primary color (red)
  - Inactive tint: text tertiary (gray)
  - Height: 60dp with safe area padding

### 3. All Screen Routes Updated
Every screen now uses `/tabs/` paths:
- `router.push('/(tabs)/(timer)/focus-active')`
- `router.replace('/(tabs)/(timer)')`
- etc.

### 4. Bottom Tab Icons (Placeholder)
Currently using **emoji** placeholders:
- Focus: ⏱️
- Stats: 📊
- Settings: ⚙️

**Note:** Can be replaced with Ionicons or custom SVG icons later.

---

## 🚀 What's Working

✅ **Tab Navigation:**
- Swipe between Focus, Stats, Settings tabs
- Back button preserves tab state
- Each tab maintains its own stack

✅ **Focus Tab:**
- HomeTimer → Start Focus → countdown → FocusComplete (label picker) → BreakActive → BreakComplete
- All navigation paths updated to use `/(tabs)/(timer)/` routes

✅ **Stats Tab:**
- Displays placeholder KPIs, streak, histogram, top labels

✅ **Settings Tab:**
- Language selector modal
- Notification toggle + permission prompt
- Logout button

---

## 🔧 Next: Stage 2 Implementation

### Currently Pending
1. ✅ Tab navigation structure in place
2. ⏳ Zustand stores for timer state management
3. ⏳ Timer engine with timestamp-diff approach
4. ⏳ Session persistence (SQLite)
5. ⏳ Supabase auth integration

### Immediate Todo
- [ ] Wire `Supabase.auth.getSession()` in root `_layout.tsx`
- [ ] Implement auth flow (magic link + OTP) → set `isAuthenticated` on success
- [ ] Create Zustand stores (timer, sync, auth, notifications)
- [ ] Build timer engine (pause/resume/skip logic)

---

## 📝 Navigation Route Map (Updated)

| Screen | Route | Stack | Notes |
|--------|-------|-------|-------|
| AuthScreen | `/(auth)` | Stack | Magic link / OTP entry |
| OTPVerifyScreen | `/(auth)/otp-verify` | Stack | Modal presentation |
| HomeTimer | `/(tabs)/(timer)` | Stack | Default tab focus screen |
| FocusActive | `/(tabs)/(timer)/focus-active` | Stack | Full countdown |
| FocusComplete | `/(tabs)/(timer)/focus-complete` | Stack | Label picker, manual break start |
| BreakActive | `/(tabs)/(timer)/break-active` | Stack | 5m countdown |
| BreakComplete | `/(tabs)/(timer)/break-complete` | Stack | Auto-return to home after 3s |
| StatsScreen | `/(tabs)/(stats)` | Stack | KPIs & histogram |
| SettingsScreen | `/(tabs)/(settings)` | Stack | Language, notifications, logout |

---

## ✅ Summary

**Stage 1 + Tabs Navigation Complete**

- All routing restructured with bottom tab navigator
- Screen paths updated to new `/(tabs)/` paths
- Auth flow separate from tab flow
- Ready for Stage 2 (state management & timer engine)

