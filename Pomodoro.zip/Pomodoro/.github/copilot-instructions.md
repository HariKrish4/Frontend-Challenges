# Project Guidelines

## Code Style
- Framework: Expo + React Native + TypeScript (`expo` 54, `react-native` 0.81). Prefer functional components and hooks.
- Use theme tokens from `src/theme/colors.ts`, `src/theme/spacing.ts`, `src/theme/typography.ts`; avoid hardcoded styling values.
- Follow existing alias imports from `babel.config.js` (`@components`, `@store`, `@services`, `@hooks`, `@appTypes`, etc.).
- Keep logic in hooks/stores/services, and keep screens mostly for composition/navigation (see `src/app/(tabs)/(timer)/focus-active.tsx` + `src/hooks/useTimer.ts`).
- Zustand stores are typed with domain/store interfaces in `src/types/domain.ts` and `src/types/store.ts`.

## Architecture
- Routing uses Expo Router with route groups under `src/app`: `(auth)` and `(tabs)` are the active app flow.
- Root bootstrap in `src/app/_layout.tsx`: runs session recovery, checks auth, controls initial stack.
- Timer flow is store + service driven: `src/store/timerStore.ts` uses pure time math in `src/services/timer/TimerEngine.ts`.
- Session recovery persists timer snapshots via AsyncStorage in `src/services/persistence/SessionPersistence.ts`.
- Stores are the state boundary: `authStore`, `timerStore`, `syncStore`, `profileStore`, `notificationStore`.

## Build and Test
- Install deps: `npm install`
- Start dev server: `npm run start`
- Platform launch: `npm run ios`, `npm run android`, `npm run web`
- Lint: `npm run lint`
- Type-check: `npm run type-check`
- Unit tests: `npm run test`
- E2E (Detox): `npm run test:e2e`
- EAS builds: `npm run build-ios`, `npm run build-android`

## Project Conventions
- Timer accuracy: compute from timestamps (not interval counters). Use helpers in `src/services/timer/TimerEngine.ts`.
- Persist/restore active sessions through `SessionPersistence` from store actions (`start/pause/resume/complete/recover`).
- Route paths in tab timer flow should stay under `/(tabs)/(timer)/...` (see `src/app/(tabs)/(timer)/*`).
- i18n resources are in `src/locales/{en,hi,ta}.json`; bootstrap is `src/locales/i18n.ts`.
- Some docs are outdated (`PROJECT_INDEX.md`, `STAGE_1_COMPLETE.md`, `TABS_NAVIGATION_ADDED.md`); prefer source code over stage docs.

## Integration Points
- Notifications: `expo-notifications` configured in `app.json`; app-level permission prompt exists in `src/components/modals/PermissionPrompt.tsx`.
- Auth/sync/profile stores contain staged TODOs for Supabase-backed flows (`src/store/authStore.ts`, `src/store/syncStore.ts`, `src/store/profileStore.ts`).
- Device identity is generated via `src/utils/device.ts` and attached to sessions in timer flows.
- Network/sync and notification scheduling hooks exist (`src/hooks/useSync.ts`, `src/hooks/useNotifications.ts`) but are partially stubbed.

## Security
- Do not hardcode API keys/secrets in source or instructions; use Expo/EAS environment configuration.
- Treat auth as incomplete: `authStore` methods are currently placeholders; avoid assuming real session guarantees.
- Validate and sanitize user input via existing utilities (e.g., `src/utils/validators.ts`) before persistence or remote sync.
- Keep persisted payloads minimal and scoped to timer recovery data (`PERSISTENCE_KEYS.SESSION_STATE`).
