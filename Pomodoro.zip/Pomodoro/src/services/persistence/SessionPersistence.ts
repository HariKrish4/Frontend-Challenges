/**
 * Session Persistence Service
 * Handles AsyncStorage save/load operations for timer recovery
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { PERSISTENCE_KEYS } from '@utils/constants';
import { PersistencePayload } from '@appTypes/db';
import { TimerSnapshot } from '../timer/TimerEngine';

/**
 * Save session state to AsyncStorage for recovery
 */
export const saveSessionState = async (state: TimerSnapshot): Promise<void> => {
  try {
    const payload: PersistencePayload = {
      timer: {
        status: state.status,
        sessionType: state.sessionType,
        plannedMinutes: state.plannedMinutes,
        label: state.label,
        startedAtMs: state.startedAtMs,
        pausedAtMs: state.pausedAtMs,
        resumedAtMs: state.resumedAtMs,
        totalPausedMs: state.totalPausedMs,
      },
      savedAt: Date.now(),
    };
    await AsyncStorage.setItem(
      PERSISTENCE_KEYS.SESSION_STATE,
      JSON.stringify(payload)
    );
  } catch (err) {
    console.error('Failed to save session state:', err);
    throw err;
  }
};

/**
 * Load session state from AsyncStorage
 * Returns null if no saved state or if state is invalid
 */
export const loadSessionState = async (): Promise<TimerSnapshot | null> => {
  try {
    const data = await AsyncStorage.getItem(PERSISTENCE_KEYS.SESSION_STATE);
    if (!data) return null;

    const payload = JSON.parse(data) as PersistencePayload;
    
    // Validate structure
    if (!payload.timer || !payload.timer.status) {
      return null;
    }

    return {
      status: payload.timer.status,
      sessionType: payload.timer.sessionType,
      plannedMinutes: payload.timer.plannedMinutes,
      label: payload.timer.label,
      startedAtMs: payload.timer.startedAtMs,
      pausedAtMs: payload.timer.pausedAtMs,
      resumedAtMs: payload.timer.resumedAtMs,
      totalPausedMs: payload.timer.totalPausedMs,
      completedAtMs: undefined,
      savedAt: payload.savedAt,
    };
  } catch (err) {
    console.error('Failed to load session state:', err);
    return null;
  }
};

/**
 * Clear saved session state
 */
export const clearSessionState = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(PERSISTENCE_KEYS.SESSION_STATE);
  } catch (err) {
    console.error('Failed to clear session state:', err);
    throw err;
  }
};

/**
 * Check if saved session state is stale
 * @param savedState - The saved timer snapshot
 * @param plannedMs - The planned session duration in ms
 * @returns true if session has run past its planned duration
 */
export const isSessionStateStale = (
  savedState: TimerSnapshot,
  plannedMs: number
): boolean => {
  if (!savedState.startedAtMs) return false;

  const elapsedMs = Date.now() - savedState.startedAtMs - savedState.totalPausedMs;
  return elapsedMs > plannedMs;
};
