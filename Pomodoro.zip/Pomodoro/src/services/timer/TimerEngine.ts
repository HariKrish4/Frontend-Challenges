/**
 * Timer Engine
 * Pure functional logic for monotonic Timer calculations
 * Avoids setInterval drift by using timestamp differences
 */

/**
 * Calculate elapsed time in milliseconds since session started
 * Accounts for pause/resume cycles
 */
export const calculateElapsed = (
  startedAtMs: number,
  totalPausedMs: number = 0,
  nowMs: number = Date.now()
): number => {
  return Math.max(0, nowMs - startedAtMs - totalPausedMs);
};

/**
 * Calculate remaining time in milliseconds
 */
export const calculateRemaining = (
  plannedMs: number,
  elapsedMs: number
): number => {
  return Math.max(0, plannedMs - elapsedMs);
};

/**
 * Check if session is complete (remaining time <= 0)
 */
export const isSessionComplete = (remainingMs: number): boolean => {
  return remainingMs <= 0;
};

/**
 * Calculate actual minutes and seconds from elapsed time
 */
export const getActualTime = (elapsedMs: number): { minutes: number; seconds: number } => {
  const totalSeconds = Math.floor(elapsedMs / 1000);
  return {
    minutes: Math.floor(totalSeconds / 60),
    seconds: totalSeconds % 60,
  };
};

/**
 * Format milliseconds to MM:SS display string
 * Rounds UP seconds to avoid showing 0:00 too early
 */
export const formatMStoMMSS = (totalMs: number): string => {
  const totalSeconds = Math.ceil(totalMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

/**
 * Snapshot of timer state for serialization/persistence
 */
export interface TimerSnapshot {
  status: 'idle' | 'active' | 'paused' | 'completed';
  sessionType: 'focus' | 'break' | null;
  plannedMinutes: 25 | 5;
  label?: string;
  startedAtMs?: number;
  pausedAtMs?: number;
  resumedAtMs?: number;
  completedAtMs?: number;
  totalPausedMs: number;
  savedAt: number;  // When this snapshot was created
}
