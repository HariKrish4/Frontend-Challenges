import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useAuthStore } from '../store/authStore';

// Keep the splash screen visible while we fetch the initial session
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const checkSession = useAuthStore((state) => state.checkSession);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // TODO: Wire Supabase.auth.getSession() here
        await checkSession();
      } finally {
        // Hide splash screen once we've checked auth
        await SplashScreen.hideAsync();
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, [checkSession]);

  if (isLoading) {
    return null;
  }

  // Conditional rendering based on auth state
  if (!isAuthenticated) {
    return (
      <SafeAreaProvider>
        <Stack screenOptions={{ headerShown: false }} />
      </SafeAreaProvider>
    );
  }

  // If authenticated, render tabs (home screen will handle tabs rendering)
  return (
    <SafeAreaProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      </Stack>
    </SafeAreaProvider>
  );
}
