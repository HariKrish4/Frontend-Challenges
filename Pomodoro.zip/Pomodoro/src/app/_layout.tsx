import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useAuthStore } from '../store/authStore';
import { useSessionRecovery } from '../hooks/useSessionRecovery';

// Keep the splash screen visible while we fetch the initial session
SplashScreen.preventAutoHideAsync();

/**
 * Root layout wrapper that initializes session recovery
 */
function RootLayoutContent() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const checkSession = useAuthStore((state) => state.checkSession);
  const [isLoading, setIsLoading] = useState(true);

  // Recover timer session on app startup
  useSessionRecovery();

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        await checkSession();
      } finally {
        await SplashScreen.hideAsync();
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, [checkSession]);

  if (isLoading) {
    return null;
  }

  // Conditional rendering based on auth state
  if (!isAuthenticated) {
    return (
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      </Stack>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <RootLayoutContent />
    </SafeAreaProvider>
  );
}
