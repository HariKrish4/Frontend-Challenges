import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Button } from '@components/common/Button';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

export default function BreakCompleteScreen() {
  const router = useRouter();

  useEffect(() => {
    // Auto-return to home after 3 seconds
    const timer = setTimeout(() => {
      router.replace('/(timer)');
    }, 3000);

    return () => clearTimeout(timer);
  }, [router]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.emoji}>✨</Text>
        <Text style={styles.title}>Break Complete!</Text>
        <Text style={styles.subtitle}>You're refreshed and ready to go again.</Text>

        <View style={styles.spacer} />

        <Button
          label="Start New Focus"
          onPress={() => router.replace('/(timer)')}
          variant="primary"
          size="lg"
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.secondary,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing[4],
  },
  emoji: {
    fontSize: 60,
    marginBottom: spacing[4],
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.white,
    marginBottom: spacing[2],
    textAlign: 'center',
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.white,
    textAlign: 'center',
    marginBottom: spacing[8],
  },
  spacer: {
    height: spacing[6],
  },
});
