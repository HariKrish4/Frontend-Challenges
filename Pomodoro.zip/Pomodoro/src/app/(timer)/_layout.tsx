import React from 'react';
import { Stack } from 'expo-router';

export default function TimerLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="index" />
      <Stack.Screen name="focus-active" options={{ presentation: 'card' }} />
      <Stack.Screen name="focus-complete" options={{ presentation: 'card' }} />
      <Stack.Screen name="break-active" options={{ presentation: 'card' }} />
      <Stack.Screen name="break-complete" options={{ presentation: 'card' }} />
    </Stack>
  );
}
