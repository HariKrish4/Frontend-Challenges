import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { TimerDisplay } from '@components/timer/TimerDisplay';
import { SessionControls } from '@components/timer/SessionControls';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';
import { BREAK_DURATION } from '@utils/constants';

export default function BreakActiveScreen() {
  const router = useRouter();
  const { sessionId } = useLocalSearchParams<{ sessionId: string }>();
  const [remainingSeconds, setRemainingSeconds] = useState(BREAK_DURATION * 60);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          router.push('/(timer)/break-complete');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, router]);

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleStop = () => {
    router.replace('/(timer)');
  };

  const handleSkip = () => {
    router.push('/(timer)/break-complete');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Break Time</Text>
      </View>

      <TimerDisplay totalSeconds={remainingSeconds} />

      <SessionControls
        onPause={handlePause}
        onStop={handleStop}
        onSkip={handleSkip}
        isPaused={isPaused}
      />

      {isPaused && (
        <View style={styles.pausedBanner}>
          <Text style={styles.pausedText}>Paused</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.secondary,
  },
  header: {
    padding: spacing[4],
    alignItems: 'center',
  },
  title: {
    fontSize: typography.fontSize.xl,
    fontWeight: '700' as const,
    color: colors.white,
  },
  pausedBanner: {
    backgroundColor: colors.warning,
    padding: spacing[2],
    alignItems: 'center',
  },
  pausedText: {
    color: colors.white,
    fontWeight: '600' as const,
  },
});
