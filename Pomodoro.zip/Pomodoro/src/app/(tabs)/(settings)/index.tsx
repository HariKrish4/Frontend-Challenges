import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, Switch } from 'react-native';
import { Button } from '@components/common/Button';
import { Card } from '@components/common/Card';
import { PermissionPrompt } from '@components/modals/PermissionPrompt';
import { LanguageSelector } from '@components/modals/LanguageSelector';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

type Language = 'en' | 'hi' | 'ta';

export default function SettingsScreen() {
  const [language, setLanguage] = useState<Language>('en');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);

  const handleLogout = () => {
    console.log('Logging out');
    // Placeholder: Supabase logout
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
        </View>

        <Card style={styles.card}>
          <View style={styles.setting}>
            <View>
              <Text style={styles.settingLabel}>Language</Text>
              <Text style={styles.settingValue}>
                {language === 'en' ? 'English' : language === 'hi' ? 'हिंदी' : 'தமிழ்'}
              </Text>
            </View>
            <Button
              label="Change"
              onPress={() => setShowLanguageSelector(true)}
              variant="tertiary"
              size="sm"
            />
          </View>
        </Card>

        <Card style={styles.card}>
          <View style={styles.setting}>
            <View>
              <Text style={styles.settingLabel}>Notifications</Text>
              <Text style={styles.settingValue}>
                {notificationsEnabled ? 'Enabled' : 'Disabled'}
              </Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={(value) => {
                setNotificationsEnabled(value);
                if (value) setShowPermissionPrompt(true);
              }}
            />
          </View>
        </Card>

        <Card style={styles.card}>
          <Text style={styles.settingLabel}>App Version</Text>
          <Text style={styles.settingValue}>1.0.0</Text>
        </Card>

        <View style={styles.spacer} />

        <Button
          label="Logout"
          onPress={handleLogout}
          variant="tertiary"
          size="lg"
        />
      </ScrollView>

      <PermissionPrompt
        visible={showPermissionPrompt}
        onClose={() => setShowPermissionPrompt(false)}
        onGranted={() => {
          setShowPermissionPrompt(false);
          console.log('Notifications enabled');
        }}
      />

      <LanguageSelector
        visible={showLanguageSelector}
        selectedLanguage={language}
        onSelectLanguage={setLanguage}
        onClose={() => setShowLanguageSelector(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    padding: spacing[4],
  },
  header: {
    marginBottom: spacing[6],
    alignItems: 'center',
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.textPrimary,
  },
  card: {
    marginBottom: spacing[3],
  },
  setting: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingLabel: {
    fontSize: typography.fontSize.base,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    marginBottom: spacing[1],
  },
  settingValue: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
  },
  spacer: {
    flex: 1,
  },
});
