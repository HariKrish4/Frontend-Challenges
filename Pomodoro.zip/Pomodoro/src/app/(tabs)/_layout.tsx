import React from 'react';
import { BottomTabNavigationOptions } from '@react-navigation/bottom-tabs';
import { Tabs } from 'expo-router';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

// Icon placeholder components (can be replaced with Ionicons)
const TimerIcon = ({ color, size }: { color: string; size: number }) => (
  <div style={{ color, fontSize: size, fontWeight: 'bold' }}>⏱️</div>
);

const StatsIcon = ({ color, size }: { color: string; size: number }) => (
  <div style={{ color, fontSize: size, fontWeight: 'bold' }}>📊</div>
);

const SettingsIcon = ({ color, size }: { color: string; size: number }) => (
  <div style={{ color, fontSize: size, fontWeight: 'bold' }}>⚙️</div>
);

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          height: 60,
          paddingBottom: spacing[2],
          paddingTop: spacing[1],
        },
        tabBarLabelStyle: {
          fontSize: typography.fontSize.xs,
          fontWeight: '500' as const,
          marginTop: spacing[1],
        },
      }}
    >
      <Tabs.Screen
        name="(timer)"
        options={{
          title: 'Focus',
          tabBarIcon: ({ color, size }) => <TimerIcon color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="(stats)"
        options={{
          title: 'Stats',
          tabBarIcon: ({ color, size }) => <StatsIcon color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="(settings)"
        options={{
          title: 'Settings',
          tabBarIcon: ({ color, size }) => <SettingsIcon color={color} size={size} />,
        }}
      />
    </Tabs>
  );
}
