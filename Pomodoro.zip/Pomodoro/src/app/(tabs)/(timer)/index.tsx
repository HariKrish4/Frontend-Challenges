import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Button } from '@components/common/Button';
import { Card } from '@components/common/Card';
import { Countdown } from '@components/common/Countdown';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';
import { FOCUS_DURATION } from '@utils/constants';

export default function HomeTimerScreen() {
  const router = useRouter();

  const handleStartFocus = () => {
    // Placeholder: create session and navigate
    console.log('Starting focus session');
    router.push('/(tabs)/(timer)/focus-active');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.greeting}>Ready to focus?</Text>

        <Card style={styles.card}>
          <Text style={styles.durationLabel}>Focus Session</Text>
          <Countdown totalSeconds={FOCUS_DURATION * 60} variant="large" />
          <Text style={styles.durationText}>25 minutes</Text>
        </Card>

        <Button
          label="Start Focus"
          onPress={handleStartFocus}
          variant="primary"
          size="lg"
          style={styles.button}
        />

        <View style={styles.info}>
          <Text style={styles.infoTitle}>How it works:</Text>
          <Text style={styles.infoText}>• 25 minutes focused work</Text>
          <Text style={styles.infoText}>• 5 minutes break (manual start)</Text>
          <Text style={styles.infoText}>• No interruptions, no configuration</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    padding: spacing[4],
  },
  greeting: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.textPrimary,
    marginBottom: spacing[6],
    textAlign: 'center',
  },
  card: {
    marginBottom: spacing[6],
    alignItems: 'center',
  },
  durationLabel: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    marginBottom: spacing[3],
    fontWeight: '500' as const,
  },
  durationText: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    marginTop: spacing[2],
  },
  button: {
    marginBottom: spacing[6],
  },
  info: {
    backgroundColor: colors.gray50,
    padding: spacing[4],
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    marginBottom: spacing[2],
  },
  infoText: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginVertical: spacing[1],
  },
});
