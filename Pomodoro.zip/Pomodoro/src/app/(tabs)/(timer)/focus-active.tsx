import React, { useEffect } from 'react';
import { View, Text, StyleSheet, SafeAreaView } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useTimer } from '@hooks/useTimer';
import { useTimerStore } from '@store/timerStore';
import { TimerDisplay } from '@components/timer/TimerDisplay';
import { SessionControls } from '@components/timer/SessionControls';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

export default function FocusActiveScreen() {
  const router = useRouter();
  const { sessionId } = useLocalSearchParams<{ sessionId?: string }>();
  const { displayTime, timer, isActive, isPaused, actions } = useTimer();
  const currentSession = useTimerStore((s) => s.currentSession);

  // Auto-navigate to complete when focus session is done
  useEffect(() => {
    if (timer.status === 'completed' && timer.sessionType === 'focus') {
      router.push('/(tabs)/(timer)/focus-complete');
    }
  }, [timer.status, timer.sessionType, router]);

  const handlePauseToggle = async () => {
    if (isPaused) {
      await actions.resume();
    } else {
      await actions.pause();
    }
  };

  const handleStop = async () => {
    await actions.skip();
    router.replace('/(tabs)/(timer)');
  };

  const handleSkip = async () => {
    await actions.skip();
    router.push('/(tabs)/(timer)/focus-complete');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Focus Session</Text>
        {currentSession?.label && (
          <Text style={styles.label}>{currentSession.label}</Text>
        )}
      </View>

      <View style={styles.content}>
        <View style={styles.timerContainer}>
          <Text style={styles.timerText}>{displayTime}</Text>
        </View>

        <View style={styles.progressContainer}>
          <View
            style={[
              styles.progressBar,
              { width: `${(1 - timer.remainingMs / (timer.plannedMinutes * 60 * 1000)) * 100}%` },
            ]}
          />
        </View>
      </View>

      <SessionControls
        onPause={handlePauseToggle}
        onStop={handleStop}
        onSkip={handleSkip}
        isPaused={isPaused}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    padding: spacing[4],
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.gray200,
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.textPrimary,
  },
  label: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginTop: spacing[1],
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing[4],
  },
  timerContainer: {
    alignItems: 'center',
    marginBottom: spacing[8],
  },
  timerText: {
    fontSize: 80,
    fontWeight: '300' as const,
    color: colors.primary,
  },
  progressContainer: {
    width: '100%',
    height: 8,
    backgroundColor: colors.gray200,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: colors.primary,
  },
});
