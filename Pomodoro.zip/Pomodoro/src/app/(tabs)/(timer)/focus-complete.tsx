import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TextInput } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { BreakStartCTA } from '@components/timer/BreakStartCTA';
import { Chip } from '@components/common/Chip';
import { Button } from '@components/common/Button';
import { Card } from '@components/common/Card';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

const PRESET_LABELS = ['UPSC', 'JEE', 'NEET', 'Work', 'Coding'];

export default function FocusCompleteScreen() {
  const router = useRouter();
  const { sessionId } = useLocalSearchParams<{ sessionId: string }>();
  const [selectedLabel, setSelectedLabel] = useState<string | null>(null);
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customLabel, setCustomLabel] = useState('');

  const handleStartBreak = () => {
    console.log('Starting break with label:', selectedLabel || customLabel);
    router.push('/(tabs)/(timer)/break-active');
  };

  const handleAddCustomLabel = () => {
    if (customLabel.trim()) {
      setSelectedLabel(customLabel);
      setShowCustomInput(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Great job! 🎉</Text>
        <Text style={styles.subtitle}>Select what you focused on</Text>

        <Card style={styles.card}>
          <View style={styles.labelsContainer}>
            {PRESET_LABELS.map((label) => (
              <Chip
                key={label}
                label={label}
                selected={selectedLabel === label}
                onPress={() => {
                  setSelectedLabel(label);
                  setShowCustomInput(false);
                }}
              />
            ))}
          </View>
        </Card>

        {!showCustomInput ? (
          <Button
            label="Add Custom Label"
            onPress={() => setShowCustomInput(true)}
            variant="tertiary"
            size="md"
            style={styles.customButton}
          />
        ) : (
          <Card style={styles.customInputCard}>
            <TextInput
              style={styles.input}
              placeholder="Enter custom label"
              value={customLabel}
              onChangeText={setCustomLabel}
            />
            <Button
              label="Add"
              onPress={handleAddCustomLabel}
              variant="primary"
              size="md"
            />
          </Card>
        )}

        <View style={styles.spacer} />

        <BreakStartCTA onStartBreak={handleStartBreak} />

        <Button
          label="Back to Home"
          onPress={() => router.replace('/(tabs)/(timer)')}
          variant="tertiary"
          size="md"
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    padding: spacing[4],
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.textPrimary,
    marginBottom: spacing[2],
    textAlign: 'center',
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    marginBottom: spacing[4],
    textAlign: 'center',
  },
  card: {
    marginBottom: spacing[4],
  },
  labelsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  customButton: {
    marginBottom: spacing[4],
  },
  customInputCard: {
    marginBottom: spacing[4],
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: spacing[2],
    marginBottom: spacing[2],
    backgroundColor: colors.gray50,
  },
  spacer: {
    flex: 1,
  },
});
