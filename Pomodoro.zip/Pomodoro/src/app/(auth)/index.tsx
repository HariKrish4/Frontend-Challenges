import React from 'react';
import { View, Text, StyleSheet, ScrollView, SafeAreaView } from 'react-native';
import { Button } from '@components/common/Button';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

export default function AuthScreen() {
  const handleMagicLink = () => {
    // Placeholder
    console.log('Send magic link');
  };

  const handleOTP = () => {
    // Placeholder
    console.log('Send OTP');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Pomodoro</Text>
        <Text style={styles.subtitle}>Focus. Achieve. Repeat.</Text>

        <View style={styles.spacer} />

        <Button
          label="Continue with Email"
          onPress={handleMagicLink}
          variant="primary"
          size="lg"
          style={styles.button}
        />

        <Button
          label="Continue with Phone"
          onPress={handleOTP}
          variant="secondary"
          size="lg"
          style={styles.button}
        />

        <Text style={styles.disclaimer}>
          We'll send you a secure link or code to sign in.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    padding: spacing[4],
    justifyContent: 'center',
  },
  title: {
    fontSize: typography.fontSize['4xl'],
    fontWeight: '700' as const,
    color: colors.primary,
    textAlign: 'center',
    marginBottom: spacing[2],
  },
  subtitle: {
    fontSize: typography.fontSize.lg,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing[8],
  },
  spacer: {
    height: spacing[6],
  },
  button: {
    marginBottom: spacing[3],
  },
  disclaimer: {
    fontSize: typography.fontSize.sm,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: spacing[6],
  },
});
