import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatCard } from '@components/stats/StatCard';
import { StreakCard } from '@components/stats/StreakCard';
import { WeeklyHistogram } from '@components/stats/WeeklyHistogram';
import { TopLabelsBar } from '@components/stats/TopLabelsBar';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

export default function StatsScreen() {
  // Placeholder data
  const stats = {
    pomodorosToday: 3,
    totalFocusMinutes: 75,
    currentStreak: 5,
    longestStreak: 12,
    weeklyData: [2, 3, 2, 4, 3, 5, 2],
    topLabels: [
      { label: 'Coding', count: 15 },
      { label: 'Work', count: 12 },
      { label: 'UPSC', count: 8 },
    ],
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Statistics</Text>
        </View>

        <View style={styles.statsRow}>
          <StatCard
            label="Today"
            value={stats.pomodorosToday}
            subtitle="Pomodoros"
          />
          <StatCard
            label="Total"
            value={`${stats.totalFocusMinutes}m`}
            subtitle="Focus Time"
          />
        </View>

        <StreakCard
          streak={stats.currentStreak}
          longestStreak={stats.longestStreak}
        />

        <WeeklyHistogram data={stats.weeklyData} />

        <TopLabelsBar labels={stats.topLabels} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    paddingBottom: spacing[4],
  },
  header: {
    padding: spacing[4],
    paddingTop: spacing[6],
    alignItems: 'center',
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700' as const,
    color: colors.textPrimary,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: spacing[2],
  },
});
