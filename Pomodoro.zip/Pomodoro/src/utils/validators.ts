/**
 * Validate email format
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate phone number (Indian format)
 */
export const isValidPhone = (phone: string): boolean => {
  const phoneRegex = /^(\+91|91)?[6-9]\d{9}$/;
  return phoneRegex.test(phone.replace(/\s|-/g, ''));
};

/**
 * Validate OTP (6 digits)
 */
export const isValidOTP = (otp: string): boolean => {
  return /^\d{6}$/.test(otp);
};

/**
 * Validate custom label (3-50 chars, alphanumeric + spaces)
 */
export const isValidLabel = (label: string): boolean => {
  const trimmed = label.trim();
  return trimmed.length >= 3 && trimmed.length <= 50 && /^[a-zA-Z0-9\s\u0900-\u097F\u0B80-\u0BFF]+$/.test(trimmed);
};

/**
 * Sanitize custom label
 */
export const sanitizeLabel = (label: string): string => {
  return label.trim().slice(0, 50);
};
