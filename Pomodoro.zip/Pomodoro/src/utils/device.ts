import AsyncStorage from '@react-native-async-storage/async-storage';

const DEVICE_ID_KEY = 'pomodoro_device_id';

/**
 * Get or generate a unique device ID
 */
export const getOrGenerateDeviceId = async (): Promise<string> => {
  try {
    const existing = await AsyncStorage.getItem(DEVICE_ID_KEY);
    if (existing) return existing;

    const newId = UUID.v4();
    await AsyncStorage.setItem(DEVICE_ID_KEY, newId);
    return newId;
  } catch (error) {
    console.warn('Failed to get device ID:', error);
    // Fallback to a random ID
    return `fallback_${Math.random().toString(36).substr(2, 9)}`;
  }
};

/**
 * Clear device ID (for testing)
 */
export const clearDeviceId = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(DEVICE_ID_KEY);
  } catch (error) {
    console.warn('Failed to clear device ID:', error);
  }
};
