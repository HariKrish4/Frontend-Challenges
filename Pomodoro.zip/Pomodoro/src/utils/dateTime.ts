import { useMemo } from 'react';

// IST timezone format
export const IST_TIMEZONE = 'Asia/Kolkata';

/**
 * Format a date to IST string (HH:MM)
 */
export const formatTimeIST = (date: Date): string => {
  return date.toLocaleTimeString('en-IN', {
    timeZone: IST_TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
};

/**
 * Format a date to IST string (YYYY-MM-DD HH:MM:SS)
 */
export const formatDateTimeIST = (date: Date): string => {
  const istDate = new Date(date.toLocaleString('en-US', { timeZone: IST_TIMEZONE }));
  return istDate.toISOString().slice(0, 19);
};

/**
 * Get current IST date as string (YYYY-MM-DD)
 */
export const getTodayIST = (): string => {
  const today = new Date();
  const istDate = new Date(today.toLocaleString('en-US', { timeZone: IST_TIMEZONE }));
  return istDate.toISOString().split('T')[0];
};

/**
 * Format MM:SS from total seconds
 */
export const formatMMSS = (totalSeconds: number): string => {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

/**
 * Format duration in minutes
 */
export const formatDuration = (minutes: number): string => {
  return `${minutes}m`;
};

/**
 * Get relative time (e.g., "2 hours ago")
 */
export const getRelativeTime = (date: string | Date): string => {
  const now = new Date();
  const then = typeof date === 'string' ? new Date(date) : date;
  const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
};

/**
 * Parse ISO datetime string to Date
 */
export const parseISO = (isoString: string): Date => {
  return new Date(isoString);
};

/**
 * Check if two dates are the same day (IST)
 */
export const isSameDay = (date1: Date, date2: Date): boolean => {
  const d1 = date1.toLocaleString('en-US', { timeZone: IST_TIMEZONE }).split(',')[0];
  const d2 = date2.toLocaleString('en-US', { timeZone: IST_TIMEZONE }).split(',')[0];
  return d1 === d2;
};

/**
 * Get start and end of day (IST)
 */
export const getDayRange = (date: Date): { start: Date; end: Date } => {
  const istDate = new Date(date.toLocaleString('en-US', { timeZone: IST_TIMEZONE }));
  const start = new Date(istDate);
  start.setHours(0, 0, 0, 0);

  const end = new Date(istDate);
  end.setHours(23, 59, 59, 999);

  return { start, end };
};

/**
 * Get week range (Monday to Sunday, IST)
 */
export const getWeekRange = (date: Date): { start: Date; end: Date } => {
  const d = new Date(date.toLocaleString('en-US', { timeZone: IST_TIMEZONE }));
  const dayOfWeek = d.getDay();
  const start = new Date(d);
  start.setDate(d.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  end.setHours(23, 59, 59, 999);

  return { start, end };
};

/**
 * Format MM:SS from total milliseconds (for timer display)
 * Rounds up seconds to avoid showing 0:00 too early
 */
export const formatMStoMMSS = (totalMs: number): string => {
  const totalSeconds = Math.ceil(totalMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

/**
 * Calculate elapsed time in milliseconds
 * @param startedAtMs - Timestamp in ms when session started
 * @param pausedTimeMs - Cumulative pause duration in ms
 * @param nowMs - Current timestamp in ms (defaults to Date.now())
 */
export const getElapsedMs = (
  startedAtMs: number,
  pausedTimeMs: number = 0,
  nowMs: number = Date.now()
): number => {
  return nowMs - startedAtMs - pausedTimeMs;
};

/**
 * Calculate remaining time in milliseconds
 * @param plannedMs - Total planned session duration in ms
 * @param elapsedMs - Elapsed time in ms
 */
export const calculateRemainingMs = (plannedMs: number, elapsedMs: number): number => {
  return Math.max(0, plannedMs - elapsedMs);
};

/**
 * Check if session is complete (remaining <= 0)
 */
export const isSessionComplete = (remainingMs: number): boolean => {
  return remainingMs <= 0;
};
