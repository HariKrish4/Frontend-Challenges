// Pomodoro durations (in minutes)
export const FOCUS_DURATION = 25;
export const BREAK_DURATION = 5;

// Durations in milliseconds
export const FOCUS_DURATION_MS = FOCUS_DURATION * 60 * 1000;
export const BREAK_DURATION_MS = BREAK_DURATION * 60 * 1000;

// Session statuses
export const SESSION_STATUS = {
  IDLE: 'idle',
  ACTIVE: 'active',
  PAUSED: 'paused',
  COMPLETED: 'completed',
} as const;

// Session types
export const SESSION_TYPE = {
  FOCUS: 'focus',
  BREAK: 'break',
} as const;

// Exam presets (localized separately via i18n)
export const EXAM_PRESETS = ['upsc', 'jee', 'neet', 'work', 'coding'];

// Default language
export const DEFAULT_LANGUAGE = 'en';

// Supported languages
export const SUPPORTED_LANGUAGES = ['en', 'hi', 'ta'] as const;

// Time format
export const TIME_FORMAT_24H = 'HH:mm';
export const DATE_FORMAT = 'YYYY-MM-DD';

// Notification delays
export const NOTIFICATION_CHECK_INTERVAL = 1000; // 1 second
export const NOTIFICATION_EARLY_WARN = 2000; // 2 seconds before end

// Sync retry settings
export const SYNC_RETRY_DELAY = 5000; // 5 seconds
export const SYNC_MAX_RETRIES = 5;

// UI constants
export const BUTTON_HEIGHT = 48;
export const SMALL_BUTTON_HEIGHT = 40;
export const CARD_BORDER_RADIUS = 12;
export const MODAL_BORDER_RADIUS = 20;
