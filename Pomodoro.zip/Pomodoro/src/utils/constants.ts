// Pomodoro durations (in minutes)
export const FOCUS_DURATION = 25;
export const BREAK_DURATION = 5;

// Durations in milliseconds
export const FOCUS_DURATION_MS = FOCUS_DURATION * 60 * 1000;
export const BREAK_DURATION_MS = BREAK_DURATION * 60 * 1000;

// Timer update frequency
export const TIMER_UPDATE_INTERVAL_MS = 1000; // 1 second (UI updates)
export const TIMER_TICK_INTERVAL_MS = 100; // 100ms for calculation precision

// Session statuses
export const SESSION_STATUS = {
  IDLE: 'idle',
  ACTIVE: 'active',
  PAUSED: 'paused',
  COMPLETED: 'completed',
} as const;

// Session types
export const SESSION_TYPE = {
  FOCUS: 'focus',
  BREAK: 'break',
} as const;

// Exam presets (localized separately via i18n)
export const EXAM_PRESETS = ['upsc', 'jee', 'neet', 'work', 'coding'];

// Default language
export const DEFAULT_LANGUAGE = 'en';

// Supported languages
export const SUPPORTED_LANGUAGES = ['en', 'hi', 'ta'] as const;

// Time format
export const TIME_FORMAT_24H = 'HH:mm';
export const DATE_FORMAT = 'YYYY-MM-DD';

// Notification delays
export const NOTIFICATION_CHECK_INTERVAL = 1000; // 1 second
export const NOTIFICATION_EARLY_WARN = 2000; // 2 seconds before end

// Sync retry settings
export const SYNC_RETRY_DELAY = 5000; // 5 seconds
export const SYNC_MAX_RETRIES = 5;
export const SYNC_TIMEOUT_MS = 10000; // 10 seconds to sync before timing out

// Persistence & Storage Keys
export const PERSISTENCE_KEYS = {
  SESSION_STATE: 'pomodoro_timer_state',
  DEVICE_ID: 'pomodoro_device_id',
  CURRENT_USER: 'pomodoro_current_user',
  SYNC_QUEUE: 'pomodoro_sync_queue',
  NOTIFICATION_STATE: 'pomodoro_notification_state',
  LAST_SYNC_AT: 'pomodoro_last_sync_at',
} as const;

// UI constants
export const BUTTON_HEIGHT = 48;
export const SMALL_BUTTON_HEIGHT = 40;
export const CARD_BORDER_RADIUS = 12;
export const MODAL_BORDER_RADIUS = 20;
