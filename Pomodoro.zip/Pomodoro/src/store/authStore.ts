import { create } from 'zustand';

interface AuthState {
  isAuthenticated: boolean;
  user: { id: string; email: string } | null;
  isLoading: boolean;
  error: string | null;
  checkSession: () => Promise<void>;
  setAuthenticated: (authenticated: boolean, user?: { id: string; email: string } | null) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  isLoading: false,
  error: null,

  checkSession: async () => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Wire Supabase.auth.getSession() here
      // For now, default to false (user not authenticated)
      set({ isAuthenticated: false, user: null });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to check session';
      set({ error: message, isAuthenticated: false });
    } finally {
      set({ isLoading: false });
    }
  },

  setAuthenticated: (authenticated, user = null) => {
    set({
      isAuthenticated: authenticated,
      user: authenticated ? user : null,
      error: null,
    });
  },

  logout: () => {
    set({
      isAuthenticated: false,
      user: null,
      error: null,
    });
  },
}));
