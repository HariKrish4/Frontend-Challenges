import { create } from 'zustand';
import { AuthStoreState } from '@appTypes/store';
import { AuthUser } from '@appTypes/domain';
import { useTimerStore } from './timerStore';
import { useSyncStore } from './syncStore';
import { useProfileStore } from './profileStore';

/**
 * Create auth store
 */
export const useAuthStore = create<AuthStoreState>((set, get) => ({
  user: null,
  profile: null,
  isLoading: false,
  error: null,

  /**
   * Send magic link to email
   */
  sendMagicLink: async (email: string) => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase auth.signInWithOtp() in Stage 3
      console.log('Magic link sent to:', email);
      set({ isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to send magic link';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Verify magic link token
   */
  verifyMagicLink: async (email: string, token: string) => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase auth.verifyOtp() in Stage 3
      // For now, simulate successful auth
      const user: AuthUser = {
        id: 'test-user-id',
        email,
        created_at: new Date().toISOString(),
      };
      set({ user, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Verification failed';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Send OTP to phone number
   */
  sendOTP: async (phone: string) => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase auth OTP for phone in Stage 3
      console.log('OTP sent to:', phone);
      set({ isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to send OTP';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Verify OTP
   */
  verifyOTP: async (phone: string, otp: string) => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase auth OTP verification in Stage 3
      const user: AuthUser = {
        id: 'test-user-id',
        phone,
        created_at: new Date().toISOString(),
      };
      set({ user, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'OTP verification failed';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Check if user has an active session (on app startup)
   */
  checkSession: async () => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase.auth.getSession() in Stage 3
      // For now, default to unauthenticated
      set({ user: null, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to check session';
      set({ error: message, user: null, isLoading: false });
    }
  },

  /**
   * Log out current user
   */
  logout: async () => {
    try {
      set({ isLoading: true, error: null });
      // TODO: Implement Supabase.auth.signOut() in Stage 3

      // Reset all stores on logout
      useTimerStore.getState().resetTimer();
      useSyncStore.getState().resetSync();
      useProfileStore.getState().resetProfile();

      set({
        user: null,
        profile: null,
        isLoading: false,
        error: null,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Logout failed';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  // ============================================================================
  // INTERNAL SETTERS
  // ============================================================================

  setUser: (user) => {
    set({ user });
  },

  setProfile: (profile) => {
    set({ profile });
  },

  setLoading: (loading) => {
    set({ isLoading: loading });
  },

  setError: (error) => {
    set({ error });
  },

  clearError: () => {
    set({ error: null });
  },
}));
