/**
 * Notification Store (Zustand)
 * Manages notification permissions and scheduled notifications
 */

import { create } from 'zustand';
import { NotificationStoreState } from '@appTypes/store';
import { NotificationPermissionState, ScheduledNotification } from '@appTypes/domain';

/**
 * Default permission state
 */
const defaultPermissionState: NotificationPermissionState = {
  isDenied: false,
};

/**
 * Create notification store
 */
export const useNotificationStore = create<NotificationStoreState>((set: any, get: any) => ({
  permissions: defaultPermissionState,
  scheduledNotifications: [],

  /**
   * Request notification permissions
   * Returns 'granted' if successful, 'denied' if user rejects
   */
  requestPermissions: async () => {
    try {
      // TODO: Implement expo-notifications permission request in Stage 4
      // For now, assume granted
      set({
        permissions: {
          isDenied: false,
          iosGranted: true,
          androidGranted: true,
        },
      });
      return 'granted';
    } catch (err) {
      console.error('Failed to request notification permissions:', err);
      set({
        permissions: {
          isDenied: true,
        },
      });
      return 'denied';
    }
  },

  scheduleEndOfFocus: async (sessionId: number, delayMs: number) => {
    try {
      // TODO: Implement expo-notifications scheduling in Stage 4
      // For now, generate a fake ID
      const notifId = `focus_notif_${sessionId}_${Date.now()}`;

      const scheduled: ScheduledNotification = {
        sessionId,
        notifId,
        sessionType: 'focus',
        scheduledAt: Date.now(),
      };

      set((state: any) => ({
        scheduledNotifications: [...state.scheduledNotifications, scheduled],
      }));

      return notifId;
    } catch (err) {
      console.error('Failed to schedule focus notification:', err);
      throw err;
    }
  },

  /**
   * Schedule a notification for end of break session
   * @returns notification ID for later cancellation
   */
  scheduleEndOfBreak: async (sessionId: number, delayMs: number) => {
    try {
      // TODO: Implement expo-notifications scheduling in Stage 4
      const notifId = `break_notif_${sessionId}_${Date.now()}`;

      const scheduled: ScheduledNotification = {
        sessionId,
        notifId,
        sessionType: 'break',
        scheduledAt: Date.now(),
      };

      set((state: any) => ({
        scheduledNotifications: [...state.scheduledNotifications, scheduled],
      }));

      return notifId;
    } catch (err) {
      console.error('Failed to schedule break notification:', err);
      throw err;
    }
  },

  /**
   * Cancel a scheduled notification
   */
  cancelNotification: async (notifId: string) => {
    try {
      // TODO: Implement expo-notifications cancellation in Stage 4
      set((state: any) => ({
        scheduledNotifications: state.scheduledNotifications.filter(
          (n: any) => n.notifId !== notifId
        ),
      }));
    } catch (err) {
      console.error('Failed to cancel notification:', err);
      throw err;
    }
  },

  // ============================================================================
  // INTERNAL SETTERS
  // ============================================================================

  setPermissions: (permissions: Partial<NotificationPermissionState>) => {
    set((state: any) => ({
      permissions: { ...state.permissions, ...permissions },
    }));
  },

  addScheduledNotification: (notif: ScheduledNotification) => {
    set((state: any) => ({
      scheduledNotifications: [...state.scheduledNotifications, notif],
    }));
  },

  removeScheduledNotification: (notifId: string) => {
    set((state: any) => ({
      scheduledNotifications: state.scheduledNotifications.filter(
        (n: any) => n.notifId !== notifId
      ),
    }));
  },

  resetNotifications: () => {
    set({
      permissions: defaultPermissionState,
      scheduledNotifications: [],
    });
  },
}));
