/**
 * Sync Store (Zustand)
 * Manages offline queue and sync operations
 */

import { create } from 'zustand';
import { SyncStoreState } from '@appTypes/store';
import { SyncStatus, Session } from '@appTypes/domain';

/**
 * Default sync status
 */
const defaultSyncStatus: SyncStatus = {
  online: false,
  syncing: false,
  queueLength: 0,
  lastSyncAt: undefined,
};

/**
 * Create sync store
 */
export const useSyncStore = create<SyncStoreState>((set: any, get: any) => ({
  syncStatus: defaultSyncStatus,
  isLoading: false,
  error: null,

  queueSession: async (session: Session) => {
    try {
      // TODO: Implement SQLite persistence in Stage 3
      set((state: any) => ({
        syncStatus: {
          ...state.syncStatus,
          queueLength: (state.syncStatus.queueLength || 0) + 1,
        },
      }));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to queue session';
      set({ error: message });
    }
  },

  syncPending: async () => {
    try {
      set({ isLoading: true, error: null });

      // TODO: Implement Supabase sync in Stage 3
      // For now, just clear the queue
      const queueLength = get().syncStatus.queueLength || 0;

      set((state: any) => ({
        syncStatus: {
          ...state.syncStatus,
          queueLength: 0,
          lastSyncAt: new Date().toISOString(),
          syncing: false,
        },
        isLoading: false,
      }));

      return { uploaded: queueLength, failed: 0 };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sync failed';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  setOnline: async (isOnline: boolean) => {
    set((state: any) => ({
      syncStatus: {
        ...state.syncStatus,
        online: isOnline,
      },
    }));

    if (isOnline && (get().syncStatus.queueLength || 0) > 0) {
      // Attempt to sync when coming online
      try {
        await get().syncPending();
      } catch (err) {
        console.error('Auto-sync on reconnect failed:', err);
      }
    }
  },

  // ============================================================================
  // INTERNAL SETTERS
  // ============================================================================

  setSyncStatus: (status: Partial<SyncStatus>) => {
    set((state: any) => ({
      syncStatus: { ...state.syncStatus, ...status },
    }));
  },

  setLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  setError: (error: string | null) => {
    set({ error });
  },

  resetSync: () => {
    set({
      syncStatus: defaultSyncStatus,
      isLoading: false,
      error: null,
    });
  },
}));
