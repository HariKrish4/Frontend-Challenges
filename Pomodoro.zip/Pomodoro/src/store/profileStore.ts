/**
 * Profile Store (Zustand)
 * Manages user profile and preferences
 */

import { create } from 'zustand';
import { ProfileStoreState } from '@appTypes/store';
import { Profile } from '@appTypes/domain';

/**
 * Create profile store
 */
export const useProfileStore = create<ProfileStoreState>((set: any, get: any) => ({
  profile: null,
  isLoading: false,
  error: null,

  /**
   * Load user profile from backend
   */
  loadProfile: async (userId: string) => {
    try {
      set({ isLoading: true, error: null });

      // TODO: Implement Supabase profile fetch in Stage 3
      // For now, create a default profile
      const profile: Profile = {
        id: userId,
        language: 'en',
        timezone: 'Asia/Kolkata',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      set({ profile, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load profile';
      set({ error: message, isLoading: false });
    }
  },

  /**
   * Set user language preference
   */
  setLanguage: async (lang: 'en' | 'hi' | 'ta') => {
    try {
      set({ isLoading: true, error: null });

      const profile = get().profile;
      if (!profile) {
        throw new Error('No profile loaded');
      }

      const updated: Profile = {
        ...profile,
        language: lang,
        updated_at: new Date().toISOString(),
      };

      // TODO: Persist to Supabase in Stage 3

      set({ profile: updated, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to set language';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Set notifications enabled/disabled
   */
  setNotificationsEnabled: async (enabled: boolean) => {
    try {
      set({ isLoading: true, error: null });

      // TODO: Persist to Supabase in Stage 3

      set({ isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update notification setting';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  // ============================================================================
  // INTERNAL SETTERS
  // ============================================================================

  setProfile: (profile: Profile | null) => {
    set({ profile });
  },

  setLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  setError: (error: string | null) => {
    set({ error });
  },

  resetProfile: () => {
    set({
      profile: null,
      isLoading: false,
      error: null,
    });
  },
}));
