/**
 * Timer Store (Zustand)
 * Manages timer state machine, session management, and notifications
 */

import { create } from 'zustand';
import { TimerStoreState } from '@appTypes/store';
import { TimerState, Session, SessionCreatePayload } from '@appTypes/domain';
import { SESSION_STATUS, SESSION_TYPE, FOCUS_DURATION_MS, BREAK_DURATION_MS, TIMER_UPDATE_INTERVAL_MS } from '@utils/constants';
import { getOrGenerateDeviceId } from '@utils/device';
import { calculateElapsed, calculateRemaining, formatMStoMMSS, isSessionComplete, getActualTime } from '@services/timer/TimerEngine';
import { saveSessionState, loadSessionState, clearSessionState } from '@services/persistence/SessionPersistence';

/**
 * Default init state for timer
 */
const defaultTimerState: TimerState = {
  status: SESSION_STATUS.IDLE,
  sessionType: null,
  plannedMinutes: 25,
  actualMinutes: 0,
  actualSeconds: 0,
  remainingMs: FOCUS_DURATION_MS,
  elapsedMs: 0,
  label: undefined,
  startedAtMs: undefined,
  pausedAtMs: undefined,
  totalPausedMs: 0,
};

/**
 * Create timer store
 */
export const useTimerStore = create<TimerStoreState>((set: any, get: any) => ({
  timer: defaultTimerState,
  currentSession: null,
  isLoading: false,
  error: null,

  // ============================================================================
  // PUBLIC ACTIONS
  // ============================================================================

  /**
   * Start a focus session
   */
  startFocus: async (label?: string) => {
    try {
      set({ isLoading: true, error: null });
      const deviceId = await getOrGenerateDeviceId();
      const now = Date.now();

      // Create session record
      const session: Session = {
        id: 0, // Will be assigned by DB
        user_id: '', // Will be filled by sync layer
        type: SESSION_TYPE.FOCUS,
        planned_minutes: 25,
        actual_minutes: 0,
        label,
        started_at: new Date(now).toISOString(),
        ended_at: undefined,
        device_id: deviceId,
        created_at: new Date(now).toISOString(),
      };

      // Update timer state
      const newTimer: TimerState = {
        status: SESSION_STATUS.ACTIVE,
        sessionType: SESSION_TYPE.FOCUS,
        plannedMinutes: 25,
        actualMinutes: 0,
        actualSeconds: 0,
        remainingMs: FOCUS_DURATION_MS,
        elapsedMs: 0,
        label,
        startedAtMs: now,
        totalPausedMs: 0,
      };

      set({
        timer: newTimer,
        currentSession: session,
        isLoading: false,
      });

      // Persist state
      await saveSessionState({
        status: newTimer.status,
        sessionType: newTimer.sessionType,
        plannedMinutes: newTimer.plannedMinutes,
        label: newTimer.label,
        startedAtMs: newTimer.startedAtMs,
        totalPausedMs: newTimer.totalPausedMs,
        completedAtMs: undefined,
        pausedAtMs: undefined,
        resumedAtMs: undefined,
        savedAt: now,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to start focus session';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Start a break session
   */
  startBreak: async (focusSessionId?: number) => {
    try {
      set({ isLoading: true, error: null });
      const deviceId = await getOrGenerateDeviceId();
      const now = Date.now();

      const session: Session = {
        id: 0,
        user_id: '',
        type: SESSION_TYPE.BREAK,
        planned_minutes: 5,
        actual_minutes: 0,
        label: `Break after session`,
        started_at: new Date(now).toISOString(),
        ended_at: undefined,
        device_id: deviceId,
        created_at: new Date(now).toISOString(),
      };

      const newTimer: TimerState = {
        status: SESSION_STATUS.ACTIVE,
        sessionType: SESSION_TYPE.BREAK,
        plannedMinutes: 5,
        actualMinutes: 0,
        actualSeconds: 0,
        remainingMs: BREAK_DURATION_MS,
        elapsedMs: 0,
        label: undefined,
        startedAtMs: now,
        totalPausedMs: 0,
      };

      set({
        timer: newTimer,
        currentSession: session,
        isLoading: false,
      });

      await saveSessionState({
        status: newTimer.status,
        sessionType: newTimer.sessionType,
        plannedMinutes: newTimer.plannedMinutes,
        startedAtMs: newTimer.startedAtMs,
        totalPausedMs: newTimer.totalPausedMs,
        completedAtMs: undefined,
        pausedAtMs: undefined,
        resumedAtMs: undefined,
        savedAt: now,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to start break session';
      set({ error: message, isLoading: false });
      throw err;
    }
  },

  /**
   * Pause current session
   */
  pauseSession: async () => {
    try {
      const { timer } = get();
      if (timer.status !== SESSION_STATUS.ACTIVE) return;

      const now = Date.now();
      const updated = {
        ...timer,
        status: SESSION_STATUS.PAUSED,
        pausedAtMs: now,
      };

      set({ timer: updated });

      await saveSessionState({
        status: updated.status,
        sessionType: updated.sessionType,
        plannedMinutes: updated.plannedMinutes,
        label: updated.label,
        startedAtMs: updated.startedAtMs,
        pausedAtMs: updated.pausedAtMs,
        resumedAtMs: updated.resumedAtMs,
        totalPausedMs: updated.totalPausedMs,
        completedAtMs: updated.completedAtMs,
        savedAt: now,
      });
    } catch (err) {
      console.error('Failed to pause session:', err);
    }
  },

  /**
   * Resume paused session
   */
  resumeSession: async () => {
    try {
      const { timer } = get();
      if (timer.status !== SESSION_STATUS.PAUSED || !timer.pausedAtMs || !timer.startedAtMs) return;

      const now = Date.now();
      const pausedDuration = now - timer.pausedAtMs;
      const updated = {
        ...timer,
        status: SESSION_STATUS.ACTIVE,
        totalPausedMs: timer.totalPausedMs + pausedDuration,
        pausedAtMs: undefined,
        resumedAtMs: now,
      };

      set({ timer: updated });

      await saveSessionState({
        status: updated.status,
        sessionType: updated.sessionType,
        plannedMinutes: updated.plannedMinutes,
        label: updated.label,
        startedAtMs: updated.startedAtMs,
        resumedAtMs: updated.resumedAtMs,
        totalPausedMs: updated.totalPausedMs,
        completedAtMs: updated.completedAtMs,
        savedAt: now,
      });
    } catch (err) {
      console.error('Failed to resume session:', err);
    }
  },

  /**
   * Skip current session
   */
  skipSession: async () => {
    try {
      const { timer, currentSession } = get();
      const now = Date.now();

      if (!currentSession) {
        console.warn('No active session to skip');
        return;
      }

      // Mark as complete
      set({
        timer: {
          ...timer,
          status: SESSION_STATUS.COMPLETED,
          completedAtMs: now,
        },
      });

      await clearSessionState();
    } catch (err) {
      console.error('Failed to skip session:', err);
    }
  },

  /**
   * Complete current session
   * @param actualMinutes - Override for actual duration (optional)
   */
  completeSession: async (actualMinutes?: number) => {
    try {
      const { timer, currentSession } = get();
      if (!currentSession) {
        console.warn('No active session to complete');
        return;
      }

      const now = Date.now();
      const elapsedMs = calculateElapsed(
        timer.startedAtMs || now,
        timer.totalPausedMs,
        now
      );
      const { minutes, seconds } = getActualTime(elapsedMs);

      // Update session with actual time
      const completedSession: Session = {
        ...currentSession,
        actual_minutes: actualMinutes ?? minutes,
        ended_at: new Date(now).toISOString(),
      };

      set({
        timer: {
          ...timer,
          status: SESSION_STATUS.COMPLETED,
          completedAtMs: now,
          actualMinutes: actualMinutes ?? minutes,
          actualSeconds: seconds,
          remainingMs: 0,
        },
        currentSession: completedSession,
      });

      await clearSessionState();
    } catch (err) {
      console.error('Failed to complete session:', err);
    }
  },

  /**
   * Recover session from storage (on app resume/restart)
   */
  recoverFromStorage: async () => {
    try {
      const saved = await loadSessionState();
      if (!saved) {
        set({ timer: defaultTimerState, currentSession: null });
        return;
      }

      const plannedMs =
        saved.sessionType === SESSION_TYPE.FOCUS ? FOCUS_DURATION_MS : BREAK_DURATION_MS;

      // Check if session is stale
      if (
        saved.status === SESSION_STATUS.ACTIVE &&
        saved.startedAtMs &&
        calculateElapsed(saved.startedAtMs, saved.totalPausedMs) > plannedMs
      ) {
        // Session has completed
        const elapsedMs = calculateElapsed(saved.startedAtMs, saved.totalPausedMs);
        const { minutes, seconds } = getActualTime(elapsedMs);

        set({
          timer: {
            status: SESSION_STATUS.COMPLETED,
            sessionType: saved.sessionType,
            plannedMinutes: saved.plannedMinutes,
            actualMinutes: minutes,
            actualSeconds: seconds,
            remainingMs: 0,
            elapsedMs,
            label: saved.label,
            startedAtMs: saved.startedAtMs,
            totalPausedMs: saved.totalPausedMs,
            completedAtMs: Date.now(),
          },
          currentSession: null,
        });

        await clearSessionState();
        return;
      }

      // Resume session
      const elapsedMs = calculateElapsed(
        saved.startedAtMs || 0,
        saved.totalPausedMs
      );
      const remainingMs = calculateRemaining(plannedMs, elapsedMs);
      const { minutes, seconds } = getActualTime(elapsedMs);

      set({
        timer: {
          status: saved.status,
          sessionType: saved.sessionType,
          plannedMinutes: saved.plannedMinutes,
          actualMinutes: minutes,
          actualSeconds: seconds,
          remainingMs,
          elapsedMs,
          label: saved.label,
          startedAtMs: saved.startedAtMs,
          pausedAtMs: saved.pausedAtMs,
          resumedAtMs: saved.resumedAtMs,
          totalPausedMs: saved.totalPausedMs,
        },
      });
    } catch (err) {
      console.error('Failed to recover session from storage:', err);
      set({ timer: defaultTimerState, currentSession: null, error: 'Recovery failed' });
    }
  },

  /**
   * Format timer display (MM:SS)
   */
  formatDisplayTime: () => {
    const { timer } = get();
    return formatMStoMMSS(timer.remainingMs);
  },

  /**
   * Tick the timer (called every TIMER_UPDATE_INTERVAL_MS)
   * Updates elapsed/remaining times
   */
  _tick: () => {
    const { timer, currentSession } = get();
    if (timer.status !== SESSION_STATUS.ACTIVE || !timer.startedAtMs) return;

    const plannedMs =
      timer.sessionType === SESSION_TYPE.FOCUS
        ? FOCUS_DURATION_MS
        : BREAK_DURATION_MS;

    const elapsedMs = calculateElapsed(timer.startedAtMs, timer.totalPausedMs);
    const remainingMs = calculateRemaining(plannedMs, elapsedMs);
    const { minutes, seconds } = getActualTime(elapsedMs);

    set({
      timer: {
        ...timer,
        elapsedMs,
        remainingMs,
        actualMinutes: minutes,
        actualSeconds: seconds,
      },
    });

    // Auto-complete if timer reached zero
    if (isSessionComplete(remainingMs)) {
      get().completeSession(minutes);
    }
  },

  // ============================================================================
  // INTERNAL SETTERS
  // ============================================================================

  setTimer: (partial: Partial<TimerState>) => {
    set((state: any) => ({
      timer: { ...state.timer, ...partial },
    }));
  },

  setCurrentSession: (session: Session | null) => {
    set({ currentSession: session });
  },

  setLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  setError: (error: string | null) => {
    set({ error });
  },

  resetTimer: () => {
    set({
      timer: defaultTimerState,
      currentSession: null,
      isLoading: false,
      error: null,
    });
  },
}));

/**
 * Setup timer tick interval
 * Call this from a hook or component effect
 */
export const setupTimerTick = () => {
  const interval = setInterval(() => {
    useTimerStore.getState()._tick();
  }, TIMER_UPDATE_INTERVAL_MS);

  return () => clearInterval(interval);
};
