/**
 * useTimer Hook
 * Binds timer store to screen UI
 * Manages tick interval and display formatting
 */

import { useEffect, useRef } from 'react';
import { useTimerStore, setupTimerTick } from '@store/timerStore';
import { TIMER_UPDATE_INTERVAL_MS } from '@utils/constants';
import { TimerState, Session } from '@appTypes/domain';

export interface UseTimerReturn {
  displayTime: string;
  timer: TimerState;
  session: Session | null;
  isActive: boolean;
  isPaused: boolean;
  progress: number; // 0-1
  actions: {
    pause: () => Promise<void>;
    resume: () => Promise<void>;
    skip: () => Promise<void>;
  };
}

/**
 * Hook to manage timer display and interactions
 */
export const useTimer = (): UseTimerReturn => {
  const timer = useTimerStore((s: any) => s.timer);
  const session = useTimerStore((s: any) => s.currentSession);
  const pauseSession = useTimerStore((s: any) => s.pauseSession);
  const resumeSession = useTimerStore((s: any) => s.resumeSession);
  const skipSession = useTimerStore((s: any) => s.skipSession);
  const formatDisplayTime = useTimerStore((s: any) => s.formatDisplayTime);
  const tickRef = useRef<ReturnType<typeof setupTimerTick> | undefined>(undefined);

  // Setup timer tick on mount
  useEffect(() => {
    tickRef.current = setupTimerTick();
    return () => {
      if (tickRef.current) {
        tickRef.current();
      }
    };
  }, []);

  const isActive = timer.status === 'active';
  const isPaused = timer.status === 'paused';

  // Calculate progress (0-1) for visual indicators
  const plannedMs = timer.plannedMinutes * 60 * 1000;
  const progress =
    plannedMs > 0 ? Math.max(0, Math.min(1, timer.elapsedMs / plannedMs)) : 0;

  return {
    displayTime: formatDisplayTime(),
    timer,
    session,
    isActive,
    isPaused,
    progress,
    actions: {
      pause: pauseSession,
      resume: resumeSession,
      skip: skipSession,
    },
  };
};
