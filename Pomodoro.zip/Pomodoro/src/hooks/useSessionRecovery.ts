/**
 * useSessionRecovery Hook
 * Recovers timer state on app startup/resume
 * Used in app root layout
 */

import { useEffect } from 'react';
import { useTimerStore } from '@store/timerStore';

/**
 * Hook to recover session state on app startup
 * Should be called in the app root layout
 */
export const useSessionRecovery = () => {
  const recoverFromStorage = useTimerStore((s) => s.recoverFromStorage);

  useEffect(() => {
    const recover = async () => {
      try {
        await recoverFromStorage();
      } catch (err) {
        console.error('Session recovery failed:', err);
      }
    };

    recover();
  }, [recoverFromStorage]);
};
