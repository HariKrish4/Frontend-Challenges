/**
 * useSync Hook
 * Manages sync queue and online/offline detection
 */

import { useEffect } from 'react';
import { useSyncStore } from '@store/syncStore';

/**
 * Hook to manage sync operations
 */
export const useSync = () => {
  const syncStatus = useSyncStore((s) => s.syncStatus);
  const queueSession = useSyncStore((s) => s.queueSession);
  const syncPending = useSyncStore((s) => s.syncPending);
  const setOnline = useSyncStore((s) => s.setOnline);

  // TODO: Setup connectivity listener (useNetInfo or similar) in Stage 3
  // For now, assume online
  useEffect(() => {
    setOnline(true);
  }, [setOnline]);

  return {
    syncStatus,
    queueSession,
    syncPending,
    setOnline,
    isOnline: syncStatus.online,
    queueLength: syncStatus.queueLength || 0,
    isSyncing: syncStatus.syncing || false,
  };
};
