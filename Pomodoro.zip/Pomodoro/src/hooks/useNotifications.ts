/**
 * useNotifications Hook
 * Manages notification permissions and scheduling
 */

import { useEffect } from 'react';
import { useNotificationStore } from '../store/notificationStore';

/**
 * Hook to manage notifications
 */
export const useNotifications = () => {
  const permissions = useNotificationStore((s) => s.permissions);
  const requestPermissions = useNotificationStore((s) => s.requestPermissions);
  const scheduleEndOfFocus = useNotificationStore((s) => s.scheduleEndOfFocus);
  const scheduleEndOfBreak = useNotificationStore((s) => s.scheduleEndOfBreak);
  const cancelNotification = useNotificationStore((s) => s.cancelNotification);
  const scheduledNotifications = useNotificationStore((s) => s.scheduledNotifications);

  // TODO: Setup notification listeners in Stage 4
  // Listen for notification taps and route accordingly

  return {
    permissions,
    requestPermissions,
    scheduleEndOfFocus,
    scheduleEndOfBreak,
    cancelNotification,
    scheduledNotifications,
    permitted: !permissions.isDenied,
  };
};
