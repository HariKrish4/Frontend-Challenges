// ============================================================================
// DATABASE TYPES (SQLite & Supabase)
// ============================================================================

/**
 * SQLite Sessions Table Schema
 * Mirrors Supabase sessions table locally
 */
export interface SessionsTable {
  id: number;
  user_id: string;
  type: 'focus' | 'break';
  planned_minutes: 25 | 5;
  actual_minutes: number;
  label: string | null;
  started_at: string;  // ISO8601
  ended_at: string | null;  // ISO8601
  device_id: string;
  created_at: string;  // ISO8601
  synced: boolean;  // Local flag: has been uploaded to Supabase?
}

/**
 * SQLite Profiles Table Schema
 * Mirrors Supabase profiles table locally
 */
export interface ProfilesTable {
  id: string;  // UUID
  language: 'en' | 'hi' | 'ta';
  timezone: string;
  notifications_enabled: boolean;
  created_at: string;  // ISO8601
  updated_at: string;  // ISO8601
}

/**
 * SQLite Sync Queue Table
 * Tracks offline operations pending upload
 */
export interface SyncQueueTable {
  id: string;  // UUID
  session_id: number;
  operation: 'insert' | 'update';
  payload: string;  // JSON stringified
  created_at: string;  // ISO8601
  retry_count: number;
  last_retry_at: string | null;  // ISO8601
}

/**
 * SQLite Exam Presets Table
 * Cached from Supabase, read-only
 */
export interface ExamPresetsTable {
  id: number;
  title: string;
  description: string | null;
  locale: 'en' | 'hi' | 'ta';
  is_active: boolean;
  created_at: string;  // ISO8601
}

/**
 * Notification State Table (for recovery)
 * Tracks scheduled notification IDs in case of app restart
 */
export interface NotificationStateTable {
  id: string;  // UUID
  session_id: number;
  notification_id: string;  // expo-notifications ID
  session_type: 'focus' | 'break';
  scheduled_at: string;  // ISO8601
  delivered: boolean;
}

/**
 * Storage Keys for AsyncStorage persistence
 */
export const STORAGE_KEYS = {
  SESSION_STATE: 'pomodoro_timer_state',
  DEVICE_ID: 'pomodoro_device_id',
  CURRENT_USER: 'pomodoro_current_user',
  SYNC_QUEUE: 'pomodoro_sync_queue',
  NOTIFICATION_STATE: 'pomodoro_notification_state',
  LAST_SYNC_AT: 'pomodoro_last_sync_at',
} as const;

/**
 * Serializable timer state for AsyncStorage
 */
export interface PersistencePayload {
  timer: {
    status: 'idle' | 'active' | 'paused' | 'completed';
    sessionType: 'focus' | 'break' | null;
    plannedMinutes: 25 | 5;
    label?: string;
    startedAtMs?: number;
    pausedAtMs?: number;
    resumedAtMs?: number;
    totalPausedMs: number;
  };
  sessionId?: number;
  savedAt: number;
}
