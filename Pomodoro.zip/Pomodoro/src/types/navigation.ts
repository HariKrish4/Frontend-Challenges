export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

export type AuthStackParamList = {
  index: undefined;
  'otp-verify': { email: string };
};

export type MainTabParamList = {
  timer: undefined;
  stats: undefined;
  settings: undefined;
};

export type TimerStackParamList = {
  index: undefined;
  'focus-active': { sessionId?: string };
  'focus-complete': { sessionId: string };
  'break-active': { sessionId: string };
  'break-complete': { sessionId: string };
};

export type StatsStackParamList = {
  index: undefined;
};

export type SettingsStackParamList = {
  index: undefined;
};
