// ============================================================================
// AUTH & USER
// ============================================================================
export interface AuthUser {
  id: string;
  email?: string;
  phone?: string;
  aud?: string;
  role?: string;
  email_confirmed_at?: string;
  phone_confirmed_at?: string;
  created_at: string;
}

export interface Profile {
  id: string;
  language: 'en' | 'hi' | 'ta';
  timezone: string;
  created_at: string;
  updated_at: string;
}

// ============================================================================
// SESSION & TIMER
// ============================================================================
export type SessionType = 'focus' | 'break';
export type SessionStatus = 'idle' | 'active' | 'paused' | 'completed';

export interface Session {
  id: number;
  user_id: string;
  type: SessionType;
  planned_minutes: 25 | 5;
  actual_minutes: number;
  label?: string;
  started_at: string;
  ended_at?: string;
  device_id: string;
  created_at: string;
  updated_at?: string;
}

export interface LocalSession {
  tempId?: string;
  user_id?: string;
  type: SessionType;
  planned_minutes: 25 | 5;
  actual_minutes: number;
  label?: string;
  started_at: string;
  ended_at?: string;
  device_id: string;
  synced: boolean;
}

export interface TimerState {
  status: SessionStatus;
  sessionType: SessionType;
  plannedMinutes: 25 | 5;
  actualMinutes: number;
  actualSeconds: number;
  remainingMs: number;
  label?: string;
  startedAt?: number;
  pausedAt?: number;
  totalPausedMs: number;
}

// ============================================================================
// EXAM PRESETS & LABELS
// ============================================================================
export interface ExamPreset {
  id: number;
  title: string;
  description?: string;
  locale: 'en' | 'hi' | 'ta';
  is_active: boolean;
  created_at: string;
}

export interface LabelOption {
  type: 'preset' | 'custom';
  value: string;
  displayName: string;
}

// ============================================================================
// STATS
// ============================================================================
export interface DailyStat {
  date: string;
  focusCount: number;
  breakCount: number;
  totalFocusMinutes: number;
  totalBreakMinutes: number;
}

export interface StatsAggregate {
  totalSessions: number;
  totalFocusMinutes: number;
  currentStreak: number;
  longestStreak: number;
  weeklyData: DailyStat[];
  topLabels: Array<{ label: string; count: number }>;
}

// ============================================================================
// SYNC & OFFLINE
// ============================================================================
export interface SyncQueue {
  id: string;
  action: 'insert' | 'update';
  table: 'sessions' | 'profiles';
  payload: any;
  createdAt: number;
  retries: number;
  lastError?: string;
}

export interface SyncStatus {
  online: boolean;
  syncing: boolean;
  queueLength: number;
  lastSyncAt?: number;
}

// ============================================================================
// NOTIFICATIONS
// ============================================================================
export interface NotificationPayload {
  sessionType: SessionType;
  sessionId?: number;
  plannedMinutes: 25 | 5;
  label?: string;
  deepLink?: string;
}

export interface NotificationPermissionState {
  iosGranted?: boolean;
  androidGranted?: boolean;
  isDenied: boolean;
}
