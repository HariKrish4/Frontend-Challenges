import { TimerState, Session, Profile, SyncStatus, NotificationPermissionState, ScheduledNotification, SessionCreatePayload } from './domain';

// ============================================================================
// TIMER STORE
// ============================================================================
export interface TimerStoreState {
  timer: TimerState;
  currentSession: Session | null;
  isLoading: boolean;
  error: string | null;
  
  // Core actions
  startFocus: (label?: string) => Promise<void>;
  startBreak: () => Promise<void>;
  pauseSession: () => Promise<void>;
  resumeSession: () => Promise<void>;
  skipSession: () => Promise<void>;
  completeSession: (actualMinutes?: number) => Promise<void>;
  
  // Utility
  formatDisplayTime: () => string;  // MM:SS
  recoverFromStorage: () => Promise<void>;
  
  // Internal setters
  setTimer: (timer: Partial<TimerState>) => void;
  setCurrentSession: (session: Session | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  resetTimer: () => void;
  _tick: () => void;
}

// ============================================================================
// SYNC STORE
// ============================================================================
export interface SyncStoreState {
  syncStatus: SyncStatus;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  queueSession: (session: Session) => Promise<void>;
  syncPending: () => Promise<{ uploaded: number; failed: number }>;
  setOnline: (isOnline: boolean) => void;
  
  // Internal setters
  setSyncStatus: (status: Partial<SyncStatus>) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  resetSync: () => void;
}

// ============================================================================
// PROFILE STORE
// ============================================================================
export interface ProfileStoreState {
  profile: Profile | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  loadProfile: (userId: string) => Promise<void>;
  setLanguage: (lang: 'en' | 'hi' | 'ta') => Promise<void>;
  setNotificationsEnabled: (enabled: boolean) => Promise<void>;
  
  // Internal setters
  setProfile: (profile: Profile | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  resetProfile: () => void;
}

// ============================================================================
// AUTH STORE
// ============================================================================
export interface AuthStoreState {
  user: { id: string; email?: string } | null;
  profile: Profile | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  sendMagicLink: (email: string) => Promise<void>;
  verifyMagicLink: (email: string, token: string) => Promise<void>;
  sendOTP: (phone: string) => Promise<void>;
  verifyOTP: (phone: string, otp: string) => Promise<void>;
  checkSession: () => Promise<void>;
  logout: () => Promise<void>;
  
  // Internal setters
  setUser: (user: { id: string; email?: string } | null) => void;
  setProfile: (profile: Profile | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearError: () => void;
}

// ============================================================================
// NOTIFICATION STORE
// ============================================================================
export interface NotificationStoreState {
  permissions: NotificationPermissionState;
  scheduledNotifications: ScheduledNotification[];
  
  // Actions
  requestPermissions: () => Promise<'granted' | 'denied'>;
  scheduleEndOfFocus: (sessionId: number, delayMs: number) => Promise<string>;
  scheduleEndOfBreak: (sessionId: number, delayMs: number) => Promise<string>;
  cancelNotification: (notifId: string) => Promise<void>;
  
  // Internal setters
  setPermissions: (permissions: Partial<NotificationPermissionState>) => void;
  addScheduledNotification: (notif: ScheduledNotification) => void;
  removeScheduledNotification: (notifId: string) => void;
  resetNotifications: () => void;
}
