import { TimerState, Session, Profile, SyncStatus, NotificationPermissionState } from './domain';

// ============================================================================
// TIMER STORE
// ============================================================================
export interface TimerStoreState {
  timer: TimerState;
  currentSession: Session | null;
  setTimer: (timer: Partial<TimerState>) => void;
  setCurrentSession: (session: Session | null) => void;
  resetTimer: () => void;
}

// ============================================================================
// SYNC STORE
// ============================================================================
export interface SyncStoreState {
  syncStatus: SyncStatus;
  setSyncStatus: (status: Partial<SyncStatus>) => void;
  resetSync: () => void;
}

// ============================================================================
// AUTH STORE
// ============================================================================
export interface AuthStoreState {
  user: { id: string; email?: string } | null;
  profile: Profile | null;
  isLoading: boolean;
  error: string | null;
  setUser: (user: { id: string; email?: string } | null) => void;
  setProfile: (profile: Profile | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  logout: () => void;
}

// ============================================================================
// NOTIFICATION STORE
// ============================================================================
export interface NotificationStoreState {
  permissions: NotificationPermissionState;
  scheduleIds: { focusId?: string; breakId?: string };
  setPermissions: (permissions: Partial<NotificationPermissionState>) => void;
  setScheduleIds: (ids: { focusId?: string; breakId?: string }) => void;
  resetNotifications: () => void;
}
