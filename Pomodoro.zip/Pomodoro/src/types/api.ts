// Supabase API response types (can be auto-generated from database)
export type Tables = {
  profiles: {
    Row: {
      id: string;
      language: 'en' | 'hi' | 'ta';
      timezone: string;
      created_at: string;
      updated_at: string;
    };
  };
  sessions: {
    Row: {
      id: number;
      user_id: string;
      type: 'focus' | 'break';
      planned_minutes: 25 | 5;
      actual_minutes: number;
      label?: string;
      started_at: string;
      ended_at?: string;
      device_id: string;
      created_at: string;
      updated_at?: string;
    };
  };
  exam_presets: {
    Row: {
      id: number;
      title: string;
      description?: string;
      locale: 'en' | 'hi' | 'ta';
      is_active: boolean;
      created_at: string;
    };
  };
};

export type Database = {
  public: {
    Tables: Tables;
  };
};
