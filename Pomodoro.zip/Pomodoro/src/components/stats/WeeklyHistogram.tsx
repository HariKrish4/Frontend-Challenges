import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Card } from '@components/common/Card';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface WeeklyHistogramProps {
  data: number[]; // 7 days of data
  maxValue?: number;
  labels?: string[];
}

export const WeeklyHistogram: React.FC<WeeklyHistogramProps> = ({
  data,
  maxValue = Math.max(...data, 1),
  labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
}) => {
  return (
    <Card style={styles.card}>
      <Text style={styles.title}>Weekly Overview</Text>
      <View style={styles.chartContainer}>
        {data.map((value, index) => (
          <View key={index} style={styles.barContainer}>
            <View
              style={[
                styles.bar,
                {
                  height: (value / maxValue) * 100,
                  backgroundColor: value > 0 ? colors.primary : colors.gray200,
                },
              ]}
            />
            <Text style={styles.barLabel}>{labels[index]}</Text>
          </View>
        ))}
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: spacing[4],
    marginHorizontal: spacing[2],
    marginVertical: spacing[2],
  },
  title: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    marginBottom: spacing[3],
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 150,
    paddingHorizontal: spacing[1],
  },
  barContainer: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'flex-end',
    marginHorizontal: spacing[1],
  },
  bar: {
    width: '100%',
    minHeight: 4,
    borderRadius: 4,
    marginBottom: spacing[2],
  },
  barLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textTertiary,
    fontWeight: '500' as const,
  },
});
