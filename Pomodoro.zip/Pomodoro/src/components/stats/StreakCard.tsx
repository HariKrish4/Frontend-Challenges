import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Card } from '@components/common/Card';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface StreakCardProps {
  streak: number;
  longestStreak: number;
}

export const StreakCard: React.FC<StreakCardProps> = ({ streak, longestStreak }) => {
  return (
    <Card style={styles.card}>
      <View style={styles.streakContainer}>
        <Text style={styles.emoji}>🔥</Text>
        <View>
          <Text style={styles.streakValue}>{streak}</Text>
          <Text style={styles.streakLabel}>Day Streak</Text>
        </View>
      </View>
      <View style={styles.divider} />
      <View style={styles.longestContainer}>
        <Text style={styles.longestLabel}>Longest: {longestStreak} days</Text>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: spacing[4],
    marginHorizontal: spacing[2],
    marginVertical: spacing[2],
  },
  streakContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing[2],
  },
  emoji: {
    fontSize: 40,
    marginRight: spacing[3],
  },
  streakValue: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: '700' as const,
    color: colors.primary,
  },
  streakLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: '500' as const,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing[2],
  },
  longestContainer: {
    alignItems: 'center',
  },
  longestLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.textTertiary,
  },
});
