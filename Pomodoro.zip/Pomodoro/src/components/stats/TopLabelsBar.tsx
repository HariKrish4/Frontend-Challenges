import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { Card } from '@components/common/Card';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface LabelEntry {
  label: string;
  count: number;
}

interface TopLabelsBarProps {
  labels: LabelEntry[];
}

export const TopLabelsBar: React.FC<TopLabelsBarProps> = ({ labels }) => {
  const maxCount = Math.max(...(labels.map((l) => l.count) || [1]));

  const renderItem = ({ item, index }: { item: LabelEntry; index: number }) => (
    <View style={styles.labelRow}>
      <View style={styles.labelInfo}>
        <Text style={styles.rank}>#{index + 1}</Text>
        <Text style={styles.labelName}>{item.label}</Text>
      </View>
      <View style={styles.barWrapper}>
        <View
          style={[
            styles.bar,
            {
              width: `${(item.count / maxCount) * 100}%`,
            },
          ]}
        />
      </View>
      <Text style={styles.count}>{item.count}</Text>
    </View>
  );

  return (
    <Card style={styles.card}>
      <Text style={styles.title}>Top Focus Areas</Text>
      <FlatList
        data={labels}
        renderItem={renderItem}
        keyExtractor={(item) => item.label}
        scrollEnabled={false}
      />
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: spacing[4],
    marginHorizontal: spacing[2],
    marginVertical: spacing[2],
  },
  title: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    marginBottom: spacing[3],
  },
  labelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing[3],
  },
  labelInfo: {
    width: 80,
    flexDirection: 'row',
    alignItems: 'center',
  },
  rank: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600' as const,
    color: colors.primary,
    marginRight: spacing[2],
  },
  labelName: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: '500' as const,
    flex: 1,
  },
  barWrapper: {
    flex: 1,
    height: 8,
    backgroundColor: colors.gray200,
    borderRadius: 4,
    marginHorizontal: spacing[2],
    overflow: 'hidden',
  },
  bar: {
    height: '100%',
    backgroundColor: colors.secondary,
    borderRadius: 4,
  },
  count: {
    fontSize: typography.fontSize.sm,
    fontWeight: '600' as const,
    color: colors.textPrimary,
    minWidth: 30,
    textAlign: 'right',
  },
});
