import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Card } from '@components/common/Card';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface StatCardProps {
  label: string;
  value: string | number;
  subtitle?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ label, value, subtitle }) => {
  return (
    <Card style={styles.card}>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing[4],
    marginHorizontal: spacing[2],
    marginVertical: spacing[2],
    flex: 1,
  },
  value: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: '700' as const,
    color: colors.primary,
    marginBottom: spacing[1],
  },
  label: {
    fontSize: typography.fontSize.sm,
    fontWeight: '500' as const,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: typography.fontSize.xs,
    color: colors.textTertiary,
    marginTop: spacing[1],
  },
});
