import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, FlatList, TouchableOpacity } from 'react-native';
import { Button } from '@components/common/Button';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

type Language = 'en' | 'hi' | 'ta';

interface LanguageSelectorProps {
  visible: boolean;
  selectedLanguage: Language;
  onSelectLanguage: (language: Language) => void;
  onClose: () => void;
}

const LANGUAGES: Array<{ code: Language; label: string; nativeLabel: string }> = [
  { code: 'en', label: 'English', nativeLabel: 'English' },
  { code: 'hi', label: 'Hindi', nativeLabel: 'हिंदी' },
  { code: 'ta', label: 'Tamil', nativeLabel: 'தமிழ்' },
];

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  visible,
  selectedLanguage,
  onSelectLanguage,
  onClose,
}) => {
  const renderItem = ({ item }: { item: typeof LANGUAGES[0] }) => (
    <TouchableOpacity
      style={[
        styles.languageItem,
        selectedLanguage === item.code && styles.languageItemSelected,
      ]}
      onPress={() => {
        onSelectLanguage(item.code);
        onClose();
      }}
    >
      <View>
        <Text style={styles.languageLabel}>{item.label}</Text>
        <Text style={styles.languageNative}>{item.nativeLabel}</Text>
      </View>
      {selectedLanguage === item.code && (
        <Text style={styles.checkmark}>✓</Text>
      )}
    </TouchableOpacity>
  );

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <Text style={styles.title}>Select Language</Text>
          <FlatList
            data={LANGUAGES}
            renderItem={renderItem}
            keyExtractor={(item) => item.code}
            scrollEnabled={false}
          />
          <Button
            label="Close"
            onPress={onClose}
            variant="tertiary"
            size="md"
            style={styles.closeButton}
          />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    backgroundColor: colors.white,
    borderRadius: 20,
    padding: spacing[4],
    marginHorizontal: spacing[4],
    minWidth: 280,
  },
  title: {
    fontSize: typography.fontSize.lg,
    fontWeight: '700' as const,
    color: colors.textPrimary,
    marginBottom: spacing[4],
  },
  languageItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing[3],
    paddingHorizontal: spacing[3],
    marginVertical: spacing[1],
    borderRadius: 8,
    backgroundColor: colors.gray50,
  },
  languageItemSelected: {
    backgroundColor: colors.primaryLight,
  },
  languageLabel: {
    fontSize: typography.fontSize.base,
    fontWeight: '600' as const,
    color: colors.textPrimary,
  },
  languageNative: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginTop: spacing[1],
  },
  checkmark: {
    fontSize: typography.fontSize.lg,
    color: colors.primary,
    fontWeight: '700' as const,
  },
  closeButton: {
    marginTop: spacing[4],
  },
});
