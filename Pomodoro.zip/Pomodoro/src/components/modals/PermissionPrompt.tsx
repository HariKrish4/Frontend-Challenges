import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, Platform } from 'react-native';
import { Button } from '@components/common/Button';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface PermissionPromptProps {
  visible: boolean;
  onClose: () => void;
  onGranted: () => void;
}

export const PermissionPrompt: React.FC<PermissionPromptProps> = ({ visible, onClose, onGranted }) => {
  const [loading, setLoading] = useState(false);

  const handleRequestPermission = async () => {
    setLoading(true);
    try {
      // Notifications are not available in Expo Go on Android (SDK 53+)
      // For now, just proceed with onGranted
      if (Platform.OS === 'android') {
        console.warn('Push notifications not available in Expo Go. Use a development build instead.');
        onGranted();
        return;
      }

      // For iOS, try to request permissions if available
      try {
        const Notifications = await import('expo-notifications');
        const { status } = await Notifications.requestPermissionsAsync();
        if (status === 'granted') {
          onGranted();
        }
      } catch {
        onGranted();
      }
    } catch (error) {
      console.error('Permission request error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <Text style={styles.title}>Enable Notifications</Text>
          <Text style={styles.message}>
            Get notified when your focus and break sessions end. You can always change this later in Settings.
          </Text>

          <View style={styles.actions}>
            <Button
              label="Not Now"
              onPress={onClose}
              variant="tertiary"
              size="md"
            />
            <Button
              label="Enable"
              onPress={handleRequestPermission}
              variant="primary"
              size="md"
              loading={loading}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    backgroundColor: colors.white,
    borderRadius: 20,
    padding: spacing[6],
    marginHorizontal: spacing[4],
    minWidth: 280,
  },
  title: {
    fontSize: typography.fontSize.xl,
    fontWeight: '700' as const,
    color: colors.textPrimary,
    marginBottom: spacing[2],
  },
  message: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: spacing[6],
  },
  actions: {
    gap: spacing[2],
  },
});
