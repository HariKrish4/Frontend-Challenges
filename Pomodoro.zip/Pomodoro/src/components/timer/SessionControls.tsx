import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button } from '@components/common/Button';
import { spacing } from '@theme/spacing';

interface SessionControlsProps {
  onPause: () => void;
  onStop: () => void;
  onSkip: () => void;
  isPaused?: boolean;
}

export const SessionControls: React.FC<SessionControlsProps> = ({
  onPause,
  onStop,
  onSkip,
  isPaused = false,
}) => {
  return (
    <View style={styles.container}>
      <Button
        label={isPaused ? 'Resume' : 'Pause'}
        onPress={onPause}
        variant="secondary"
        size="md"
        style={styles.button}
      />
      <Button
        label="Stop"
        onPress={onStop}
        variant="tertiary"
        size="md"
        style={styles.button}
      />
      <Button
        label="Skip"
        onPress={onSkip}
        variant="tertiary"
        size="md"
        style={styles.button}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing[2],
    marginVertical: spacing[4],
    paddingHorizontal: spacing[4],
  },
  button: {
    flex: 1,
  },
});
