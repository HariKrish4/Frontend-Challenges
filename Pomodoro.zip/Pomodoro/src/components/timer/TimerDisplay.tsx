import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Countdown } from '@components/common/Countdown';
import { colors } from '@theme/colors';
import { spacing } from '@theme/spacing';

interface TimerDisplayProps {
  totalSeconds: number;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({ totalSeconds }) => {
  return (
    <View style={styles.container}>
      <View style={styles.circleContainer}>
        <View style={styles.circle}>
          <Countdown totalSeconds={totalSeconds} variant="large" />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: spacing[6],
  },
  circleContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  circle: {
    width: 240,
    height: 240,
    borderRadius: 120,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
});
