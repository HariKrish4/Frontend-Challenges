import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button } from '@components/common/Button';
import { spacing } from '@theme/spacing';

interface BreakStartCTAProps {
  onStartBreak: () => void;
  loading?: boolean;
}

export const BreakStartCTA: React.FC<BreakStartCTAProps> = ({ onStartBreak, loading = false }) => {
  return (
    <View style={styles.container}>
      <Button
        label="Start Break"
        onPress={onStartBreak}
        variant="primary"
        size="lg"
        loading={loading}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing[4],
    paddingVertical: spacing[4],
  },
});
