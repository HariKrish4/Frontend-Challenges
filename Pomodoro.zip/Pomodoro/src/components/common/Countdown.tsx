import React from 'react';
import { Text, StyleSheet, StyleProp, TextStyle as RNTextStyle } from 'react-native';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';

interface CountdownProps {
  totalSeconds: number;
  variant?: 'large' | 'medium' | 'small';
  style?: StyleProp<RNTextStyle>;
}

export const Countdown: React.FC<CountdownProps> = ({ totalSeconds, variant = 'large', style }) => {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const displayText = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const variantStyles = {
    large: {
      fontSize: typography.fontSize['5xl'],
      fontWeight: '700' as const,
    },
    medium: {
      fontSize: typography.fontSize['3xl'],
      fontWeight: '600' as const,
    },
    small: {
      fontSize: typography.fontSize['2xl'],
      fontWeight: '600' as const,
    },
  };

  return (
    <Text style={[styles.text, variantStyles[variant], style]}>
      {displayText}
    </Text>
  );
};

const styles = StyleSheet.create({
  text: {
    color: colors.textPrimary,
    fontVariant: ['tabular-nums'],
    textAlign: 'center',
  },
});
