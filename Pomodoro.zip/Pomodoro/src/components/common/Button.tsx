import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, StyleProp, ViewStyle, TextStyle as RNTextStyle } from 'react-native';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

type ButtonVariant = 'primary' | 'secondary' | 'tertiary';
type ButtonSize = 'lg' | 'md' | 'sm';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  labelStyle?: StyleProp<RNTextStyle>;
}

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  style,
  labelStyle,
}) => {
  const styles = getStyles(variant, size);

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={[styles.button, disabled && styles.disabled, style]}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator color={styles.labelColor} size="small" />
      ) : (
        <Text style={[styles.label, labelStyle]}>{label}</Text>
      )}
    </TouchableOpacity>
  );
};

interface StylesReturn {
  button: ViewStyle;
  label: RNTextStyle;
  disabled: ViewStyle;
  labelColor: string;
}

const getStyles = (variant: ButtonVariant, size: ButtonSize): StylesReturn => {
  const baseSizeStyles = {
    lg: {
      paddingVertical: spacing[4],
      paddingHorizontal: spacing[6],
      fontSize: typography.fontSize.lg,
    },
    md: {
      paddingVertical: spacing[3],
      paddingHorizontal: spacing[5],
      fontSize: typography.fontSize.base,
    },
    sm: {
      paddingVertical: spacing[2],
      paddingHorizontal: spacing[4],
      fontSize: typography.fontSize.sm,
    },
  };

  const variantStyles = {
    primary: {
      button: {
        backgroundColor: colors.primary,
        borderRadius: 8,
      },
      label: {
        color: colors.white,
        fontWeight: '600' as const,
      },
      labelColor: colors.white,
    },
    secondary: {
      button: {
        backgroundColor: colors.secondary,
        borderRadius: 8,
      },
      label: {
        color: colors.white,
        fontWeight: '600' as const,
      },
      labelColor: colors.white,
    },
    tertiary: {
      button: {
        backgroundColor: colors.gray100,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: colors.border,
      },
      label: {
        color: colors.textPrimary,
        fontWeight: '500' as const,
      },
      labelColor: colors.textPrimary,
    },
  };

  const sizeStyle = baseSizeStyles[size];
  const variantStyle = variantStyles[variant];

  return {
    button: { ...variantStyle.button, ...sizeStyle },
    label: variantStyle.label,
    disabled: {
      opacity: 0.6,
    },
    labelColor: variantStyle.labelColor,
  };
};
