import React from 'react';
import { TouchableOpacity, Text, StyleSheet, StyleProp, ViewStyle, TextStyle as RNTextStyle } from 'react-native';
import { colors } from '@theme/colors';
import { typography } from '@theme/typography';
import { spacing } from '@theme/spacing';

interface ChipProps {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}

export const Chip: React.FC<ChipProps> = ({ label, selected = false, onPress, style, disabled = false }) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.chip,
        selected ? styles.chipSelected : styles.chipDefault,
        disabled && styles.disabled,
        style,
      ]}
      activeOpacity={0.7}
    >
      <Text style={[styles.label, selected ? styles.labelSelected : styles.labelDefault]}>{label}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: spacing[3],
    paddingVertical: spacing[2],
    borderRadius: 20,
    marginRight: spacing[2],
    marginBottom: spacing[2],
  },
  chipSelected: {
    backgroundColor: colors.primary,
    borderWidth: 0,
  },
  chipDefault: {
    backgroundColor: colors.gray100,
    borderWidth: 1,
    borderColor: colors.border,
  },
  label: {
    fontSize: typography.fontSize.sm,
    fontWeight: '500' as const,
  },
  labelSelected: {
    color: colors.white,
  },
  labelDefault: {
    color: colors.textPrimary,
  },
  disabled: {
    opacity: 0.5,
  },
});
