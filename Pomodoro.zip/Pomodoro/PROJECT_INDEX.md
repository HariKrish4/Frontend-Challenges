# Pomodoro App — Project Index

## 📁 Complete File Manifest

### Root Configuration
- `package.json` — Dependencies & scripts
- `app.json` — Expo configuration
- `tsconfig.json` — TypeScript settings
- `.gitignore` — Git exclusions
- `eas.json` — EAS Build config
- `index.js` — Expo Router entry point

---

## 🎨 Theme & Design (`src/theme/`)
- `colors.ts` — Palette (primary red, secondary teal, neutrals, semantic)
- `typography.ts` — Material Design 3 scales, font families, styles
- `spacing.ts` — Consistent spacing scale (4px-based)

---

## 🌍 Internationalization (`src/locales/`)
- `en.json` — English strings
- `hi.json` — Hindi strings (Devanagari)
- `ta.json` — Tamil strings (Tamil script)
- `i18n.ts` — react-i18next config + device locale detection

---

## 📱 Routing & Screens (`src/app/`)

### Root
- `_layout.tsx` — Root layout, splash handling, session check prep

### Auth Group `(auth)/`
- `_layout.tsx` — Auth stack navigator
- `index.tsx` — AuthScreen (magic link + OTP entry)
- `otp-verify.tsx` — OTPVerifyScreen (OTP confirmation)

### Timer Group `(timer)/`
- `_layout.tsx` — Timer stack navigator
- `index.tsx` — HomeTimer (idle, start focus button)
- `focus-active.tsx` — FocusActive (25m countdown, controls)
- `focus-complete.tsx` — FocusComplete (label picker, "Start Break" CTA)
- `break-active.tsx` — BreakActive (5m countdown, controls)
- `break-complete.tsx` — BreakComplete (celebration, auto-return)

### Stats Group `(stats)/`
- `_layout.tsx` — Stats stack navigator
- `index.tsx` — StatsScreen (KPIs, streak, histogram, top labels)

### Settings Group `(settings)/`
- `_layout.tsx` — Settings stack navigator
- `index.tsx` — SettingsScreen (language, notifications, logout)

---

## 🧩 Components (`src/components/`)

### Common Components (`common/`)
- `Button.tsx` — Styled button (3 variants: primary/secondary/tertiary, 3 sizes: lg/md/sm)
- `Chip.tsx` — Preset/label chips (selected/unselected states)
- `Countdown.tsx` — MM:SS timer display (large/medium/small variants)
- `Card.tsx` — Container with shadow & border radius
- `LoadingSpinner.tsx` — Activity indicator wrapper
- `ErrorBoundary.tsx` — Error fallback UI

### Timer Components (`timer/`)
- `TimerDisplay.tsx` — Large circular timer with countdown
- `SessionControls.tsx` — Pause/Resume, Stop, Skip button row
- `BreakStartCTA.tsx` — Large "Start Break" primary button

### Stats Components (`stats/`)
- `StatCard.tsx` — KPI display (number + label, e.g., "3 Pomodoros")
- `StreakCard.tsx` — Streak display with emoji & longest streak
- `WeeklyHistogram.tsx` — 7-day bar chart of sessions
- `TopLabelsBar.tsx` — Most-used labels leaderboard with bars

### Modal Components (`modals/`)
- `PermissionPrompt.tsx` — Notification permission request modal
- `LanguageSelector.tsx` — EN/HI/TA language radio group modal

---

## 🏪 State Management (`src/store/`)
**All placeholders — to be filled in Stage 2:**
- `timerStore.ts` — Zustand: timer state machine
- `syncStore.ts` — Zustand: sync queue & online status
- `authStore.ts` — Zustand: user session & profile
- `notificationStore.ts` — Zustand: permissions & scheduled IDs

---

## 🔧 Services (`src/services/`)

### Supabase (`supabase/`)
- `client.ts` — Supabase JS client init (placeholder)
- `auth.ts` — Magic link & OTP flows (placeholder)

### SQLite (`sqlite/`)
- `db.ts` — Database schema & init
- `repositories/`
  - `SessionRepository.ts` — CRUD for sessions (placeholder)
  - `ProfileRepository.ts` — CRUD for profiles (placeholder)
  - `PresetRepository.ts` — Read-only presets (placeholder)
- `migrations.ts` — Schema versioning (placeholder)

### Notifications (`notifications/`)
- `notificationManager.ts` — Schedule focus/break end notifications (placeholder)
- `handlers.ts` — Tap & foreground response handlers (placeholder)

### Sync (`sync/`)
- `syncEngine.ts` — Queue local inserts, push on online, de-duplicate (placeholder)
- `reconciliation.ts` — Last-write-wins conflict resolution (placeholder)

### Timer (`timer/`)
- `timerEngine.ts` — Timestamp-diff monotonic timer (placeholder)
- `utils.ts` — Duration calc, format helpers (placeholder)

### Connectivity (`connectivity/`)
- `netInfo.ts` — Online/offline status listener (placeholder)

---

## 🎯 Types (`src/types/`)
- `domain.ts` — Core types (Session, TimerState, Profile, ExamPreset, StatsAggregate, SyncQueue, NotificationPayload)
- `store.ts` — Zustand state shape types
- `api.ts` — Supabase table row types
- `navigation.ts` — Expo Router param lists (RootStackParamList, TimerStackParamList, etc.)

---

## 🛠️ Utilities (`src/utils/`)
- `dateTime.ts` — IST timezone handling, formatting, day/week ranges
- `device.ts` — Device ID generation & storage (AsyncStorage-based)
- `validators.ts` — Email, phone, OTP, label validation & sanitization
- `constants.ts` — FOCUS_DURATION, BREAK_DURATION, SESSION_STATUS, EXAM_PRESETS, etc.

---

## 📋 Key Decisions (Stage 1)

### Navigation
- **expo-router** (file-based routing, not React Navigation)
- Groups: `(auth)`, `(timer)`, `(stats)`, `(settings)` for logical organization
- All screens are **placeholders** with correct routing structure

### Styling
- No external UI library (CSS-in-JS via StyleSheet)
- Material Design 3 principles (colors, typography, spacing scales)
- Responsive: based on spacing units, not hardcoded pixels

### Internationalization
- **react-i18next** with JSON resource files
- Device locale auto-detection (fallback: English)
- All UI strings in i18n keys (no hardcoded strings)

### Placeholders Ready for Stage 2
- Zustand stores (currently empty directories)
- Service implementations (signatures defined, bodies minimal)
- Timer logic (utils created, engine pending)
- SQLite schema (defined in db.ts, no actual DB init yet)
- Supabase auth (package installed, client stub exists)

---

## 🚀 Next: Stage 2 Checklist

### Timer Engine & State Management
- [ ] Implement Zustand stores (timerStore, syncStore, authStore, notificationStore)
- [ ] Create timer service with timestamp-diff approach
- [ ] Implement pause/resume/stop/skip logic
- [ ] Add session state machine (idle → active → paused → completed)

### Testing
- [ ] Manual testing of screen navigation
- [ ] Timer countdown accuracy
- [ ] Pause/resume transitions

### Deliverable
- Fully functional Pomodoro timer with manual break start
- Timer continues accurately across app backgrounding (in-memory)
- State persists within session

---

## 📄 License & Documentation
- `STAGE_1_COMPLETE.md` — This stage's summary & next steps
- `README.md` — (To be created)

---

**Last Updated:** 20 January 2026  
**Status:** ✅ Stage 1 Complete — UI Scaffolding & Routing Functional
